L.form = function(id) {
	function Form(id) {
		var _this = this;
		_this.element = document.getElementById(id);
		
		
		_this.disable=function(){
			_this.disformInput = _this.element.getElementsByTagName('input');
			_this.disformSelect = _this.element.getElementsByTagName('select');
			_this.disformTextarea = _this.element.getElementsByTagName('textarea');
			_this.disformBtn = $("#"+id).find(".btn");
			for(var i = 0; i < _this.disformInput.length; i++){
				_this.disformInput[i].disabled="disabled";
			}
			for(var i = 0; i < _this.disformSelect.length; i++){
				_this.disformSelect[i].disabled="disabled";
				$(_this.disformSelect[i]).prop("disabled", true)
				$('.selectpicker').select2Call();
			}
			for(var i = 0; i < _this.disformTextarea.length; i++){
				_this.disformTextarea[i].disabled="disabled";
			}
			for(var i = 0; i < _this.disformBtn.length; i++){
				_this.disformBtn.eq(i).addClass('disabled');
				_this.disformBtn.eq(i).on('click',function(){if($(this).hasClass("disabled")){return false;}});
			}
		
		}
		_this.enable=function(){
			_this.disformInput = _this.element.getElementsByTagName('input');
			_this.disformSelect = _this.element.getElementsByTagName('select');
			_this.disformTextarea = _this.element.getElementsByTagName('textarea');
			_this.disformBtn = $("#"+id).find(".btn.disabled");
			for(var i = 0; i < _this.disformInput.length; i++){
				_this.disformInput[i].disabled=false;
			}
			for(var i = 0; i < _this.disformSelect.length; i++){
				_this.disformSelect[i].disabled=false;
				$(_this.disformSelect[i]).prop("disabled", false);
				$('.selectpicker').select2Call();
			}
			for(var i = 0; i < _this.disformTextarea.length; i++){
				_this.disformTextarea[i].disabled=false;
			}
			for(var i = 0; i < _this.disformBtn.length; i++){
				_this.disformBtn.eq(i).removeClass('disabled');
			}
			
		}
		
		
		_this.getData = function(){
			
			_this.formInput = _this.element.getElementsByTagName('input');
			_this.formSelect = _this.element.getElementsByTagName('select');
			_this.formTextarea = _this.element.getElementsByTagName('textarea');
			_this.data = {};

			for(var i = 0; i < _this.formInput.length; i++) {
				if(_this.formInput[i].name&&_this.formInput[i].type!='radio'&&_this.formInput[i].type!='checkbox') {
					_this.data[_this.formInput[i].name] = _this.formInput[i].value ? _this.formInput[i].value : "";
				}else if(_this.formInput[i].name&&_this.formInput[i].type=='radio'&&_this.formInput[i].checked){
					_this.data[_this.formInput[i].name] = _this.formInput[i].value ? _this.formInput[i].value : "";
				}
				else if(_this.formInput[i].name&&_this.formInput[i].type=='checkbox'&&_this.formInput[i].checked){
					if(_this.data[_this.formInput[i].name]){
						_this.data[_this.formInput[i].name].push(_this.formInput[i].value ? _this.formInput[i].value : "")
					}else{
						_this.data[_this.formInput[i].name]=[];
						_this.data[_this.formInput[i].name][0] =_this.formInput[i].value ? _this.formInput[i].value : "";
					}
					
				}
			}
			for(var i = 0; i < _this.formSelect.length; i++) {
				
				if(_this.formSelect[i].name) {
					_this.data[_this.formSelect[i].name] = _this.formSelect[i].value ? _this.formSelect[i].value:$(_this).attr("Value");
				}
			}
			for(var i = 0; i < _this.formTextarea.length; i++) {
				if(_this.formTextarea[i].name) {
					_this.data[_this.formTextarea[i].name] = _this.formTextarea[i].value ? _this.formTextarea[i].value : "";
				}
			}
			return _this.data;
		};

		_this.setData = function(data){
			for(var k in data) {
				_this.Eles= _this.element.querySelectorAll('[name='+k+']');
				_this.Ele = _this.Eles[0];
				if(_this.Ele&&_this.Ele.type&&_this.Ele.type!='radio'&&_this.Ele.type!='checkbox'&&_this.Ele.type!='select-one'&&_this.Ele.type!='select-multiple'){
					_this.Ele.value = data[k];
					
				}
				else if(_this.Ele&&(_this.Ele.type=='select-one'||_this.Ele.type=='select-multiple')){
					if($(_this.Ele).hasClass('selectpicker')){
						$(_this.Ele).attr("Value",data[k]);
						$(_this.Ele).val(data[k]).trigger("change");
					}else{
						_this.Ele.value = data[k];
					}
					
				}
				else if(_this.Ele&&_this.Ele.type&&_this.Ele.type=='radio'){
					for(var i=0;i<_this.Eles.length;i++){
						if(_this.Eles[i].value == data[k]){
							_this.Eles[i].checked='checked';
						}
					}
				}
				else if(_this.Ele&&_this.Ele.type&&_this.Ele.type=='checkbox'){
					for(var i=0;i<_this.Eles.length;i++){
						for(var j=0;j<data[k].length;j++){
							if(_this.Eles[i].value == data[k][j]){
							_this.Eles[i].checked='checked';
						}
						}
					}
				}
			}
		
		
		}
	
	
	_this.clear=function(){
		if(_this.element.tagName=='FORM'){
			_this.element.reset();
		}
		_this.formSelect = _this.element.getElementsByTagName('select');
		for(var i = 0; i < _this.formSelect.length; i++){
				if(_this.formSelect[i].type=='select-one'||_this.formSelect[i].type=='select-multiple') {
					var val=$(_this.formSelect[i]).find("option").eq(0).val();
					$(_this.formSelect[i]).val("").trigger("change");
				}
			}
		_this.formInput = _this.element.getElementsByTagName('input');
		for(var i = 0; i < _this.formInput.length; i++) {
				if(_this.formInput[i].type=='radio'||this.formInput[i].type=='checkbox') {
					var name=_this.formInput[i].name;
					$('[name='+name+']').prop("checked",false);
					
				}else{
					_this.formInput[i].value="";
				}
			}
		_this.formTextarea=_this.element.getElementsByTagName('textarea');
		for(var i = 0; i < _this.formTextarea.length; i++) {
					_this.formTextarea[i].value="";
				
			}
	}
	}
	return new Form(id)
}
