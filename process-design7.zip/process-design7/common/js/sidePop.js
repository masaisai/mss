(function() {
	function SidePop(option) {
		var _this = this;
		this.defaultParameter = {
			hide: true, //默认是否打开
			width: '700px', //宽度
			minWidth:'0px',
			height: $(window).height() + "px", //高度
			top: "0px",
			right: "-100%",
			contentHeight: "620px",
			headPadding: "0px 30px", //头部padding
			contentPadding: '0', //主体padding
			headBackgroundColor: '#eee', //头部背景色
			body: $('body'),
			title: "标题" //标题
		}
		option = $.extend(true, {}, this.defaultParameter, option);
		if(option.body.find('.panelSide')) {
			option.body.find('.panelSide').remove();
		};
		this.$panelSide = $('<div class="panelSide" style="height:100%"></div>');
		if(option.hide) {
			option.right = "-100%";
		} else {
			option.right = "0";
		}
		if(typeof(option.width)=='number'){
			option.width=option.width+"px";
		}
		if(typeof(option.minWidth)=='number'){
			option.minWidth=option.minWidth+"px";
		}
		this.$panelSide.css({
			'width': option.width,
			//'height': $(window).height() - parseInt(option.top) + "px",
			'background': 'white',
			'position': 'fixed',
			'right': option.right,
			'top': option.top,
			'min-width':option.minWidth,
			'z-index': 1000000,
			'box-shadow': '-5px 5px 20px rgba(0,0,0,0.1)'
		});
		
		
		this.$div1 = $('<div class="panel-header"></div>');
		this.$div1.css({
			'background-color': option.headBackgroundColor,
			'padding': option.headPadding,
			"height":'50px',
			"position":"absolute",
			"top":"0",
			"left":"0",
			"width":"100%"
		});
		this.$h = $('<h4>标题</h4>');
		this.$h.css({
			color: '#000',
			'margin-top':'0',
			'margin-bottom':'0',
			'line-height':'50px'
		});
		this.$h.html(option.title);
		this.$close = $('<a class="panel-close" style="position: absolute; top:15px; width:24px; text-align:center; display:block; right: 20px; cursor:pointer"><i class="el-icon-close"></i></a>');
		this.$div1.append(this.$h);
		this.$div1.append(this.$close);

		this.$content = $('<div style="height:100%"></div>');
		_this.onload = "";

		
		
		this.$content.css({
			//"height": option.contentHeight,
			//"height":$(window).height()+"px",
			"padding": option.contentPadding,
			"padding-top":"50px"
		});
var a=0;

	
		this.$panelSide.append(this.$div1);
		this.$panelSide.append(this.$content);
		option.body.append(this.$panelSide);

		this.Btn = option.hide;
		this.ondestory = "";
		_this.close = function(data, call) {

			_this.$panelSide.stop(true,true).animate({
				"right": "-100%"
			},800, function() {
				if(_this.ondestory && (call != false || call == 'undefined')) {
					_this.ondestory(data);
				}
			});
			_this.Btn = true;
			_this.iframe.remove();

		};

		_this.clickEvent = function(openOption) {
			if(openOption.onload) {
				_this.onload = openOption.onload
			};
			if(openOption.ondestory) {
				_this.ondestory = openOption.ondestory;
			} else {
				_this.ondestory = ""
			};

			if(_this.Btn) {
				_this.$panelSide.animate({
					"right": "0px"
				},800);
				_this.Btn = false;
				_this.iframe = $('<iframe id="iframeWindow"  style="width:100%;height:100%;border:none;display:block"></iframe>');
				_this.iframe.get(0).onload = function() {
						var $style=$('<style>body{-ms-overflow-style:none;overflow:-moz-scrollbars;}html::-webkit-scrollbar{width:0}body::-webkit-scrollbar{display:none}</style>').get(0);
					_this.iframe.get(0).contentWindow.document.getElementsByTagName('head')[0].appendChild($style);
					
					
					_this.onload();
				};
				_this.iframe.attr("src", openOption.openurl ? openOption.openurl : "");
				_this.$content.append(_this.iframe);

				if(openOption.opentitle) {
					_this.$h.html(openOption.opentitle)
				}

			} else {
				_this.close({}, false);

			}
		};

		_this.openWindow = function(openOption) {
			if(!_this.Btn){
				_this.openViewWindow(openOption)
			}else{
				_this.clickEvent(openOption);
			}
			
		};
//		$(document).click(function(e) {
//				if((!$(e.target).hasClass('sideBtn'))&&(!$(e.target).parents().hasClass('sideBtn'))){
//				if(!_this.Btn) {
//						_this.close()
//					}	
//				}
//				});


	
		_this.open = function(url, title, data, callback) {
			//if(e){stopBubble(e);}
			_this.openWindow({
				'openurl': url,
				'opentitle': title,
				'onload': function() {
					if(_this.iframe.get(0).contentWindow.setData) {
						_this.iframe.get(0).contentWindow.setData(data);
							
					};
					
					_this.iframe.get(0).contentWindow.getData = function() {
						return data;
					};

			
				},
				'ondestory': function(param) {
					if(callback) {
						callback(param)
					}
				}
			});
			return false;
		};

		_this.openViewWindow = function(openOption) {
			_this.iframe.remove();
			if(openOption.onload) {
				_this.onload = openOption.onload
			};

			_this.iframe = $('<iframe id="iframeWindow"  style="width:100%;height:100%;border:none;display:block"></iframe>');
			_this.iframe.get(0).onload = function() {
				var $style=$('<style>body{-ms-overflow-style:none;overflow:-moz-scrollbars}html::-webkit-scrollbar{width:0}body::-webkit-scrollbar{display:none}</style>').get(0);
					_this.iframe.get(0).contentWindow.document.getElementsByTagName('head')[0].appendChild($style);
				_this.onload()
			};
			_this.iframe.attr("src", openOption.openurl ? openOption.openurl : "");
			_this.$content.append(_this.iframe);
			if(openOption.opentitle) {
				_this.$h.html(openOption.opentitle)
			};
		
		};
		_this.openView = function(url, title, data, callback) {
			if(callback) {
				callback = callback.toString();
				_this.ondestory = function(data) {
					callback = eval('(' + callback + ')');
					callback(data);
				};
			};
			_this.openViewWindow({
				'openurl': url,
				'opentitle': title,
				'onload': function() {
					if(_this.iframe.get(0).contentWindow.setData) {
						_this.iframe.get(0).contentWindow.setData(data);
					};
					_this.iframe.get(0).contentWindow.getData = function() {
						return data;
					};
					
				}
			});
//			_this.$close.click(function(){
//						if(typeof _this.iframe.get(0).contentWindow.CloseSidePop!="undefined"){
//							_this.iframe.get(0).contentWindow.CloseSidePop();
//						}else{
//							_this.close({}, false)
//						}
//					});
		}
		_this.$close.click(function() {
								if(typeof(_this.iframe.get(0).contentWindow.CloseSidePop)!="undefined"){
							_this.iframe.get(0).contentWindow.CloseSidePop();
						}else{
							_this.close()
						}
							});
//		_this.$close.click(function() {
//			_this.close({}, false)
//		});
		//var ie=(navigator.userAgent.indexOf('MSIE') >= 0) && (navigator.userAgent.indexOf('Opera') < 0);
//			window.onresize=function(){
//		
//			_this.$panelSide.css({
//				'height': $(window).height() - parseInt(option.top) + "px"
//			});
//
//		
//	}

	};

	
		L.newSidePop = null;
		L.sidePop = function(option) {
			L.newSidePop = new SidePop(option)
		};
		L.sidePop.openWindow = function(option) {
			L.newSidePop.openWindow(option)
		};
		L.sidePop.open = function(url, title, data, callback) {
			L.newSidePop.open(url, title, data, callback)
		};
		L.sidePop.openViewWindow = function(option) {
			L.newSidePop.openViewWindow(option)
		};
		L.sidePop.openView = function(url, title, data, callback) {
			L.newSidePop.openView(url, title, data, callback)
		};
		L.sidePop.close = function(data) {
			L.newSidePop.close(data)
		};
		L.sidePop.callback = function(data) {
			L.newSidePop.callback(data)
		};
	
	
})()
