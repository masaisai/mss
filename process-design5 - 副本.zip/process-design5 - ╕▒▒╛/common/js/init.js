Vue.use(Vuex);
var store = new Vuex.Store({
    state: {
        mode: 'view',
        viewInstance: null,
        instance: null,
        processData: [],
        currentMenu: []

    },
    mutations: {
        setMode: function (state, params) {
            state.mode = params.mode;
        },
        setInstance: function (state, params) { //设置编辑模式instance
            state.instance = params.instance;
        },
        setViewInstance: function (state, params) { //设置视图模式instance
            state.viewInstance = params.instance;
        },
        setProcessData: function (state, params) { //全局保存ajax数据
            state.processData = params.processData;
        },
        setCurrentMenu: function (state, params) {
            state.currentMenu = params.currentMenu;
        }
    },
    actions: {

        createViewProcess: function (content, params) {  //创建视图模式
            if (content.state.viewInstance) {
                L.instance.removeView(content.state.viewInstance);
                content.commit('setViewInstance', { instance: null });
            }
            if (content.state.instance) {
                L.instance.removeEditView(content.state.instance);
                instanceUnbindEvent(content.state.instance);
                content.commit('setInstance', { instance: null });
            }
            var instance = L.instance.viewInit({ Container: "container-id", Connector: ["Bezier", { stub: [40, 60], gap: 0, cornerRadius: 0, alwaysRespectStubs: true }] });
            L.instance.createView(instance, this.state.processData);
            content.commit('setInstance', { instance: instance });
        },
        createProcess: function (content, params) { //创建编辑模式
            if (content.state.instance) {
                L.instance.removeEditView(content.state.instance);
                content.commit('setInstance', { instance: null });
            }
            if (content.state.viewInstance) {
                L.instance.removeView(content.state.viewInstance);
                instanceUnbindEvent(content.state.instance);
                content.commit('setViewInstance', { instance: null });
            }
            var instance = L.instance.init({ Container: "container-id", Connector: ["Bezier", { stub: [40, 60], gap: 10, cornerRadius: 0, alwaysRespectStubs: true }] });
            instanceBindEvent(instance);
            L.instance.createEditView(instance, this.state.processData);
            content.commit('setInstance', { instance: instance });
        }
    }
});
var bus = new Vue();
Vue.prototype.bus = bus;
Vue.component('component-sidebar', function (resolve, reject) {  //侧边菜单
    $.get("./components/sidebar.html").then(function (res) {
        resolve({
            template: res,
            props: [],
            data: function () {
                return {
                    menuData: [],
                    menuTreeData: [],
                    active: "1-1",
                    dialogVisible: false,
                    dialogVisible1: false,
                    defaultProps: {
                        children: 'children',
                        label: 'name'
                    },
                    formTitle: "",
                    form: {
                        "name": "",
                        "icon": ""
                    },
                    rules: {
                        name: [
                            { required: true, message: '请输入菜单名称', trigger: 'blur' }
                        ]
                    },
                    editNode: "",
                    editType: ""
                }
            },
            created: function () {
                var _this = this;
                $.get('common/data/apply.json').then(function (result) {
                    _this.menuData = result;
                    _this.menuTreeData = JSON.parse(JSON.stringify(_this.menuData));
                    jsPlumb.ready(function () {
                        var activeArr = _this.active.split('-');
                        store.commit('setCurrentMenu', { currentMenu: _this.menuData[activeArr[0]].children[activeArr[1]] });
                        var id = _this.menuData[activeArr[0]].children[activeArr[1]].id;
                        L.instance.ajaxData('common/data/data.json?id=' + id, function (res) {
                            store.commit('setProcessData', { "processData": res });
                            store.dispatch('createViewProcess');
                        })
                    });
                });
            },
            mounted: function () {
                //setTimeout(function(){
                //	$('.el-menu .el-submenu .el-submenu__title').click();
                //	},100)
            },
            methods: {

                nodeSelect: function (res, active) {
                    var _this = this;
                    _this.active = active;
                    store.commit('setCurrentMenu', { currentMenu: res });
                    L.instance.ajaxData('common/data/data.json?id=' + res.id, function (res) {
                        store.commit('setProcessData', { "processData": res });
                        store.commit('setMode', { mode: 'view' });
                        _this.$emit('changemode', false);
                        _this.bus.$emit('treeChange');
                        store.dispatch('createViewProcess');
                    });

                },
                editMenu: function () {
                    this.dialogVisible = true
                },
                menuDataChange: function () {
                    this.menuData = JSON.parse(JSON.stringify(this.menuTreeData));
                    this.dialogVisible = false
                },
                cancelDataChange: function () {
                    this.menuTreeData = JSON.parse(JSON.stringify(this.menuData));
                    this.dialogVisible = false
                },
                renderContent: function (h, res) {
                    var _this = this;

                    var label = h('span', { domProps: { innerHTML: "<span><i class='" + res.data.icon + "' style='margin-right:4px'></i>" + res.data.name + "</span>" } });

                    var appendBtn = h('button', { attrs: { type: 'button' }, on: { click: function () { _this.appendData(res.node, res.data, res.store) } }, domProps: { innerHTML: '<i class="el-icon-circle-plus-outline"></i>' } });
                    var appendChildBtn = h('button', { attrs: { type: 'button' }, on: { click: function () { _this.appendChildData(res.node, res.data, res.store) } }, domProps: { innerHTML: '<i class="el-icon-circle-plus"></i>' } })
                    var removeBtn = h('button', { attrs: { type: 'button' }, on: { click: function () { _this.removeData(res.node, res.data, res.store) } }, domProps: { innerHTML: '<i class="el-icon-delete"></i>' } })
                    var editBtn = h('button', { attrs: { type: 'button' }, on: { click: function () { _this.editData(res.node, res.data, res.store) } }, domProps: { innerHTML: '<i class="el-icon-edit"></i>' } })
                    var removeToolTipBtn = h('el-tooltip', { attrs: { effect: "light", content: "节点删除", placement: "right" } }, [removeBtn]);
                    var appendToolTipBtn = h('el-tooltip', { attrs: { effect: "light", content: "增加兄弟节点", placement: "right" } }, [appendBtn]);
                    var appendChildToolTipBtn = h('el-tooltip', { attrs: { effect: "light", content: "增加子节点", placement: "right" } }, [appendChildBtn])
                    var editToolTipBtn = h('el-tooltip', { attrs: { effect: "light", content: "编辑节点", placement: "right" } }, [editBtn])
                    if (res.node.level == 1) {
                        return h('span', { attrs: { class: "custom-tree-node" } }, [label, h('span', {}, [appendToolTipBtn, appendChildToolTipBtn, editToolTipBtn, removeToolTipBtn])])
                    } else {
                        return h('span', { attrs: { class: "custom-tree-node" } }, [label, h('span', {}, [editToolTipBtn, removeToolTipBtn])])
                    }


                },
                appendData: function (node, data, store) {
                    this.formTitle = '增加兄弟节点';
                    this.dialogVisible1 = true;
                    this.editNode = node;
                    this.editType = "sibling";
                },
                appendChildData: function (node, data, store) {
                    this.formTitle = '增加子节点';
                    this.dialogVisible1 = true;
                    this.editNode = node;
                    this.editType = "child";
                },
                removeData: function (node, data) {
                    var parent = node.parent;
                    var children = parent.data.children || parent.data;
                    children.forEach(function (item, index) {
                        if (item.id == data.id) {
                            children.splice(index, 1);
                        }
                    })

                },
                editData: function (node, data) {
                    this.formTitle = '编辑节点';
                    this.dialogVisible1 = true;
                    this.editNode = node;
                    this.editType = "edit";
                    this.form.name = data.name;
                    this.form.icon = data.icon;
                },
                formSubmit: function () {
                    var _this = this;
                    _this.$refs['ruleForm'].validate(function (valid) {
                        if (valid) {
                            if (_this.editType == "sibling") {
                                var node = {
                                    "id": "",
                                    "name": _this.form.name,
                                    "icon": _this.form.icon,
                                    "children": []
                                }
                                if (_this.editNode.level == 1) {
                                    _this.editNode.parent.data.push(node)
                                } else {
                                    _this.editNode.parent.data.children.push(node)
                                }
                                _this.dialogVisible1 = false;
                            } else if (_this.editType == "child") {
                                var node = {
                                    "id": "",
                                    "name": _this.form.name,
                                    "icon": _this.form.icon,
                                    "children": []
                                }
                                _this.editNode.data.children.push(node)
                                _this.dialogVisible1 = false;
                            } else if (_this.editType == "edit") {
                                _this.editNode.data.name = _this.form.name;
                                _this.editNode.data.icon = _this.form.icon;
                                _this.dialogVisible1 = false;
                            }
                            _this.form = { "name": "", "icon": "" }
                            _this.$refs['ruleForm'].resetFields();
                        } else {
                            return false
                        }
                    })

                },
                cancelFormSubmit: function () {
                    this.$refs['ruleForm'].resetFields();
                    this.form = { "name": "", "icon": "" };
                    this.dialogVisible1 = false;
                },
                formAuth: function () {
                    this.$refs['ruleForm'].validate(function () { })
                },
                allowDrop: function (draggingNode, dropNode, type) {
                    if (draggingNode.level != dropNode.level) {
                        return false
                    }
                    else if (type == "inner") {
                        return false
                    } else {
                        return true
                    }


                },
            }
        })
    });
});
Vue.component('component-main', function (resolve, reject) {  //流程图
    $.get("./components/main.html").then(function (res) {
        resolve({
            template: res,
            props: [],
            data: function () {
                return {
                    mainCurrentIndex: 0,
                    thiseditMode: this.editMode,
                    dialogVisible: false,
                    imgDialogVisible: false,
                    jsonData: [],
                    imgSrc: ''
                }
            },
            created: function () {
                var _this = this;
                jsPlumb.ready(function () {
                    //store.dispatch('createProcess',{url:'common/data/data.json'});

                    //L.instance.ajaxData( 'common/data/data.json',function(res){
                    //store.commit('setProcessData',{"processData":res});
                    //store.dispatch('createViewProcess');
                    //})
                });
                $(document).on('conEdit', function (e, data, conn) {
                    _this.$prompt('label', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        inputValue: data

                    }).then(function (res) {
                        conn.getOverlay('label').setLabel(res.value);
                        conn.data.label = res.value;
                        _this.$message({
                            type: 'success',
                            message: '修改成功'
                        });
                    }).catch(function () {
                    });
                });
                _this.bus.$on('treeChange', function () {
                    _this.mainCurrentIndex = 0;
                });
            },
            methods: {

                mainTabSwitch: function (index) {
                    this.mainCurrentIndex = index;
                    if (index == 0) {
                        store.commit('setMode', { mode: 'view' });
                        this.$emit('changemode', false)
                        store.dispatch('createViewProcess');
                    } else if (index == 1) {
                        store.commit('setMode', { mode: 'edit' });
                        this.$emit('changemode', true)
                        store.dispatch('createProcess');
                        $(document).trigger('moduleChange')
                    }
                },
                saveData: function () {
                    var _this = this;
                    L.instance.getInstanceData(store.state.instance, function (datas, unableSave, unableSaveNode) {
                        if (unableSave) {
                            _this.$alert('存在未填写必填属性节点' + unableSaveNode + '，无法保存！', '警告', {
                                confirmButtonText: '确定',
                                type: 'warning',
                                callback: function () { }
                            });
                            return false
                        }

                        store.commit('setProcessData', { "processData": datas });
                        _this.$message({
                            message: '数据保存成功！',
                            type: 'success'
                        });
                    });


                },
                getJsonData: function () {
                    var _this = this;
                    L.instance.getInstanceData(store.state.instance, function (datas, unableSave, unableSaveNode) {
                        if (unableSave) {
                            _this.$alert('存在未填写必填属性节点' + unableSaveNode + '，请规范填写属性后进行预览！', '警告', {
                                confirmButtonText: '确定',
                                type: 'warning',
                                callback: function () { }
                            });
                            return false
                        }
                        var data = store.state.currentMenu;
                        data.flow = datas;
                        _this.jsonData = data;
                        _this.dialogVisible = true
                    });

                },
                domtoImage: function () {
                    var _this = this;
                    if (isIE()) {
                        this.$alert('不支持ie浏览器预览，请使用火狐或谷歌浏览器?', '提示', {
                            confirmButtonText: '确定',
                            type: 'warning',
                            callback: function () { }
                        });
                        return
                    }
                    L.domtoimage('container-id', function (result) {
                        _this.imgDialogVisible = true;
                        _this.imgSrc = result.src;
                    })
                },
                clearImage: function () {
                    L.instance.removeEditView(store.state.instance);
                }
            }
        })
    });
});
Vue.component('component-module', function (resolve, reject) {  //节点模型
    $.get("./components/module.html").then(function (res) {
        resolve({
            template: res,
            props: [],
            data: function () {
                return {
                    nodeModule: [],
                    copyNodeModule: [],
                    moduleConfig: {},
                    activeNames: [],
                    searchkeyWord: ''

                }
            },
            created: function () {
                var _this = this;
                this.moduleConfig = L.nodeConfig.module;
                $.ajax({
                    url: 'common/data/nodeModule.json',
                    type: 'get',
                    success: function (res) {
                        res.forEach(function (itemData) {
                            itemData.data.forEach(function (item) {

                                item.type = _this.moduleConfig[item.mode].type;
                                var background = 'background:' + _this.moduleConfig[item.mode].nodeStyle.background + ';';
                                var borderWidth = 'border-width:' + _this.moduleConfig[item.mode].nodeStyle.borderWidth + ';';
                                var borderColor = 'border-color:' + _this.moduleConfig[item.mode].nodeStyle.borderColor + ';';
                                var borderRadius = '';
                                item.height = _this.moduleConfig[item.mode].nodeStyle.height ? _this.moduleConfig[item.mode].nodeStyle.height : 70;
                                item.width = _this.moduleConfig[item.mode].nodeStyle.width ? _this.moduleConfig[item.mode].nodeStyle.width : 120;
                                if (item.type == 'Rect') {
                                    borderRadius = 'border-radius:' + _this.moduleConfig[item.mode].nodeStyle.borderRadius;
                                }
                                item.style = background + borderWidth + borderColor + borderRadius
                                if (item.type == 'Ellipse') {
                                    item.className = 'round'
                                }
                                if (item.type == 'Prismatic') {
                                    item.style = 'border:none;background:transparent'
                                    item.fillStyle = "fill:" + _this.moduleConfig[item.mode].nodeStyle.background + ';';
                                    item.fillStyle += "stroke-width:" + parseInt(_this.moduleConfig[item.mode].nodeStyle.borderWidth) + ';';
                                    item.fillStyle += "stroke:" + _this.moduleConfig[item.mode].nodeStyle.borderColor + ';';
                                }

                                item.fontStyle = "font-size:" + parseInt(_this.moduleConfig[item.mode].nodeStyle.font.fontSize) + "px;color:" + _this.moduleConfig[item.mode].nodeStyle.font.color + ";font-weight:" + _this.moduleConfig[item.mode].nodeStyle.font.fontWeight;
                                item.sourceEndPoint = _this.moduleConfig[item.mode].sourceEndPoint;
                                item.targetEndPoint = _this.moduleConfig[item.mode].targetEndPoint;
                            });
                        })


                        _this.nodeModule = res;
                        _this.copyNodeModule = JSON.parse(JSON.stringify(_this.nodeModule));
                        for (i = 0; i < _this.nodeModule.length; i++) {
                            _this.activeNames.push(i)
                        }
                    }

                })
            },
            methods: {
                searchModule: function () {
                    var _this = this;


                    var keyWord = this.searchkeyWord.toLowerCase();
                    var moduleData = JSON.parse(JSON.stringify(_this.copyNodeModule))
                    if (keyWord.length > 0) {
                        var newModule = [];
                        moduleData.forEach(function (item) {
                            var obj = {};
                            var append = false;
                            obj.name = item.name;
                            obj.data = [];
                            item.data.forEach(function (it) {
                                if (it.name.toLowerCase().indexOf(keyWord) > -1) {
                                    obj.data.push(it);
                                    append = true;
                                }
                            });
                            if (append) {
                                newModule.push(obj)
                            }
                        })
                        _this.nodeModule = newModule;
                    } else {
                        _this.nodeModule = moduleData;
                    }
                    var activeNames = [];
                    for (i = 0; i < _this.nodeModule.length; i++) {
                        activeNames.push(i)
                    }
                    _this.activeNames = activeNames

                },
                nodeMove: function (e, group, it) {
                    L.dragNodeExample(e, store.state.instance, group, it)
                }
            }
        })
    });
});
Vue.directive('scrollbar', {
    inserted: function (el) {
        $(el).mCustomScrollbar({
            'axis': $(el).attr('scroll-type') == 'xy' ? "yx" : "y",
            'theme': "dark",
            'scrollInertia': 200,
            'mouseWheelPixels': 100
        });
    }
})
L.vue = new Vue({
    el: '#app',
    store: store,
    data: {
        edit: false
    },
    created: function () {

    },
    methods: {
        changeMode: function (buer) {
            this.edit = buer
        }
    }
});
