L.nodeConfig = {
    module: {
        "mode-1": {
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "3px",
                "borderColor": "rgb(21, 1, 52)",
                "borderRadius": "0px",
                "background": "#F3F6F8",
                "font": {
                    "fontSize": "14px",
                    "color": "rgb(13, 1, 45)",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [],
            "template": ''
        },
        "mode-2": {
            "type": "Ellipse",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "x": 80,
                "y": 151,
                "borderWidth": "3px",
                "borderColor": "rgb(21, 1, 52)",
                "background": "rgb(243, 246, 248)",
                "font": {
                    "color": "rgb(13, 1, 45)",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }]
        },
        "mode-3": {
            "type": "Prismatic",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": 3,
                "borderColor": "rgb(21, 1, 52)",
                "background": "rgb(243, 246, 248)",
                "font": {
                    "color": "rgb(0, 0, 0)",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-4": {
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "3px",
                "borderColor": "rgb(21, 1, 52)",
                "background": "rgb(13, 1, 45)",
                "borderRadius": "0px",
                "font": {
                    "color": "rgb(255, 255, 255)",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-5": {
            "type": "Ellipse",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "3px",
                "borderColor": "rgb(21, 1, 52)",
                "background": "rgb(13, 1, 45)",
                "font": {
                    "color": "rgb(255, 255, 255)",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-6": {
            "type": "Prismatic",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": 3,
                "borderColor": "rgb(21, 1, 52)",
                "background": "rgb(13, 1, 45)",
                "font": {
                    "color": "rgb(255, 255, 255)",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-7": {
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "3px",
                "borderColor": "rgb(21, 1, 52)",
                "borderRadius": "0px",
                "background": "#F3F6F8",
                "font": {
                    "fontSize": "14px",
                    "color": "rgb(13, 1, 45)",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template": "<div class='node-mode-wrap'><div class='node-mode-icon'><i class='el-icon-picture-outline'></i></div><div class='node-mode-content'>{{content}}</div></div>"
        },
        "mode-8": {
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "3px",
                "borderColor": "rgb(21, 1, 52)",
                "background": "rgb(13, 1, 45)",
                "borderRadius": "0px",
                "font": {
                    "color": "rgb(255, 255, 255)",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template": "<div class='node-mode-wrap dark'><div class='node-mode-icon'><i class='el-icon-picture-outline'></i></div><div class='node-mode-content'>{{content}}</div></div>"

        },

    },
    edit: {
        Rect: {
            selectOption: [{
                    value: "Top",
                    text: "上"
                },
                {
                    value: "Bottom",
                    text: "下"
                },
                {
                    value: "Left",
                    text: "左"
                },
                {
                    value: "Right",
                    text: "右"
                },
                {
                    value: "TopLeft",
                    text: "左上"
                },
                {
                    value: "BottomLeft",
                    text: "左下"
                },
                {
                    value: "TopRight",
                    text: "右上"
                },
                {
                    value: "BottomRight",
                    text: "右下"
                }
            ]

        },
        Ellipse: {
            selectOption: [{
                    value: "Top",
                    text: "上"
                },
                {
                    value: "Bottom",
                    text: "下"
                },
                {
                    value: "Left",
                    text: "左"
                },
                {
                    value: "Right",
                    text: "右"
                }
            ]
        },
        Prismatic: {
            selectOption: [{
                    value: "Top",
                    text: "上"
                },
                {
                    value: "Bottom",
                    text: "下"
                },
                {
                    value: "Left",
                    text: "左"
                },
                {
                    value: "Right",
                    text: "右"
                }
            ]
        }
    }
}