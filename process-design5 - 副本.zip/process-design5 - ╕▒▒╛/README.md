文件说明

plugins
browser-polyfill   填平旧浏览器对HTML5支持上的缺陷，用于兼容ie；
customscrollbar    自定义滚动条插件；
dom-to-image       html转换图片插件；
vue                MVC框架，用于页面结构生成和渲染；
zTree              树插件；
jsplumb            流程图核心插件，用于画线和画端点；
jquery-slidePanel  侧边弹出框插件；
jquery 			   jquery插件；
font-awesome       字体图标插件
