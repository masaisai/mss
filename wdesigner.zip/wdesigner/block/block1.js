
L.block={ 
	Rect:function(option,instance){
		var _this=this;
		_this.defaults={
			id:"",
			wrapId:"",
			top:0,
			left:0,
			background:'#fff',
			border:"1px solid blue",
			hoverBorder:"1px solid red",
			width:"100",
			height:"50",
			minHeight:'30px',
			minWidth:'30px'
		};
		option=$.extend(true,{},_this.defaults,option);
		_this.model=$('<div id="'+option.id+'" class="node" style="position:absolute;top:'+parseFloat(option.top)+'px;left:'+parseFloat(option.left)+'px;background:'+option.background+';width:'+option.width+'px;height:'+option.height+'px;border:'+option.border+';min-height:'+option.minHeight+';min-width:'+option.minWidth+'" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		_this.model.appendTo($("#" + option.wrapId));
		_this.model.hover(function(){
			$(this).css({"border":option.hoverBorder});
		},function(){
			$(this).css({"border":option.border});
		});
		_this.model.on('click',function(e){
		e.stopPropagation();
		for(var i=0;i<_this.allEditElement.length;i++){
				_this.allEditElement[i].remove()
			}
			_this.editBox(this,option.wrapId,instance);
		})
	},
	allEditElement:[],
	editBox:function(obj,wrapId,instance){
		var _this=this;
		var height=$(obj).outerHeight();
		var width=$(obj).outerWidth();
		var left=$(obj).position().left;
		var top=$(obj).position().top;
		var $editBox=$('<div class="editBox" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $removeBtn=$('<a style="position:absolute;right:0;top:0;z-index:99999999999;cursor:pointer;user-select:none;" onselectstart="return false;" style="-moz-user-select: none;">x</a>');
		$editBox.append($removeBtn);
		$editBox.css({
			position:'absolute',
			width:width+8+'px',
			height:height+8+'px',
			left:-6+'px',
			top:-6+'px',
			border:'1px solid #ddd',
			'zIndex':999999,
			'min-height':'38px',
			'min-width':'38px'
		});

		var $ltresize=$('<div class="resize lt" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $tresize=$('<div class="resize t" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $rtresize=$('<div class="resize rt" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $rresize=$('<div class="resize r" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $rbresize=$('<div class="resize rb" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $bresize=$('<div class="resize b" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $lbresize=$('<div class="resize lb" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $lresize=$('<div class="resize l" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		$editBox.append($ltresize);
		$editBox.append($tresize);
		$editBox.append($rtresize);
		$editBox.append($rresize);
		$editBox.append($rbresize);
		$editBox.append($bresize);
		$editBox.append($lbresize);
		$editBox.append($lresize);
		$editBox.appendTo($(obj));
		/*左上*/
		$ltresize.on('mousedown',function(e){
			instance.repaintEverything();
			//instance.droppable($('.node'))
			e.stopPropagation();
			var posX=$(obj).offset().left-5;
			var posY=$(obj).offset().top-5;
			var width=$(obj).outerWidth();
			var height=$(obj).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=posX-pageX;
				var oY=posY-pageY;
				$(obj).css({
					width:width+oX+'px',
					height:height+oY+'px',
					left:posX+5-oX+'px',
					top:posY+5-oY+'px'
				});
				$editBox.css({
			width:width+oX+10+'px',
			height:height+oY+10+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				
			})
		});
		/*上*/
		$tresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var posY=$(obj).offset().top-5;
			var height=$(obj).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageY=e.pageY;
				var oY=posY-pageY;
				$(obj).css({
					height:height+oY+'px',
					top:posY+5-oY+'px'
				});
				$editBox.css({
			height:height+oY+10+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
			})
		});
	/*右上*/	
	$rtresize.on('mousedown',function(e){
		instance.repaintEverything();
		e.stopPropagation();
			var posX=$(obj).offset().left-5;
			var posY=$(obj).offset().top-5;
			var width=$(obj).outerWidth();
			var height=$(obj).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=pageX-posX;
				var oY=posY-pageY;
				$(obj).css({
					width:oX-10+'px',
					height:height+oY+'px',
					top:posY+5-oY+'px'
				});
				$editBox.css({
			width:oX+'px',
			height:height+oY+10+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
			})
		});	
		/*右*/
			$rresize.on('mousedown',function(e){
				instance.repaintEverything();
				e.stopPropagation();
			var posX=$(obj).offset().left-5;
			var width=$(obj).outerWidth();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var oX=pageX-posX;
				$(obj).css({
					width:oX-10+'px',
				});
				$editBox.css({
			width:oX+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
			})
		});
		/*右下*/
		$rbresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var posX=$(obj).offset().left-5;
			var posY=$(obj).offset().top-5;
			var width=$(obj).outerWidth();
			var height=$(obj).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=pageX-posX;
				var oY=pageY-posY;
				$(obj).css({
					width:oX-10+'px',
					height:oY-10+'px'
				});
				$editBox.css({
			width:oX+'px',
			height:oY+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
			})
		});
		/*下*/
		$bresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var posY=$(obj).offset().top-5;
			var height=$(obj).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageY=e.pageY;
				var oY=pageY-posY;
				$(obj).css({
					height:oY-10+'px'
				});
				$editBox.css({
			height:oY+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
			})
		});
		/*左下*/
		$lbresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var posX=$(obj).offset().left-5;
			var posY=$(obj).offset().top-5;
			var width=$(obj).outerWidth();
			var height=$(obj).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=posX-pageX;
				var oY=pageY-posY;
				$(obj).css({
					width:width+oX+'px',
					height:oY-10+'px',
					left:posX+5-oX+'px'
				});
				$editBox.css({
			width:width+oX+10+'px',
			height:oY+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
			})
		});
		/*左*/
		$lresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var posX=$(obj).offset().left-5;
			var width=$(obj).outerWidth();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var oX=posX-pageX;
				$(obj).css({
					width:width+oX+'px',
					left:posX+5-oX+'px'
				});
				$editBox.css({
			width:width+oX+10+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
			})
		});
		_this.allEditElement.push($editBox);
		$editBox.on('click',function(e){
			e.stopPropagation()
		});
		$removeBtn.on('click',function(e){
			e.stopPropagation();
			$editBox.remove();
			$(obj).remove();
			var nodeAttr=$(obj).get(0).nodeAttr;
			for(var i=0;i<nodeAttr.conn.length;i++){
				L.deleteConnection(instance,nodeAttr.conn[i]);
			}
			console.log($(obj).get(0).nodeAttr)
			instance.deleteEndpoint(nodeAttr.endPoint[0])
			
		});
		$(document).off('click');
		$(document).on('click',function(e){
			for(var i=0;i<_this.allEditElement.length;i++){
				_this.allEditElement[i].remove()
			}
		})
	}
}
