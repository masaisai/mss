	L.title=function(){
		$.fn.title=function(type){
				return $(this).each(function(){
					if($(this).hasClass('disabled')||$(this).parents().hasClass('disabled')){return false};
					if($(this).hasClass('hasDataTitleTip')){
						if(type=="destory"){
						this.box.remove();
						$(this).removeClass('hasDataTitleTip');
					}
						return false;
					}else{
						$(this).addClass('hasDataTitleTip');
					
					var _this=this;
					_this.content=$(_this).attr("data-title");
					if((!type)&&_this.content){
					_this.posX=$(this).offset().left+($(this).outerWidth()/2);
					_this.posY=$(this).offset().top;
					_this.arrow=$('<div style="display:block;background:#333;position:absolute;width:8px;height:8px;bottom:-4px;transform:rotate(45deg);-ms-transform:rotate(45deg); z-index:999"></div>');
					_this.box=$('<div class="titleTip" style="display:inline-block;background:#333;opacity:0.9"></div>');
					_this.box.append(_this.arrow);
					_this.box.append(_this.content);
					$('body').append(_this.box);
					_this.box.css({
						"position":"absolute",
						"padding":"5px 12px",
						"line-height":"20px",
						"border":"1px solid #333",
						"border-radius":"4px",
						"z-index":"999",
						"color":"white",
						"box-shadow":"2px 4px 10px rgba(0,0,0,0.2)"
					});
					_this.pwidth=_this.box.outerWidth();
					_this.pheight=_this.box.height();
					_this.pleft=_this.posX-(_this.pwidth/2)+"px";
					_this.ptop=_this.posY-_this.pheight-18+"px";
					_this.arrow.css({"left":_this.pwidth/2-5+"px"});
					_this.box.css({
						"top":_this.ptop,
						"left":_this.pleft
					});
					}
					}
				})
			}
		$(document).on('mouseenter','[data-title]',function(){
			$(this).title();
		});
		$(document).on('mouseleave','[data-title]',function(){
			$(this).title("destory");
			$(".titleTip").remove();
			$(".hasDataTitleTip").removeClass('hasDataTitleTip');
		});
		$(document).on('click',function(){
			$(this).title("destory");
			$(".titleTip").remove();
			$(".hasDataTitleTip").removeClass('hasDataTitleTip');
			
		});
		
		
	}
	L.title();
$.fn.setContent=function(html){
	return this.each(function(){
		if($(this).find('.node-content').hasClass('node-content')){
			$(this).find('.node-content').html(html)
		}
	})
}
