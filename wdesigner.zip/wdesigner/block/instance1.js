var L={};
L.instance =function(option){
	var defaults={      
    Connector : ["Flowchart",{stub: [0,0], gap:4, cornerRadius:0, alwaysRespectStubs:false}],//Flowchart、Bezier、Straight
    DragOptions : { cursor: "pointer", zIndex:2000 },
    PaintStyle : { 
    strokeWidth:1, 
    stroke:"#37474F"
  },
    EndpointStyle : { radius:5, fill:'#000' },
    HoverPaintStyle :{ 
    stroke: "#ff4c52", strokeWidth:1, outlineStroke: "transparent", outlineWidth:10
  },
  
    EndpointHoverStyle : {fill:"#FF4C52" },
    ConnectionOverlays:[[ "Arrow", { location:1 ,length:10, foldback:0.6, fill:'#000', width:8,visible:true} ],[ "Custom",{create:function(component) {
    	$remove=$("<div style='width:20px;height:20px;line-height:18px;text-align:center;cursor:pointer;border-radius:50%;background:#000;color:#fff;padding:0'>x</div>");
        return $remove;                
      },
      cssClass:'hidden',
      location:0.9,
      id:"customOverlay",
      hoverClass:'show',events:{
       "click":function(custom, evt) {
       L.deleteConnection(custom._jsPlumb.instance,custom._jsPlumb.component)
       }}
    } ],
  
    ["Label",{label:'label', id:'label',cssClass:'aLabel',hoverClass:'show',events:{
       "click":function(label, evt) {
        console.log(label)
       }}}]],
    Container:"container-id"
 };
  
 option=$.extend(true,{},defaults,option);
	return jsPlumb.getInstance(option);
}
L.addNode=function(instance,type,nodeId, position,width,height,borderWidth,borderColor,background) {
 L.block.Model({
 	type:type,
 	id:nodeId,
 	wrapId:Object.getPrototypeOf(instance).Defaults.Container,
 	top:position.y,
 	left:position.x,
 	width:width,
 	height:height,
 	borderWidth:borderWidth,
 	borderColor:borderColor,
 	background:background
 },instance)
  return jsPlumb.getSelector('#' + nodeId)[0];
}
L.addPorts=function(instance, node, ports, type) {
  var number_of_ports = ports.length;
  var i = 0;
  var height = $(node).height(); 
  var y_offset = 1 / ( number_of_ports + 1);
  var y = 0;
 
  for ( ; i < number_of_ports; i++ ) {
    var anchor = [0,0,0,0];
    var paintStyle = { radius:5, fill:'#ff4c52' };
    var isSource = false, isTarget = false;
    if ( type === 'output' ) {
      anchor[0] = 1;
      paintStyle.fill = '#6DA611';
      isSource = true;
    } else {
      isTarget =true;
    }
 
    anchor[1] = y + y_offset;
    y = anchor[1];
    var ee=instance.addEndpoint(node, {
      uuid:ports[i],
      paintStyle: paintStyle,
      anchor:anchor,
      maxConnections:-1,
      isSource:isSource,
      isTarget:isTarget,
      detachable:true
    });
    return ee
  }
}
L.addSourceEndpoint=function(instance,name){
	var e1 = instance.addEndpoint(name, {
    isSource:true,
    maxConnections:-1,
    anchor:[1,0.5],
    paintStyle:{ radius:5, fill:'#FF8891' },
    detachable:false,
    parameters:{}
});
return e1;
}
L.addTargetEndpoint=function(instance,name){
	var e1 = instance.addEndpoint(name, {
    isTarget:true,
    anchor:[0,0.5],
    paintStyle:{ radius:5, fill:'#D4FFD6' },
    detachable:false,
    parameters:{}
});
return e1;
}
L.connect=function(instance,source,target,sourceNode,targetNode,label){
	var conn=instance.connect({source:source, target:target,overlays:[["Label",{label:label, id: sourceNode+targetNode+'label'}]]});
	return conn;
}
L.connectPorts=function(instance, node1, sourceUuid, node2,targetUuid,label) {
  overlays = [
   
    ["Label",{label:label}]
  ];
 
var conn=instance.connect({
  	//overlays:overlays,
  	uuids:[sourceUuid,targetUuid],
  	parameters:{
        "label":label
    }
  });

  return conn;
  
}
L.reConnectPorts=function(instance, node1, port1, node2 , port2,label) {
  var color = "gray";
  var arrowCommon = { foldback:0.8, fill:color, width:10 },
  overlays = [
    [ "Arrow", { location:1 ,length:10}, arrowCommon ],
    ["Label",{label:label}]
  ];
 
  var uuid_source = node1 + "-" + port1;
  var uuid_target = node2 + "-" + port2;
 
var conn=instance.connect({
  	overlays:overlays,
  	uuids:[uuid_source, uuid_target]
  });
  return conn;
}
L.deleteConnection=function(instance,conn){
	instance.deleteConnection(conn);
}
 
 
