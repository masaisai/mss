function isIE() {
	 if (!!window.ActiveXObject || "ActiveXObject" in window)
	  {return true;}
	  else
	 { return false;}
	 }
	
	/*悬浮title插件，样式同element-ui tooltip大致相同*/
	L.title=function(){
		$.fn.title=function(type){
				return $(this).each(function(){
					if($(this).hasClass('disabled')||$(this).parents().hasClass('disabled')){return false};
					if($(this).hasClass('hasDataTitleTip')){
						if(type=="destory"){
						this.box.remove();
						$(this).removeClass('hasDataTitleTip');
					}
						return false;
					}else{
						$(this).addClass('hasDataTitleTip');
					
					var _this=this;
					_this.content=$(_this).attr("data-title");
					if((!type)&&_this.content){
					_this.posX=$(this).offset().left+($(this).outerWidth()/2);
					_this.posY=$(this).offset().top;
					_this.arrow=$('<div style="position:absolute;width:0px;height:0px;bottom:-12px;border:6px solid black;border-left:6px solid transparent;border-bottom:6px solid transparent;border-right:6px solid transparent; z-index:999"><div style="width:0px;height:0px;margin-top:-6px;margin-left:-5px; border:5px solid white;border-left:5px solid transparent;border-bottom:5px solid transparent;border-right:5px solid transparent;"></div></div>');
					_this.box=$('<div class="titleTip" style="display:inline-block;background:#ffffff;pointer-events:none;"></div>');
					_this.box.append(_this.arrow);
					_this.box.append(_this.content);
					$('body').append(_this.box);
					_this.box.css({
						"position":"absolute",
						"padding":"5px 12px",
						"line-height":"20px",
						"border":"1px solid #000000",
						"border-radius":"4px",
						"z-index":"9999",
						"color":"#000000"
					});
					_this.pwidth=_this.box.outerWidth();
					_this.pheight=_this.box.height();
					_this.pleft=_this.posX-(_this.pwidth/2)+"px";
					_this.ptop=_this.posY-_this.pheight-18+"px";
					_this.arrow.css({"left":_this.pwidth/2-7+"px"});
					_this.box.css({
						"top":_this.ptop,
						"left":_this.pleft
					});
					}
					}
				})
			}
		$(document).on('mouseenter','[data-title]',function(e){
			$(this).title();
		});
		$(document).on('mouseleave','[data-title]',function(e){
			$(this).title("destory");
			$(".titleTip").remove();
			$(".hasDataTitleTip").removeClass('hasDataTitleTip');
		});
		$(document).on('click',function(){
			$(this).title("destory");
			$(".titleTip").remove();
			$(".hasDataTitleTip").removeClass('hasDataTitleTip');
			
		});
		
		
	}
	/*{{}}模板解析*/
	L.compileTemple=function(content,propertys){
		var reg=new RegExp('{{(.*?)}}', "g");
		var string=content;
		var strArr=string.match(reg);
		var newStrArr=[];
		
		if(strArr&&strArr.length>0){
			strArr.forEach(function(item,index){
				var newStr=item.substring(2);
				var len=newStr.length;
				newStr=newStr.substring(0,len-2);
				newStrArr.push(newStr)
			   });
			var proObj={};
			for(var i=0;i<propertys.length;i++){
					proObj[propertys[i].key]=propertys[i].value
			}
				newStrArr.forEach(function(item){
				if(proObj[item]){
					string=string.replace("{{"+item+"}}",proObj[item])
				}
			});
		}
		return string;
	}
	/*两侧边窗口尺寸调整*/
	L.homeResize=function(){
				$('[data-plugin="resize"]').each(function(){
			var $resize=$('<div class="rx-resize"></div>');
			var direction=$(this).data('resize');
			if(!direction){
				return false;
			}else if(direction=='right'){
				$resize.addClass('resize-right');
			}else if(direction=='left'){
				$resize.addClass('resize-left');
			}else if(direction=='top'){
				$resize.addClass('resize-top');
			}
			$(this).append($resize)
			var _this=this;
			$resize.mousedown(function(e){
				$resize.addClass('active');
				var width=$(_this).outerWidth();
				var height=$(_this).outerHeight();
				var pageX=e.pageX;
				var pageY=e.pageY;
				$(document).bind('mousemove',function(e){
					var page1X=e.pageX;
					var page1Y=e.pageY;
					if(direction=='right'){
						var width1=page1X-pageX+width;
					if(width1>=500){
						width1=500
					}else if(width1<=100){
						width1=100
					}
					$(_this).css({
						"width":width1+'px'
					});
						$('.rx-container').css({
						'padding-left':width1+'px'
					})
					
					
					}else if(direction=='left'){
						var width1=pageX-page1X+width;
					if(width1>=500){
						width1=500
					}else if(width1<=100){
						width1=100
					}
					$(_this).css({
						"width":width1+'px'
					});
						$('.rx-container2').css({
						'padding-right':width1+'px'
						});
					}else if(direction=='top'){
						var height1=pageY-page1Y+height;
						if(height1>=500){
						height1=500
					}else if(height1<=100){
						height1=100
					}
						
						$(_this).css({
						"height":height1+'px'
					});
						$('.rx-container1').css({
						'padding-bottom':height1+'px'
					})
					}
					resetNotePos()
				});
				
				$(document).bind('mouseup',function(e){
					$(document).unbind('mousemove');
					$(document).unbind('mouseup');
					$resize.removeClass('active');
				})
			})
		})
	}
	/*右侧标题拖拽时显示节点*/
	   	L.dragNodeExample=function(e,instance,group,it){
			   
			   var $this=this;
			   var config=L.nodeConfig.module[group.mode];
			   var contentParams=[{key:"content",value:it.name}];
			   var content=it.name;
			   if(config.template){
				  content=L.compileTemple(config.template,contentParams)
			   }
  		var $node=$(e.currentTarget);
		  var $body=$('body');
  		var nodeLeft=$node.offset().left;
  		var nodeTop=$node.offset().top;
  		var nodeWidth=it.width||120;
  		var nodeHeight=it.height||70;
  		var pageX=e.pageX;
		  var pageY=e.pageY;
		  var $nodeExample=$('<div class="rx-node-example '+it.className+'" style="z-index:99999;position:relative;'+it.style+'"></div>');
		  var $nodeExampleContent=$('<div class="node-example-content"></div>');
		  var $svg='';
		  if(it.type=='Prismatic'){
			  $svg=$('<svg width="120" height="70" class="prismatic" version="1.1" xmlns="http://www.w3.org/2000/svg" ><polygon style="'+it.fillStyle+'" points="2,35 59,2 118,35 59,68"/></svg>');
			  $nodeExampleContent.append($svg)
		  }
		  
		  var $nodeExampleText=$('<span class="node-example-text" style="'+it.fontStyle+'">'+content+'</span>');
		  $nodeExampleContent.append($nodeExampleText)
		  if(it.sourceEndPoint){
			for(var i=0;i<it.sourceEndPoint.length;i++){
				$nodeExampleContent.append($('<div class="rx-node-sourceEndpoint '+it.sourceEndPoint[i].position+'"></div>'));
			  }
		  }
		  if(it.targetEndPoint){
			for(var i=0;i<it.targetEndPoint.length;i++){
				$nodeExampleContent.append($('<div class="rx-node-targetEndpoint '+it.targetEndPoint[i].position+'"></div>'));
			  }
		  }
		  
		  $nodeExample.append($nodeExampleContent);
  		$nodeExample.css({
  			position:'absolute',
  			left:nodeLeft+'px',
  			top:nodeTop+'px',
  			width:nodeWidth+'px',
  			height:nodeHeight+'px'
  		});
  		$(document).bind('mousemove',function(e){
  			var pageX1=e.pageX;
  			var pageY1=e.pageY;
  			$nodeExample.css({
  			left:nodeLeft+(pageX1-pageX)+'px',
  			top:nodeTop+(pageY1-pageY)+'px'
  		});
  		});
  		$(document).bind('mouseup',function(e){
  			var nodeExampleLeft=$nodeExample.offset().left;
  			var nodeExampleTop=$nodeExample.offset().top;
  			var cl=$('.rx-main').offset().left;
  			var ct=$('.rx-main').offset().top;
  			var cr=cl+$('.rx-main').outerWidth();
  			var cb=ct+$('.rx-main').outerHeight();
  			if(nodeExampleLeft>=cl&&nodeExampleTop>=ct&&nodeExampleLeft<=cr-100&&nodeExampleTop<=cb-50){
  				
  				var data={
  					width:nodeWidth,
  					height:nodeHeight,
  					left:nodeExampleLeft-$('#container-id').offset().left,
  					top:nodeExampleTop-$('#container-id').offset().top
  				}
  				
  				$(instance).trigger('addDargNode',{data:data,group:group})
  			}
  			$nodeExample.remove()
  			$(document).unbind('mousemove');
  			$(document).unbind('mouseup');
  		
  		})
   		$body.append($nodeExample);
  	}
	

   	
$(function(){
	L.title();
	L.homeResize();
});
/*dom转成图片*/
L.domtoimage=function(id,fun){
var node = document.getElementById(id);
domtoimage.toPng(node)
  .then(function (dataUrl) {
	  var img = new Image();
	  img.src = dataUrl;
	  if(fun){
		  fun({
			  src:dataUrl,
			  img:img
		  })
	  }
  })
  .catch(function (error) {
      console.error('oops, something went wrong!', error);
  });
    //domtoimage.toBlob(document.getElementById('container-id'))
   // .then(function (blob) {
    //    window.saveAs(blob, 'my-node.png');
   // });
}
/*instance解绑事件*/
function instanceUnbindEvent(instance) {
	instance.unbind("connection");
	instance.unbind("click");
	instance.unbind("dblclick");
	instance.unbind("beforeDrop");
	instance.unbind("connectionDetached");
	$(instance).unbind('addDargNode');
	$(instance).unbind('nodeRemoved');
	$(instance).unbind('nodeEdit');
}
/*instance绑定事件*/
function instanceBindEvent(instance) {
			
	instance.bind("connection", function(conn, originalEvent) {
		$(conn.connection.getOverlay('label').getElement()).removeClass('hidden');
		if(!conn.connection.getOverlay('label').labelText){
			conn.connection.getOverlay('label').setVisible(false);
		}
		if(!conn.connection.getParameter("init")) {
			var lineData = {
				"type": "Line",
				"sourceId": conn.sourceId,
				"targetId": conn.targetId,
				"sourceEndPointUuid": conn.sourceEndpoint.getUuid(),
				"targetEndPointUuid": conn.targetEndpoint.getUuid(),
				"label": conn.connection.getOverlay('label').labelText
			}
			
			conn.connection.data=lineData;
			
			//store.state.processData.push(lineData);
		}
		
	});
	instance.bind("click", function(conn, originalEvent){});
	instance.bind("dblclick", function(conn, originalEvent) {
		var label=conn.getOverlay('label').label;
		//var name=prompt("label",label);
		//conn.getOverlay('label').setLabel(name);
		//conn.data.label=name;
		$(document).trigger('conEdit',[label,conn])
	});
	instance.bind("beforeDrop", function(conn) {
		if(instance.select({
				source: conn.sourceId,
				target: conn.targetId
			}).length >= 1) {
			return false;
		}
		return true;
	});
	
	/*拖拽至画布的节点生成事件*/
	$(instance).bind('addDargNode', function(e, result) {
		
		var nodeId=createNodeId();
		function createNodeId(){
			var id="node-"+parseInt(Math.random()*100000000);
			var len=L.instance.nodes.length;
			for(var i=0;i<len;i++){
				if(id==L.instance.nodes[i]){
					id=createNodeId();
				}
			}
			return id;
		}

		 var config=L.nodeConfig.module[result.group.mode];
		 var contentParams=[{key:"content",value:result.group.name}];
		 var content=result.group.name;
		 
		 if(config.template){
			content=L.compileTemple(config.template,contentParams)
		 }
		
		var data = {
			"type":config.type,
			"nodeId":nodeId,
			"nodeStyle": {
				"x": result.data.left,
				"y": result.data.top,
				"width":result.data.width,
				"height": result.data.height,
				"background": config.nodeStyle.background,
				"borderWidth": config.nodeStyle.borderWidth,
				'borderColor': config.nodeStyle.borderColor,
				"font":config.nodeStyle.font
			},
			"sourceEndPoint": config.sourceEndPoint||[],
			"targetEndPoint":config.targetEndPoint||[],
			"content":content,
			"propertys":{}
		}
		
		if(config.type=='Rect'||config.type=='Note'){
			data.nodeStyle.borderRadius= config.nodeStyle.borderRadius;
		}
		data.sourceEndPoint.forEach(function(item){
			item.type='source';
			item.uuid= nodeId+"-out-"+parseInt(Math.random(0,1)*10000000);
			if(typeof item.position=='undefined'||!item.position){
				item.position='Right';
			}
		});
		
		data.targetEndPoint.forEach(function(item){
			item.type='target';
			item.uuid= nodeId+"-out-"+parseInt(Math.random(0,1)*10000000);
			if(typeof item.position=='undefined'||!item.position){
				item.position='Left';
			}
		});
	
		data.groupId=result.group.id;
		/*var xhr = new XMLHttpRequest();
		xhr.open('get',"./common/data/module/"+node.data.groupId+".json",true);
		xhr.send(null);
		xhr.onreadystatechange = function(){
		if(xhr.readyState == 4 && xhr.status == 200){
			
			var res=JSON.parse(JSON.stringify(xhr.responseText));
			console.log(res)
				}
		}*/
		if(data.type=='Note'){
			L.instance.createNode(instance,data,"",{})
					instance.draggable($('#'+nodeId), {
						containment: true
				});
		}else{
			$.ajax({
				url:"common/data/module/"+data.groupId+".json",
				get:'get',
				success:function(res){
					var propertys =res.attribute;
				for(var i=0;i<propertys.length;i++){
					data.propertys[propertys[i].name]=propertys[i].defaultValue;
				}
				L.instance.createNode(instance,data,"",propertys)
						instance.draggable($('#'+nodeId), {
							containment: true
					});
			}
		});
		}
		
						
					
	});
	
	$(instance).bind('nodeRemoved', function(e, node, data) {});
	/*节点编辑*/
	$(instance).bind('nodeEdit', function(e, node, data) {
		
		//要转换为图片的dom对象
   L.instance.currentNode=node;
   if(node.data.type=='Note'){
	Vue.prototype.bus.$emit('editNote',{'textarea':node.data.content});
   }else{
	var name=node.data.content.replace(/<[^>]+>/g,"");
	var groupId=node.data.groupId;
	window.top.mInstance=instance;
	window.top.mNode=node;
	L.sidePop.open('components/propertys/'+groupId+'.html','编辑节点',{instance:window.top.mInstance,node:window.top.mNode},function(){
	 
 })
   }
   
	});

	
}			
