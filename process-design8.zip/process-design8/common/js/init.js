Vue.use(Vuex);
L.sidePop({"width":"600"});
	/*store存储全局数据*/
		var store=new Vuex.Store({
			state:{
				mode:'view',
				viewInstance:null,
				instance:null,
				processData:[],
				currentMenu:[],
				width:2000,
				height:1000
			
			},
			mutations: {
				setMode:function(state,params){ 
					state.mode=params.mode;
				},
				setWidth:function(state,params){ 
					state.width=params.width;
				},
				setHeight:function(state,params){ 
					state.height=params.height;
				},
				setInstance:function(state,params){ //设置编辑模式instance
					state.instance=params.instance;
				},
				setViewInstance:function(state,params){ //设置视图模式instance
					state.viewInstance=params.instance;
				},
				setProcessData:function(state,params){ //全局保存ajax数据
					state.processData=params.processData;
				},
				setCurrentMenu:function(state,params){
					state.currentMenu=params.currentMenu;
				}
  			},
  			actions: {
  				clearProcess:function(content,params){
					if(content.state.viewInstance){
						L.instance.removeView(content.state.viewInstance);
						content.commit('setViewInstance',{instance:null});
					}
				if(content.state.instance){
						L.instance.removeEditView(content.state.instance);
						instanceUnbindEvent(content.state.instance);
						content.commit('setInstance',{instance:null});
					}
				  },
  				createViewProcess:function(content,params) {  //创建视图模式
					this.dispatch('clearProcess');
					var instance=L.instance.viewInit({Container:"container-id",Connector: ["Bezier",{ stub: [20, 20], gap: 0,curviness:100, cornerRadius:0, alwaysRespectStubs:false }]});
   				 	L.instance.createView(instance,this.state.processData);
 					content.commit('setInstance',{instance:instance});
   			 		},
   				 createProcess:function(content,params) { //创建编辑模式
					this.dispatch('clearProcess');
					var instance=L.instance.init({Container:"container-id",Connector: ["Bezier",{ stub: [20, 20], gap: 10,curviness:100, cornerRadius:0, alwaysRespectStubs: false }]});
					instanceBindEvent(instance);
   				 	L.instance.createEditView(instance,this.state.processData);
 					content.commit('setInstance',{instance:instance});
   			 		}
   			 	}
		});
		/*创建事件绑定器*/
		var bus = new Vue();
		Vue.prototype.bus = bus;
		/*左边菜单组件*/
		Vue.component('component-sidebar', function(resolve, reject){  //侧边菜单
            $.get("./components/sidebar.html").then(function(res) {  
                resolve({  
                    template: res,  
                    props: [],  
                    data:function(){
                    	return {
							
							menuData:[],
							menuTreeData:[],
							active:"1-1",
							dialogVisible:false,
							dialogVisible1:false,
							defaultProps:{
          						children: 'children',
         					 	label: 'name'
								},
								formTitle:"",
								form:{
								"name":"",
								"icon":""
								},
								rules: {
          							name: [
           							 { required: true, message: '请输入菜单名称', trigger: 'blur' }
          							]
        						},
							editNode:"",
							editType:""
						}
                    },
                    created:function(){
						var _this=this;
                    	$.get('common/data/apply.json').then(function(result){
							_this.menuData=result;
							_this.menuTreeData=JSON.parse(JSON.stringify(_this.menuData));
							jsPlumb.ready(function() {
								var activeArr=_this.active.split('-');
								store.commit('setCurrentMenu',{currentMenu:_this.menuData[activeArr[0]].children[activeArr[1]]});
							var id=_this.menuData[activeArr[0]].children[activeArr[1]].id;
								L.instance.ajaxData( 'common/data/data.json?id='+id,function(res){
									store.commit('setProcessData',{"processData":res.flow});
									store.commit('setWidth',{"width":res.width});
									store.commit('setHeight',{"height":res.height});
									store.dispatch('createViewProcess');
									_this.bus.$emit('treeInit');
								})
							
							
                    	});
        					});
					},
					mounted:function(){
					//setTimeout(function(){
					//	$('.el-menu .el-submenu .el-submenu__title').click();
				//	},100)
					},
                    methods: {
    					
    					nodeSelect:function(res,active) {
							var _this=this;
							_this.active=active;
							store.commit('setCurrentMenu',{currentMenu:res});
							if(res.id){
								L.instance.ajaxData( 'common/data/data.json?id='+res.id,function(res){
									store.commit('setProcessData',{"processData":res.flow});
									store.commit('setWidth',{"width":res.width});
									store.commit('setHeight',{"height":res.height});
									store.commit('setMode',{mode:'view'});
									_this.$emit('changemode',false);
									_this.bus.$emit('treeChange');
									store.dispatch('createViewProcess');
									
								});
							}
							else{
								store.dispatch('clearProcess');
							}
							},
							editMenu:function(){
								this.dialogVisible=true
							},
							menuDataChange:function(){
								this.menuData=JSON.parse(JSON.stringify(this.menuTreeData));
								this.dialogVisible=false
							},
							cancelDataChange:function(){
								this.menuTreeData=JSON.parse(JSON.stringify(this.menuData));
								this.dialogVisible=false
							},
							renderContent:function(h,res){
							var _this=this;
							
							var label=h('span',{domProps: {innerHTML:"<span><i class='"+res.data.icon+"' style='margin-right:4px'></i>"+res.data.name+"</span>"}});
							
							var appendBtn=h('button',{attrs:{type:'button','data-title':"增加兄弟节点"},on:{click:function(){_this.appendData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-circle-plus-outline"></i>'}});
							var appendChildBtn=h('button',{attrs:{type:'button','data-title':"增加子节点"},on:{click:function(){_this.appendChildData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-circle-plus"></i>'}})
							var removeBtn=h('button',{attrs:{type:'button','data-title':"节点删除"},on:{click:function(){_this.removeData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-delete"></i>'}})
							var editBtn=h('button',{attrs:{type:'button','data-title':"编辑节点"},on:{click:function(){_this.editData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-edit"></i>'}})
							if(res.node.level==1){
								return h('span',{attrs:{class:"custom-tree-node"}},[label,h('span',{},[appendBtn,appendChildBtn,editBtn,removeBtn])])
							}else{
								return h('span',{attrs:{class:"custom-tree-node"}},[label,h('span',{},[editBtn,removeBtn])])
							}
							
										
							},
							appendData:function(node,data,store){
								this.formTitle='增加兄弟节点';
								this.dialogVisible1=true;
								this.editNode=node;
								this.editType="sibling";
							},
							appendChildData:function(node,data,store){
								this.formTitle='增加子节点';
								this.dialogVisible1=true;
								this.editNode=node;
								this.editType="child";
							},
							removeData:function(node,data){
								var parent = node.parent;
								var children = parent.data.children || parent.data;
								children.forEach(function(item,index){
									if(item.id==data.id){
										children.splice(index, 1);
									}
								})

							},
							editData:function(node,data){
								this.formTitle='节点';
								this.dialogVisible1=true;
								this.editNode=node;
								this.editType="edit";
								this.form.name=data.name;
								this.form.icon=data.icon;
							},
							formSubmit:function(){
								var _this=this;
								_this.$refs['ruleForm'].validate(function(valid){
									if(valid){
										if(_this.editType=="sibling"){
									var node={
									"id":"",
									"name":_this.form.name,
									"icon":_this.form.icon,
									"children":[]
								}
								if(_this.editNode.level==1){
									_this.editNode.parent.data.push(node)
									}else{
										_this.editNode.parent.data.children.push(node)
									}
									_this.dialogVisible1=false;
								}else if(_this.editType=="child"){
									var node={
									"id":"",
									"name":_this.form.name,
									"icon":_this.form.icon,
									"children":[]
								}
								_this.editNode.data.children.push(node)
								_this.dialogVisible1=false;
								}else if(_this.editType=="edit"){
									_this.editNode.data.name=_this.form.name;
									_this.editNode.data.icon=_this.form.icon;
									_this.dialogVisible1=false;
								}
								_this.form={"name":"","icon":""}
								_this.$refs['ruleForm'].resetFields();
									}else{
										return false
									}
								})
								
							},
							cancelFormSubmit:function(){
								this.$refs['ruleForm'].resetFields();
								this.form={"name":"","icon":""};
								this.dialogVisible1=false;
							},
							formAuth:function(){
								this.$refs['ruleForm'].validate(function(){})
							},
							allowDrop:function(draggingNode, dropNode, type) {
								if(draggingNode.level!=dropNode.level){
									return false
								}
								else if(type=="inner"){
									return false
								}else{
									return true
								}
								
       						
      					},
  					}
                })  
            });  
		}); 
		/*流程主体*/
       Vue.component('component-main', function(resolve, reject){  //流程图
            $.get("./components/main.html").then(function(res) {  
                resolve({  
                    template: res,  
                    props: [],  
                    data:function(){
                    	return {
							width:store.state.width,
							height:store.state.height,
                    		mainCurrentIndex:0,
							thiseditMode:this.editMode,
							dialogVisible:false,
							imgDialogVisible:false,
							jsonData:[],
							imgSrc:''
                    	}
                    },
                    created:function(){
                    	var _this=this;
                    	jsPlumb.ready(function() {
                    		//store.dispatch('createProcess',{url:'common/data/data.json'});
							
							//L.instance.ajaxData( 'common/data/data.json',function(res){
								//store.commit('setProcessData',{"processData":res});
								//store.dispatch('createViewProcess');
							//})
						});
						$(document).on('conEdit',function(e,data,conn){
                    		_this.$prompt('提示：将表单内容清空可隐藏label', 'label修改', {
          						confirmButtonText: '确定',
          						cancelButtonText: '取消',
          						inputValue:data
          						
       					 }).then(function(res){
								if(res.value){
									conn.getOverlay('label').setVisible(true);
									conn.getOverlay('label').setLabel(res.value);
								}else{
									conn.getOverlay('label').setVisible(false);
									conn.getOverlay('label').setLabel(res.value);
									}
       					 	conn.getOverlay('label').setLabel(res.value);
							conn.data.label=res.value;
       					 	_this.$message({
           					 	type: 'success',
           					 	message: '修改成功'
         					 });
       					 }).catch(function(){
       					 });
				   });
				  
					_this.bus.$on('treeInit',function(){
						_this.width=store.state.width;
						_this.height=store.state.height;
					})
                   _this.bus.$on('treeChange', function() {
					   _this.mainCurrentIndex=0;
					   window.mainCurrentIndex=0;
					   _this.width=store.state.width;
					   _this.height=store.state.height;
        			});
                    },
                    methods: {
						valid:function(){
							var width=this.$refs.sizeWidth.value;
							var height=this.$refs.sizeHeight.value;
							
								if(width<1000){
									width=1000
								}else if(width>10000){
									width=10000
								}
								if(height<1000){
									height=1000
								}else if(height>10000){
									height=10000
								}
							this.width=width;
							this.height=height;
						},	
    				mainTabSwitch:function(index){
						this.width=store.state.width;
						this.height=store.state.height;
						this.mainCurrentIndex=index;
						window.mainCurrentIndex=index;
    					if(index==0){
    						store.commit('setMode',{mode:'view'});
    						this.$emit('changemode',false)
    						store.dispatch('createViewProcess');
    					}else if(index==1){
    						store.commit('setMode',{mode:'edit'});
    						this.$emit('changemode',true)
							store.dispatch('createProcess');
							$(document).trigger('moduleChange')
						}
						
					},
					saveData:function(){
						var _this=this;
						 L.instance.getInstanceData(store.state.instance,function(datas,unableSave,unableSaveNode){
							 if(unableSave){
								 var textString='';
								 var len=unableSaveNode.length;
								 unableSaveNode.forEach(function(item,index){
									textString+=item.replace(/<[^>]+>/g,"");
									if(index!=len-1){
										textString+="、"
									}
								 });
								_this.$alert('存在未填写必填属性节点'+textString+'，无法保存！', '警告', {
									confirmButtonText: '确定',
									type: 'warning',
									callback:function(){}
								  });
								  return false
							 }
							 store.commit('setWidth',{"width":_this.width});
							 store.commit('setHeight',{"height":_this.height});
			  				store.commit('setProcessData',{"processData":datas});
							_this.$message({
         				 	message: '数据保存成功！',
         				 	type: 'success'
       					 });
						});
						
						
					},
					getJsonData:function(){
						var _this=this;
						
						L.instance.getInstanceData(store.state.instance,function(datas,unableSave,unableSaveNode){
							 if(unableSave){
								var textString='';
								var len=unableSaveNode.length;
								unableSaveNode.forEach(function(item,index){
								   textString+=item.replace(/<[^>]+>/g,"");
								   if(index!=len-1){
									   textString+="、"
								   }
								});
								_this.$alert('存在未填写必填属性节点'+textString+'，请规范填写属性后进行预览！', '警告', {
									confirmButtonText: '确定',
									type: 'warning',
									callback:function(){}
								  });
								  return false
							 }
							 var data=store.state.currentMenu;
							
							 data.width=_this.width;
							 data.height=_this.height;
							 data.flow=datas;
							 _this.jsonData=data;
							 _this.dialogVisible=true
						});
						
					},
					domtoImage:function(){
						var _this=this;
						if(isIE()){
							this.$alert('不支持ie浏览器预览，请使用火狐或谷歌浏览器?', '提示', {
          						confirmButtonText: '确定',
          						type: 'warning',
								callback:function(){}
								});
								return
						}
						L.domtoimage('container-id',function(result){
							_this.imgDialogVisible=true;
							_this.imgSrc=result.src;
						})
					},
					clearImage:function(){
						this.$confirm('是否清除流程', '提示', {
							confirmButtonText: '确定',
							cancelButtonText: '取消',
							type:"info",
							callback:function(action){
								if(action=='confirm'){
									L.instance.removeEditView(store.state.instance);
								}
							}
						  });
					
					}
  					}
                })  
            });  
		}); 
		/*右边菜单组件*/
        Vue.component('component-module', function(resolve, reject){  //节点模型
            $.get("./components/module.html").then(function(res) {  
                resolve({  
                    template: res,  
                    props: [],  
                    data:function(){
                    	return {
						nodeModule:[],
						copyNodeModule:[],
						moduleConfig:{},
						activeNames:[],
						searchkeyWord:''
                    	
                    }
                    },
                    created:function(){
						var _this=this;
						this.moduleConfig=L.nodeConfig.module;
						$.ajax({
							url:'common/data/nodeModule.json',
							type:'get',
							success:function(res){
								res.forEach(function(itemData){
									itemData.data.forEach(function(item){
										
									item.type=_this.moduleConfig[item.mode].type;
									var background='background:'+_this.moduleConfig[item.mode].nodeStyle.background+';';
									var borderWidth='border-width:'+_this.moduleConfig[item.mode].nodeStyle.borderWidth+';';
									var borderColor='border-color:'+_this.moduleConfig[item.mode].nodeStyle.borderColor+';';
									var borderRadius='';
									item.height=_this.moduleConfig[item.mode].nodeStyle.height?_this.moduleConfig[item.mode].nodeStyle.height:70;
									item.width=_this.moduleConfig[item.mode].nodeStyle.width?_this.moduleConfig[item.mode].nodeStyle.width:120;
									if(item.type=='Rect'||item.type=='Note'){
										borderRadius='border-radius:'+_this.moduleConfig[item.mode].nodeStyle.borderRadius;
									}
									item.style=background+borderWidth+borderColor+borderRadius
									if(item.type=='Ellipse'){
										item.className='round'
									}
									if(item.type=='Note'){
										item.className='note'
									}
									if(item.type=='Prismatic'){
										item.style='border:none;background:transparent'
										item.fillStyle="fill:"+_this.moduleConfig[item.mode].nodeStyle.background+';';
										item.fillStyle+="stroke-width:"+parseInt(_this.moduleConfig[item.mode].nodeStyle.borderWidth)+';';
										item.fillStyle+="stroke:"+_this.moduleConfig[item.mode].nodeStyle.borderColor+';';
									}
									
									item.fontStyle="font-size:"+parseInt(_this.moduleConfig[item.mode].nodeStyle.font.fontSize)+"px;color:"+_this.moduleConfig[item.mode].nodeStyle.font.color+";font-weight:"+_this.moduleConfig[item.mode].nodeStyle.font.fontWeight;
									item.sourceEndPoint=_this.moduleConfig[item.mode].sourceEndPoint;
									item.targetEndPoint=_this.moduleConfig[item.mode].targetEndPoint;
								});
								})
								
								
								_this.nodeModule=res;
								_this.copyNodeModule=JSON.parse(JSON.stringify(_this.nodeModule));
								for(i=0;i<_this.nodeModule.length;i++){
									_this.activeNames.push(i)
								}
							}

						})
                    },
                    methods: {
						searchModule:function(){
							var _this=this;
							
							
							var keyWord=this.searchkeyWord.toLowerCase();
							var moduleData=JSON.parse(JSON.stringify(_this.copyNodeModule));
							if(keyWord.length>0){
								var newModule=[];
								moduleData.forEach(function(item){
									var obj={};
									var append=false;
									obj.name=item.name;
									obj.data=[];
									item.data.forEach(function(it){
										if(it.name.toLowerCase().indexOf(keyWord)>-1){
											obj.data.push(it);
											append=true;
										}
									});
									if(append){
										newModule.push(obj)
									}
							})
							_this.nodeModule=newModule;
							}else{
								_this.nodeModule=moduleData;
							}
							var activeNames=[];
							for(i=0;i<_this.nodeModule.length;i++){
									activeNames.push(i)
								}
								_this.activeNames=activeNames
							
						},
    					nodeMove:function(e,group,it){
    						L.dragNodeExample(e,store.state.instance,group,it)
    					}
  					}
                })  
            });  
        }); 
        /*Vue.directive('scrollbar', {
  			inserted: function (el) {
    			$(el).mCustomScrollbar({
		  			'axis':$(el).attr('scroll-type')=='xy'?"yx":"y",
		  			'theme':"dark",
		  			'scrollInertia':200,
		  			'mouseWheelPixels':100
		  		});
  				}
			})*/
			/*首页vue实例化*/
		L.vue=new Vue({
			el: '#app',
			store:store,
			data:{
				edit:false,
				dialogVisible:false,
				textarea:"",
				editNote:false,
				editNoteId:'',
				noteTitle:'编辑内容'
			},
			created:function(){
				var _this=this;
				_this.bus.$on('errorMes',function(res){
					_this.$message({
						message: res,
						type: 'error'
					  });
				});
				_this.bus.$on('successMes',function(res){
					_this.$message({
						message: res,
						type: 'success'
					  });
				});
				_this.bus.$on('warningMes',function(res){
					_this.$message({
						message: res,
						type: 'warning'
					  });
				});
				_this.bus.$on('alertError',function(res){
					_this.$alert(res, '错误', {
						confirmButtonText: '确定',
						type:"error",
						callback:function(action){}
					  });
				});
				_this.bus.$on('confirmInfo',function(res,fun){
					_this.$confirm(res, '提示', {
						confirmButtonText: '确定',
						cancelButtonText: '取消',
						type:"info",
						callback:function(action){
							if(action=='confirm'){
								if(fun){fun()}
							}
						}
					  });
				});
				_this.bus.$on('infoMes',function(res){
					_this.$message({
						message: res
					  });
				});
			
				_this.bus.$on('editNote',function(res){
					_this.noteTitle='编辑内容';
					_this.dialogVisible=true;
					_this.textarea=res.textarea;
					_this.editNote=true;
					//_this.editNoteId=res.id;
				});
                    },
			methods:{
				changeMode:function(buer){
                    this.edit=buer		
				   },
				   closeEditNote:function(){
					  var value=this.textarea;
					  if(this.editNote){
						$(document).trigger('editNodeItem',[value]);
					  }else{
						$(document).trigger('addNodeItem',[value]);
					  }
					
					this.dialogVisible=false;
					this.textarea="";
				   }
			}
			});
			
			
			function editNote(textarea,id){
				Vue.prototype.bus.$emit('editNote',{'textarea':textarea,'id':id});
			}
			
			$(document).on('editNodeItem',function(e,value){
				L.instance.currentNode.getElementsByClassName('node-example-text')[0].innerHTML=value;
				L.instance.currentNode.data.content=value;
			})
		
			