Vue.use(Vuex);
L.sidePop({"width":"600"})
		var store=new Vuex.Store({
			state:{
				mode:'view',
				viewInstance:null,
				instance:null,
				processData:[],
				currentMenu:[],
				width:2000,
				height:1000
			
			},
			mutations: {
				setMode:function(state,params){ 
					state.mode=params.mode;
				},
				setWidth:function(state,params){ 
					state.width=params.width;
				},
				setHeight:function(state,params){ 
					state.height=params.height;
				},
				setInstance:function(state,params){ //设置编辑模式instance
					state.instance=params.instance;
				},
				setViewInstance:function(state,params){ //设置视图模式instance
					state.viewInstance=params.instance;
				},
				setProcessData:function(state,params){ //全局保存ajax数据
					state.processData=params.processData;
				},
				setCurrentMenu:function(state,params){
					state.currentMenu=params.currentMenu;
				}
  			},
  			actions: {
  				clearProcess:function(content,params){
					if(content.state.viewInstance){
						L.instance.removeView(content.state.viewInstance);
						content.commit('setViewInstance',{instance:null});
					}
				if(content.state.instance){
						L.instance.removeEditView(content.state.instance);
						instanceUnbindEvent(content.state.instance);
						content.commit('setInstance',{instance:null});
					}
				  },
  				createViewProcess:function(content,params) {  //创建视图模式
					this.dispatch('clearProcess');
					var instance=L.instance.viewInit({Container:"container-id",Connector: ["Straight",{ stub: [0, 0], gap: 0, cornerRadius:0, alwaysRespectStubs:false }]});
   				 	L.instance.createView(instance,this.state.processData);
 					content.commit('setInstance',{instance:instance});
   			 		},
   				 createProcess:function(content,params) { //创建编辑模式
					this.dispatch('clearProcess');
					var instance=L.instance.init({Container:"container-id",Connector: ["Straight",{ stub: [0, 0], gap: 0, cornerRadius:0, alwaysRespectStubs: false }]});
					instanceBindEvent(instance);
   				 	L.instance.createEditView(instance,this.state.processData);
 					content.commit('setInstance',{instance:instance});
   			 		}
   			 	}
		});
		var bus = new Vue();
		Vue.prototype.bus = bus;
		Vue.component('component-sidebar', function(resolve, reject){  //侧边菜单
            $.get("./components/sidebar.html").then(function(res) {  
                resolve({  
                    template: res,  
                    props: [],  
                    data:function(){
                    	return {
							
							menuData:[],
							menuTreeData:[],
							active:"1-1",
							dialogVisible:false,
							dialogVisible1:false,
							defaultProps:{
          						children: 'children',
         					 	label: 'name'
								},
								formTitle:"",
								form:{
								"name":"",
								"icon":""
								},
								rules: {
          							name: [
           							 { required: true, message: '请输入菜单名称', trigger: 'blur' }
          							]
        						},
							editNode:"",
							editType:""
						}
                    },
                    created:function(){
						var _this=this;
                    	$.get('common/data/apply.json').then(function(result){
							_this.menuData=result;
							_this.menuTreeData=JSON.parse(JSON.stringify(_this.menuData));
							jsPlumb.ready(function() {
								var activeArr=_this.active.split('-');
								store.commit('setCurrentMenu',{currentMenu:_this.menuData[activeArr[0]].children[activeArr[1]]});
							var id=_this.menuData[activeArr[0]].children[activeArr[1]].id;
								L.instance.ajaxData( 'common/data/data.json?id='+id,function(res){
									store.commit('setProcessData',{"processData":res.flow});
									store.commit('setWidth',{"width":res.width});
									store.commit('setHeight',{"height":res.height});
									store.dispatch('createViewProcess');
								})
							
							
                    	});
        					});
					},
					mounted:function(){
					//setTimeout(function(){
					//	$('.el-menu .el-submenu .el-submenu__title').click();
				//	},100)
					},
                    methods: {
    					
    					nodeSelect:function(res,active) {
							var _this=this;
							_this.active=active;
							store.commit('setCurrentMenu',{currentMenu:res});
							if(res.id){
								L.instance.ajaxData( 'common/data/data.json?id='+res.id,function(res){
									store.commit('setProcessData',{"processData":res.flow});
									store.commit('setWidth',{"width":res.width});
									store.commit('setHeight',{"height":res.height});
									store.commit('setMode',{mode:'view'});
									_this.$emit('changemode',false);
									_this.bus.$emit('treeChange');
									store.dispatch('createViewProcess');
								});
							}
							else{
								store.dispatch('clearProcess');
							}
							},
							editMenu:function(){
								this.dialogVisible=true
							},
							menuDataChange:function(){
								this.menuData=JSON.parse(JSON.stringify(this.menuTreeData));
								this.dialogVisible=false
							},
							cancelDataChange:function(){
								this.menuTreeData=JSON.parse(JSON.stringify(this.menuData));
								this.dialogVisible=false
							},
							renderContent:function(h,res){
							var _this=this;
							
							var label=h('span',{domProps: {innerHTML:"<span><i class='"+res.data.icon+"' style='margin-right:4px'></i>"+res.data.name+"</span>"}});
							
							var appendBtn=h('button',{attrs:{type:'button','data-title':"增加兄弟节点"},on:{click:function(){_this.appendData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-circle-plus-outline"></i>'}});
							var appendChildBtn=h('button',{attrs:{type:'button','data-title':"增加子节点"},on:{click:function(){_this.appendChildData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-circle-plus"></i>'}})
							var removeBtn=h('button',{attrs:{type:'button','data-title':"节点删除"},on:{click:function(){_this.removeData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-delete"></i>'}})
							var editBtn=h('button',{attrs:{type:'button','data-title':"编辑节点"},on:{click:function(){_this.editData(res.node,res.data,res.store)}},domProps: {innerHTML:'<i class="el-icon-edit"></i>'}})
							if(res.node.level==1){
								return h('span',{attrs:{class:"custom-tree-node"}},[label,h('span',{},[appendBtn,appendChildBtn,editBtn,removeBtn])])
							}else{
								return h('span',{attrs:{class:"custom-tree-node"}},[label,h('span',{},[editBtn,removeBtn])])
							}
							
										
							},
							appendData:function(node,data,store){
								this.formTitle='增加兄弟节点';
								this.dialogVisible1=true;
								this.editNode=node;
								this.editType="sibling";
							},
							appendChildData:function(node,data,store){
								this.formTitle='增加子节点';
								this.dialogVisible1=true;
								this.editNode=node;
								this.editType="child";
							},
							removeData:function(node,data){
								var parent = node.parent;
								var children = parent.data.children || parent.data;
								children.forEach(function(item,index){
									if(item.id==data.id){
										children.splice(index, 1);
									}
								})

							},
							editData:function(node,data){
								this.formTitle='节点';
								this.dialogVisible1=true;
								this.editNode=node;
								this.editType="edit";
								this.form.name=data.name;
								this.form.icon=data.icon;
							},
							formSubmit:function(){
								var _this=this;
								_this.$refs['ruleForm'].validate(function(valid){
									if(valid){
										if(_this.editType=="sibling"){
									var node={
									"id":"",
									"name":_this.form.name,
									"icon":_this.form.icon,
									"children":[]
								}
								if(_this.editNode.level==1){
									_this.editNode.parent.data.push(node)
									}else{
										_this.editNode.parent.data.children.push(node)
									}
									_this.dialogVisible1=false;
								}else if(_this.editType=="child"){
									var node={
									"id":"",
									"name":_this.form.name,
									"icon":_this.form.icon,
									"children":[]
								}
								_this.editNode.data.children.push(node)
								_this.dialogVisible1=false;
								}else if(_this.editType=="edit"){
									_this.editNode.data.name=_this.form.name;
									_this.editNode.data.icon=_this.form.icon;
									_this.dialogVisible1=false;
								}
								_this.form={"name":"","icon":""}
								_this.$refs['ruleForm'].resetFields();
									}else{
										return false
									}
								})
								
							},
							cancelFormSubmit:function(){
								this.$refs['ruleForm'].resetFields();
								this.form={"name":"","icon":""};
								this.dialogVisible1=false;
							},
							formAuth:function(){
								this.$refs['ruleForm'].validate(function(){})
							},
							allowDrop:function(draggingNode, dropNode, type) {
								if(draggingNode.level!=dropNode.level){
									return false
								}
								else if(type=="inner"){
									return false
								}else{
									return true
								}
								
       						
      					},
  					}
                })  
            });  
        }); 
       Vue.component('component-main', function(resolve, reject){  //流程图
            $.get("./components/main.html").then(function(res) {  
                resolve({  
                    template: res,  
                    props: [],  
                    data:function(){
                    	return {
							width:store.state.width,
							height:store.state.height,
                    		mainCurrentIndex:0,
							thiseditMode:this.editMode,
							dialogVisible:false,
							imgDialogVisible:false,
							jsonData:[],
							imgSrc:''
                    	}
                    },
                    created:function(){
                    	var _this=this;
                    	jsPlumb.ready(function() {
                    		//store.dispatch('createProcess',{url:'common/data/data.json'});
							
							//L.instance.ajaxData( 'common/data/data.json',function(res){
								//store.commit('setProcessData',{"processData":res});
								//store.dispatch('createViewProcess');
							//})
						});
						$(document).on('conEdit',function(e,data,conn){
                    		_this.$prompt('提示：将表单内容清空可隐藏label', 'label修改', {
          						confirmButtonText: '确定',
          						cancelButtonText: '取消',
          						inputValue:data
          						
       					 }).then(function(res){
								if(res.value){
									conn.getOverlay('label').setVisible(true);
									conn.getOverlay('label').setLabel(res.value);
								}else{
									conn.getOverlay('label').setVisible(false);
									conn.getOverlay('label').setLabel(res.value);
									}
       					 	conn.getOverlay('label').setLabel(res.value);
							conn.data.label=res.value;
       					 	_this.$message({
           					 	type: 'success',
           					 	message: '修改成功'
         					 });
       					 }).catch(function(){
       					 });
                   });
                   _this.bus.$on('treeChange', function() {
					   _this.mainCurrentIndex=0;
					   window.mainCurrentIndex=0;
					   _this.width=store.state.width;
					   _this.height=store.state.height;
        			});
                    },
                    methods: {
                    	
    				mainTabSwitch:function(index){
						this.width=store.state.width;
						this.height=store.state.height;
						this.mainCurrentIndex=index;
						window.mainCurrentIndex=index;
    					if(index==0){
    						store.commit('setMode',{mode:'view'});
    						this.$emit('changemode',false)
    						store.dispatch('createViewProcess');
    					}else if(index==1){
    						store.commit('setMode',{mode:'edit'});
    						this.$emit('changemode',true)
							store.dispatch('createProcess');
							$(document).trigger('moduleChange')
						}
						setTimeout(function(){resetNotePos()},100)
					},
					saveData:function(){
						var _this=this;
						 L.instance.getInstanceData(store.state.instance,function(datas,unableSave,unableSaveNode){
							 if(unableSave){
								 var textString='';
								 var len=unableSaveNode.length;
								 unableSaveNode.forEach(function(item,index){
									textString+=item.replace(/<[^>]+>/g,"");
									if(index!=len-1){
										textString+="、"
									}
								 });
								_this.$alert('存在未填写必填属性节点'+textString+'，无法保存！', '警告', {
									confirmButtonText: '确定',
									type: 'warning',
									callback:function(){}
								  });
								  return false
							 }
							 store.commit('setWidth',{"width":_this.width});
							 store.commit('setHeight',{"height":_this.height});
			  				store.commit('setProcessData',{"processData":datas});
							_this.$message({
         				 	message: '数据保存成功！',
         				 	type: 'success'
       					 });
						});
						
						
					},
					getJsonData:function(){
						var _this=this;
						
						L.instance.getInstanceData(store.state.instance,function(datas,unableSave,unableSaveNode){
							 if(unableSave){
								var textString='';
								var len=unableSaveNode.length;
								unableSaveNode.forEach(function(item,index){
								   textString+=item.replace(/<[^>]+>/g,"");
								   if(index!=len-1){
									   textString+="、"
								   }
								});
								_this.$alert('存在未填写必填属性节点'+textString+'，请规范填写属性后进行预览！', '警告', {
									confirmButtonText: '确定',
									type: 'warning',
									callback:function(){}
								  });
								  return false
							 }
							 var data=store.state.currentMenu;
							
							 data.width=_this.width;
							 data.height=_this.height;
							 data.flow=datas;
							 _this.jsonData=data;
							 _this.dialogVisible=true
						});
						
					},
					domtoImage:function(){
						var _this=this;
						if(isIE()){
							this.$alert('不支持ie浏览器预览，请使用火狐或谷歌浏览器?', '提示', {
          						confirmButtonText: '确定',
          						type: 'warning',
								callback:function(){}
								});
								return
						}
						L.domtoimage('container-id',function(result){
							_this.imgDialogVisible=true;
							_this.imgSrc=result.src;
						})
					},
					clearImage:function(){
						L.instance.removeEditView(store.state.instance);
					}
  					}
                })  
            });  
        }); 
        Vue.component('component-module', function(resolve, reject){  //节点模型
            $.get("./components/module.html").then(function(res) {  
                resolve({  
                    template: res,  
                    props: [],  
                    data:function(){
                    	return {
						nodeModule:[],
						copyNodeModule:[],
						moduleConfig:{},
						activeNames:[],
						searchkeyWord:''
                    	
                    }
                    },
                    created:function(){
						var _this=this;
						this.moduleConfig=L.nodeConfig.module;
						$.ajax({
							url:'common/data/nodeModule.json',
							type:'get',
							success:function(res){
								res.forEach(function(itemData){
									itemData.data.forEach(function(item){
										
									item.type=_this.moduleConfig[item.mode].type;
									var background='background:'+_this.moduleConfig[item.mode].nodeStyle.background+';';
									var borderWidth='border-width:'+_this.moduleConfig[item.mode].nodeStyle.borderWidth+';';
									var borderColor='border-color:'+_this.moduleConfig[item.mode].nodeStyle.borderColor+';';
									var borderRadius='';
									item.height=_this.moduleConfig[item.mode].nodeStyle.height?_this.moduleConfig[item.mode].nodeStyle.height:70;
									item.width=_this.moduleConfig[item.mode].nodeStyle.width?_this.moduleConfig[item.mode].nodeStyle.width:120;
									if(item.type=='Rect'){
										borderRadius='border-radius:'+_this.moduleConfig[item.mode].nodeStyle.borderRadius;
									}
									item.style=background+borderWidth+borderColor+borderRadius
									if(item.type=='Ellipse'){
										item.className='round'
									}
									if(item.type=='Prismatic'){
										item.style='border:none;background:transparent'
										item.fillStyle="fill:"+_this.moduleConfig[item.mode].nodeStyle.background+';';
										item.fillStyle+="stroke-width:"+parseInt(_this.moduleConfig[item.mode].nodeStyle.borderWidth)+';';
										item.fillStyle+="stroke:"+_this.moduleConfig[item.mode].nodeStyle.borderColor+';';
									}
									
									item.fontStyle="font-size:"+parseInt(_this.moduleConfig[item.mode].nodeStyle.font.fontSize)+"px;color:"+_this.moduleConfig[item.mode].nodeStyle.font.color+";font-weight:"+_this.moduleConfig[item.mode].nodeStyle.font.fontWeight;
									item.sourceEndPoint=_this.moduleConfig[item.mode].sourceEndPoint;
									item.targetEndPoint=_this.moduleConfig[item.mode].targetEndPoint;
								});
								})
								
								
								_this.nodeModule=res;
								_this.copyNodeModule=JSON.parse(JSON.stringify(_this.nodeModule));
								for(i=0;i<_this.nodeModule.length;i++){
									_this.activeNames.push(i)
								}
							}

						})
                    },
                    methods: {
						searchModule:function(){
							var _this=this;
							
							
							var keyWord=this.searchkeyWord.toLowerCase();
							var moduleData=JSON.parse(JSON.stringify(_this.copyNodeModule))
							if(keyWord.length>0){
								var newModule=[];
								moduleData.forEach(function(item){
									var obj={};
									var append=false;
									obj.name=item.name;
									obj.data=[];
									item.data.forEach(function(it){
										if(it.name.toLowerCase().indexOf(keyWord)>-1){
											obj.data.push(it);
											append=true;
										}
									});
									if(append){
										newModule.push(obj)
									}
							})
							_this.nodeModule=newModule;
							}else{
								_this.nodeModule=moduleData;
							}
							var activeNames=[];
							for(i=0;i<_this.nodeModule.length;i++){
									activeNames.push(i)
								}
								_this.activeNames=activeNames
							
						},
    					nodeMove:function(e,group,it){
    						L.dragNodeExample(e,store.state.instance,group,it)
    					}
  					}
                })  
            });  
        }); 
        /*Vue.directive('scrollbar', {
  			inserted: function (el) {
    			$(el).mCustomScrollbar({
		  			'axis':$(el).attr('scroll-type')=='xy'?"yx":"y",
		  			'theme':"dark",
		  			'scrollInertia':200,
		  			'mouseWheelPixels':100
		  		});
  				}
			})*/
		L.vue=new Vue({
			el: '#app',
			store:store,
			data:{
				edit:false,
				dialogVisible:false,
				textarea:"",
				editNote:false,
				editNoteId:'',
				noteTitle:'增加备注'
			},
			created:function(){
				var _this=this;
				_this.bus.$on('errorMes',function(res){
					_this.$message({
						message: res,
						type: 'error'
					  });
				});
				_this.bus.$on('successMes',function(res){
					_this.$message({
						message: res,
						type: 'success'
					  });
				});
				_this.bus.$on('warningMes',function(res){
					_this.$message({
						message: res,
						type: 'warning'
					  });
				});
				_this.bus.$on('alertError',function(res){
					_this.$alert(res, '错误', {
						confirmButtonText: '确定',
						type:"error",
						callback:function(action){}
					  });
				});
				_this.bus.$on('confirmInfo',function(res,fun){
					_this.$confirm(res, '提示', {
						confirmButtonText: '确定',
						cancelButtonText: '取消',
						callback:function(action){
							if(action=='confirm'){
								if(fun){fun()}
							}
						}
					  });
				});
				_this.bus.$on('infoMes',function(res){
					_this.$message({
						message: res
					  });
				})
				_this.bus.$on('addNote',function(res){
					_this.noteTitle='增加备注';
					_this.dialogVisible=true;
					_this.textarea=res.textarea;
					_this.editNote=false;
				})
				_this.bus.$on('editNote',function(res){
					_this.noteTitle='编辑备注';
					_this.dialogVisible=true;
					_this.textarea=res.textarea;
					_this.editNote=true;
					_this.editNoteId=res.id;
				})
                    },
			methods:{
				changeMode:function(buer){
                    this.edit=buer		
				   },
				   closeEditNote:function(){
					  var value=this.textarea;
					  if(this.editNote){
						$(document).trigger('editNodeItem',[value,this.editNoteId]);
					  }else{
						$(document).trigger('addNodeItem',[value]);
					  }
					
					this.dialogVisible=false;
					this.textarea="";
				   }
			}
			});
			L.instance.createNote=function(data){
				window.noteData=JSON.parse(JSON.stringify(data));
				var arr=noteData.value;
				
				for(var i=0;i<arr.length;i++){
					var $noteItem=$('<div class="noteItem" data-id="'+arr[i].id+'"></div>');
					var $noteContent=$('<div class="noteContent"></div>');
					$noteContent.html(arr[i].text);
					if(window.mainCurrentIndex==1){
						var $noteRemove=$('<a class="noteRemove" data-id="'+arr[i].id+'"><i class="el-icon-close"></i></a>');
						var $noteEdit=$('<a class="noteEdit" data-id="'+arr[i].id+'"><i class="el-icon-edit"></i></a>');
						$noteItem.append($noteEdit);
						$noteItem.append($noteRemove);
						$noteEdit.click(function(){
							var id=$(this).attr('data-id');
							for(var j=0;j<noteData.value.length;j++){
								if(noteData.value[j].id==id){
									editNote(noteData.value[j].text,id)
								}
							}
							resetNotePos()
						})
						$noteRemove.click(function(e){
							var _this=this;
							Vue.prototype.bus.$emit('confirmInfo','删除此条注释？',function(){
								$(_this).parent(".noteItem").remove();
								var id=$(_this).attr('data-id');
								for(var j=0;j<noteData.value.length;j++){
									if(noteData.value[j].id==id){
										noteData.value.splice(j,1)
									}
								}
								resetNotePos()
							});
							
						})
					}
					
					$noteItem.append($noteContent);
					$('.rx-container-note').append($noteItem);
				}
				resetNotePos()
			}
			function resetNotePos(){
				var len=$('.rx-container-note').find('.noteItem').length;
					for(var i=0;i<len;i++){
						var top=0;
						for(var j=i;j<len;j++){
							top+=$('.rx-container-note').find('.noteItem').eq(j).outerHeight(true)
						}
						$('.rx-container-note').find('.noteItem').eq(i).css("top","-"+top+"px")
					}
			}
			$(window).on('resize',function(){
				resetNotePos()
			})
			function editNote(textarea,id){
				Vue.prototype.bus.$emit('editNote',{'textarea':textarea,'id':id});
			}
			function addNote(textarea){
				Vue.prototype.bus.$emit('addNote',{'textarea':textarea});
			}
			$(document).on('editNodeItem',function(e,value,id){
				for(var j=0;j<noteData.value.length;j++){
					if(noteData.value[j].id==id){
						noteData.value[j].text=value;
						$('.noteItem[data-id='+id+']').find('.noteContent').html(value)
					}
				}
				resetNotePos()
			})
			$(document).on('addNodeItem',function(e,value){
				var id=parseInt(Math.random(0,1)*10000)+''+new Date().getTime();
				var $noteItem=$('<div class="noteItem" data-id="'+id+'"></div>');
				var $noteContent=$('<div class="noteContent"></div>');
				$noteContent.html(value);
					var $noteRemove=$('<a class="noteRemove" data-id="'+id+'"><i class="el-icon-close"></i></a>');
					var $noteEdit=$('<a class="noteEdit" data-id="'+id+'"><i class="el-icon-edit"></i></a>');
						$noteItem.append($noteEdit);
						$noteItem.append($noteRemove);
						$noteEdit.click(function(){
							var id=$(this).attr('data-id');
							for(var j=0;j<noteData.value.length;j++){
								if(noteData.value[j].id==id){
									editNote(noteData.value[j].text,id)
								}
							}
							resetNotePos()
						})
					$noteRemove.click(function(e){
						var _this=this;
							Vue.prototype.bus.$emit('confirmInfo','删除此条注释？',function(){
								$(_this).parent(".noteItem").remove();
								var id=$(_this).attr('data-id');
								for(var j=0;j<noteData.value.length;j++){
									if(noteData.value[j].id==id){
										noteData.value.splice(j,1)
									}
								}
								resetNotePos()
							});
					})
				$noteItem.append($noteContent);
				$('.rx-container-note').append($noteItem);
				noteData.value.push({id:id,text:value})
				resetNotePos()
			})
			