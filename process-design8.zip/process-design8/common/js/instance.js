L.instance = {};
//流程初始化参数
L.instance.init = function(option) {
	L.instance.nodes=[];
	var defaults = {
		Connector: ["Flowchart",{ cornerRadius:0, alwaysRespectStubs:false }], //Flowchart、Bezier、Straight、StateMachine
		DragOptions: {
			cursor: "pointer",
			zIndex: 2000
		},
		PaintStyle: {
			strokeWidth: 1,
			stroke: "#37474F",
			outlineStroke: "transparent",
			outlineWidth:6
		},
		EndpointStyle: {},
		EndpointHoverStyle: {
			
		},
		HoverPaintStyle: {
			stroke: "#ff4c52",
			strokeWidth: 1,
			outlineStroke: "transparent"
		},
		logEnabled:true,
		ConnectionOverlays: [
			["Arrow", {
				location:1,
				length: 10,
				foldback: 0.6,
				fill: '#000',
				width: 8,
				visible: true
			}],
			["Custom", {
				create: function(component) {
					var $remove = $("<div style='width:20px;height:20px;line-height:18px;text-align:center;cursor:pointer;border-radius:50%;background:#000;color:#fff;padding:0'><i class='fa fa-close'><i></div>");
					return $remove;
				},
				cssClass: 'hidden',
				location: 0.1,
				id: "customOverlay",
				hoverClass: 'show',
				events: {
					"click": function(custom, evt) {
						L.instance.deleteConnection(custom._jsPlumb.instance, custom._jsPlumb.component)
					}
				}
			}],

			["Label", {
				label: 'label',
				id: 'label',
				location: 0.5,
				cssClass: 'aLabel',
				hoverClass: 'show',
				events: {
					"click": function(label, evt) {
						//label.setLabel('54444');
							//console.log(label)
							//console.log(evt)
					}
				}
			}]
		],
		Container: "container-id"
	};

	option = $.extend(true, {}, defaults, option);
	return jsPlumb.getInstance(option);
}
//预览模式初始化参数
L.instance.viewInit = function(option) {
	L.instance.nodes=[];
	var defaults = {
		Connector: ["Flowchart",{ stub: [40, 60], gap: 10, cornerRadius:0, alwaysRespectStubs:false }], //Flowchart、Bezier、Straight、StateMachine
		DragOptions: {
			cursor: "pointer",
			zIndex: 2000
		},
		PaintStyle: {
			strokeWidth: 1,
			stroke: "#37474F",
			outlineStroke: "transparent",
			outlineWidth: 10
		},
		EndpointStyle: {},
		EndpointHoverStyle: {
			fill: "",
			radius:0
		},
		HoverPaintStyle: {
			stroke: "#000",
			strokeWidth: 1,
			outlineStroke: "transparent"
		},
		ConnectionOverlays: [
			["Arrow", {
				location:1,
				length: 10,
				foldback: 0.6,
				fill: '#000',
				width: 8,
				visible: true
			}],
			

			["Label", {
				label: 'label',
				id: 'label',
				location: 0.5,
				cssClass: 'aLabel',
				hoverClass: 'show',
				events: {
					"click": function(label, evt) {
					
					}
				}
			}]
		],
		Container: "container-id"
	};

	option = $.extend(true, {}, defaults, option);
	return jsPlumb.getInstance(option);
}
//增加单个节点
L.instance.createBlock = function(instance, type, nodeId, position, width, height, borderWidth, borderColor,borderRadius,font, background,content,view,propertys) {

	L.block.Model({
		type: type,
		id: nodeId,
		wrapId: Object.getPrototypeOf(instance).Defaults.Container,
		top: position.y,
		left: position.x,
		width: width,
		height: height,
		borderWidth: borderWidth,
		borderColor: borderColor,
		borderRadius:borderRadius,
		background: background,
		content:content,
		font:font,
		propertys:propertys,
		view:view
	}, instance);
	instance.makeTarget(document.getElementById(nodeId), {
		anchor:"Continuous",
		endpoint:"Dot",
		allowLoopback:false,
		paintStyle: {
            strokeStyle: "#7AB02C",
            fillStyle: "transparent",
            radius:0,
            lineWidth: 3
        },
		scope:"scope"
		
	  });
	  instance.makeSource(document.getElementById(nodeId).getElementsByClassName('node-source')[0], {
		anchor:"Continuous",
		endpoint:"Blank",
		allowLoopback:false,
		paintStyle: {
            strokeStyle: "#7AB02C",
            fillStyle: "transparent",
            radius:0,
            lineWidth: 3
		},
		
		scope:"scope"
		
	  });
	return jsPlumb.getSelector('#' + nodeId)[0];
}
//增加单个端点
L.instance.createPoint = function(instance, node,scope,view) {
	 //"Top","Bottom","Left","Right","Center","TopRight","BottomRight","TopLeft","BottomLeft"
	//另一种格式[0,0.5,0,0]
	var paintStyle = {
		radius:10,
		fill: '#6DA611'
	};
	
	if(view){
		paintStyle = {
		radius:0
	};
	}
	
	var e = instance.addEndpoint(node, {
		paintStyle: paintStyle,
		anchor: "Right",
		maxConnections: -1,
		isSource:true,
		isTarget:false,
		scope:scope,
		detachable: true,
		parameters:{manMade:true}
	});
	return e
}

//增加端点连线
L.instance.connectPoints = function(instance, sourceId, targetId, label, init) {
	var source=document.getElementById(sourceId);
	var target=document.getElementById(targetId);

	
	var conn = instance.connect({
		//anchors:[[ "Perimeter", { shape:sourceNodeType, rotation:0 } ],
				//[ "Perimeter", { shape:targetNodeType, rotation:0 } ]],
				//anchor:"Continuous",
				anchor:"AutoDefault",
                endpoint:"Blank",
				source:source, 
				target:target,
				parameters: {
					"label": label,
					'init': init
				}
			});
	if(conn){
		if(label){
			conn.getOverlay('label').setVisible(true);
			conn.getOverlay('label').setLabel(label);
		}else{
			conn.getOverlay('label').setVisible(false);
		}
		conn.id = sourceId + '-' + targetId+parseInt(Math.random(0,1)*10000);
		//conn.getOverlay('label').setLocation(0.3)
	}
	return conn;

}
//删除端点连线
L.instance.deleteConnection = function(instance, conn) {
	instance.deleteConnection(conn);
}
//创建节点和所带端点并携带数据
L.instance.createNode = function(instance, option,view,propertys) {
	var defaults = {
		"type": "Rect",
		"nodeId": "",
		"nodeStyle": {
			"x": 320,
			"y": 140,
			"width": 156,
			"height": 60,
			"borderWidth": "2px",
			"borderColor": "rgb(102, 102, 102)",
			"borderRadius":"0px",
			"background": "white",
			"font":{
				"fontSize":"12px",
				"color":"#000000",
				"fontWeight":"normal"
			}
		},
		"scope":"scope"
	}
	
	option = $.extend(true, {}, defaults, option);
	
	L.instance.nodes.push(option.nodeId);
	
	var node = L.instance.createBlock(instance, option.type, option.nodeId, {
		x: option.nodeStyle.x + 'px',
		y: option.nodeStyle.y + 'px'
	}, parseInt(option.nodeStyle.width), parseInt(option.nodeStyle.height), parseInt(option.nodeStyle.borderWidth), option.nodeStyle.borderColor, option.nodeStyle.borderRadius, option.nodeStyle.font,option.nodeStyle.background,option.content,view,option.propertys);
	if(node){
		node.data = option;
		
		if(propertys&&propertys.length>0){
			node.propertysMode=propertys;
			var unableSave=false;
			for(var i=0;i<propertys.length;i++){
				for(var key in node.data.propertys){
					if(key==propertys[i].name){
						propertys[i].defaultValue=node.data.propertys[key]
					}
				}
			}
			for(var i=0;i<propertys.length;i++){
				if(propertys[i].required==0&&!propertys[i].defaultValue&&propertys[i].defaultValue!=0){
					unableSave=true
				}
			}
			node.unableSave=unableSave;
			if(unableSave){
				$(node).addClass('unableSave');
			}
		}
		//L.instance.createPoint(instance, node,option.scope,view)
		
		
	}
	window.nodes=node;
	return node;
}
//增加端点连线并携带数据
L.instance.createLine = function(instance, option) {
	var defaults = {
		"type": "Line",
		"sourceId": "",
		"targetId": "",
		"label": ""
	}
	option = $.extend(true, {}, defaults, option);
	var conn = L.instance.connectPoints(instance, option.sourceId, option.targetId, option.label, true);
	if(conn){
		conn.data = option;
	}
	return conn;
}
//创建视图模式流程图
L.instance.createView = function(instance, data) {
	for(var i = 0; i < data.length; i++) {
		if(data[i].type == 'note') {
			L.instance.createNote(data[i])
		}
		else if(data[i].type != 'Line') {
			L.instance.createNode(instance, data[i],'view')
		} else {
			L.instance.createLine(instance, data[i])
		}
		//instance.draggable($('.node'), {
			//containment: true
		//});
	}
	
}
//ajax获取数据
L.instance.ajaxData = function(url,fun) {
	var res=$.get(url).then(function(result) {
		if(fun){fun(result)}
	});
	
}
//删除视图模式流程图
L.instance.removeView = function(instance) {
	instance.deleteEveryConnection();
	instance.deleteEveryEndpoint();
	$(instance.getContainer()).find('.node').remove();
	$('.rx-container-note').html('');
	if(window.noteData){
		window.noteData={"type":"note","value":[]};
	}
}
//创建编辑模式流程图
L.instance.createEditView = function(instance, data) {
	for(var i = 0; i < data.length; i++) {
		if(data[i].type == 'note') {
			L.instance.createNote(data[i])
		}
		else if(data[i].type != 'Line') {
			L.instance.createNode(instance,data[i])
		} else {
			L.instance.createLine(instance, data[i])
		}
		instance.draggable($('.node'), {
			containment: true
		});
	}
	
}
//删除编辑模式流程图
L.instance.removeEditView = function(instance) {
	instance.deleteEveryConnection();
	instance.deleteEveryEndpoint();
	$(instance.getContainer()).find('.node').remove();
	$('.rx-container-note').html('');
	if(window.noteData){
		window.noteData={"type":"note","value":[]};
	}
}

//获取流程数据
L.instance.getInstanceData = function(instance,fun){
	var data=[];
	var nodes=$(instance.getContainer()).find('.node');
	var len=nodes.length;
	var unableSave=false;
	var unableSaveNode=[];
	for(var i=0;i<len;i++){
		if(nodes[i].unableSave){
			unableSave=true;
			unableSaveNode.push(nodes[i].data.content)
		}
		data.push(nodes[i].data)
	}
	instance.select().each(function(connection) {
			data.push(connection.data)
		
});
if(window.noteData&&window.noteData.value&&window.noteData.value.length>0){
	data.push(noteData)
}
if(fun){
	fun(JSON.parse(JSON.stringify(data)),unableSave,unableSaveNode);
	}else{
		return JSON.parse(JSON.stringify(data))
	}

}
