
function nodeEditInit(instance, node) {
    var L=window.top.L;
    var sourceEndPoint = JSON.parse(JSON.stringify(node.data.sourceEndPoint));
    var targetEndPoint = JSON.parse(JSON.stringify(node.data.targetEndPoint));
    Vue.component('component-endpoint', function(resolve, reject) { //流程图
		$.get("../endPointEdit.html").then(function(res) {
			resolve({
                template: res,
                data: function(){
                    return {
                        nodeType: node.data.type,
                        sourceEndPoint: sourceEndPoint,
                        targetEndPoint: targetEndPoint,
                        selects: []
                    }
                },
                created: function () {
                    this.setEndPointType()
                    this.setSelects()
                },
                watch: {
                    sourceEndPoint: function (val) {
                        this.$emit('update:sourcePoint', val);
                    }
                },
                methods: {
                    setEndPointType: function () {
                        this.sourceEndPoint.forEach(function (item) {
                            item.edit = 'select'
                        });
                        this.targetEndPoint.forEach(function (item) {
                            item.edit = 'select'
                        });
                    },
                    setSelects: function () {
                        this.selects = JSON.parse(JSON.stringify(L.nodeConfig.edit[this.nodeType].selectOption));
                    },
                    changeEditSourceEndPointModule: function (index) {
                        if (this.sourceEndPoint[index].edit == 'select') {
                            this.sourceEndPoint[index].edit = 'input'
                        } else {
                            this.sourceEndPoint[index].edit = 'select'
                        }
                        Vue.set(this.sourceEndPoint, index, this.sourceEndPoint[index]);
        
                    },
                    inputChangeSourceEndPointPos: function (value, uuid) {
                        var _this = this;
                        for (var i = 0; i < this.sourceEndPoint.length; i++) {
                            if (this.sourceEndPoint[i].uuid == uuid) {
                                this.sourceEndPoint[i].position = value;
                            }
                        }
                    },
                    modifySourceEndPointPos: function (event, uuid, type) { //修改端点位置
                        var _this = this;
        
                        for (var i = 0; i < this.sourceEndPoint.length; i++) {
                            if (this.sourceEndPoint[i].uuid == uuid) {
                                changePos(this.sourceEndPoint[i].position, this.sourceEndPoint[i].uuid, this, function () {
                                    node.data.sourceEndPoint[i].position = _this.sourceEndPoint[i].position;
                                });
        
                            }
                        }
        
                        function changePos(pos, uuid, _this, fun) {
                            if (!pos) {
                                window.top.Vue.prototype.bus.$emit('errorMes','值为空，未修改！');
                                return
                            }
                            var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
                            var defaults = false;
                            var match = [false, false, false, false];
                            data.forEach(function (item) {
                                if (item == pos) {
                                    match = [true, true, true, true];
                                    defaults = true;
                                }
                            });
        
                            if (!defaults) {
                                pos = pos.split(',');
                                if (pos.length != 4) {
                                    window.top.Vue.prototype.bus.$emit('errorMes','格式错误，未修改！');
                                } else {
                                    pos.forEach(function (item, index) {
                                        pos[index] = parseFloat(item);
                                        if (index == 0 || index == 1) {
                                            if (item > 1 || item < -1) {
                                                window.top.Vue.prototype.bus.$emit('errorMes','格式错误，未修改！');
                                            } else {
                                                match[index] = true;
                                            }
                                        } else {
                                            if (item == 0 || item == 1 || item == -1) {
                                                match[index] = true;
                                            } else {
                                                window.top.Vue.prototype.bus.$emit('errorMes','格式错误，未修改！');
                                            }
                                        }
        
                                    });
                                }
        
                            }
                            for (var i = 0; i < match.length; i++) {
                                if (!match[i]) {
                                    return false
                                }
                            }
                            var nodes = null;
                            if (type == "target") {
                                nodes = instance.selectEndpoints({
                                    target: node.data.nodeId
                                });
                            } else if (type == "source") {
                                nodes = instance.selectEndpoints({
                                    source: node.data.nodeId
                                });
                            }
                            var len = nodes.length;
                            for (var j = 0; j < len; j++) {
                                if (nodes.get(j).getUuid() == uuid) {
                                    nodes.get(j).setAnchor(pos);
                                    window.top.Vue.prototype.bus.$emit('successMes','端点位置修改成功！');

                                }
                            }
                            if (fun) {
                                fun()
                            }
                        }
        
                    },
                    removeSourceEndPoint: function (uuid, type) {
                        var arr = [];
                        for (var i = 0; i < this.sourceEndPoint.length; i++) {
                            if (this.sourceEndPoint[i].uuid != uuid) {
                                arr.push(this.sourceEndPoint[i]);
                            }
                        }
                        this.sourceEndPoint = arr;
        
                        var arr1 = [];
                        for (var i = 0; i < node.data.sourceEndPoint.length; i++) {
                            if (node.data.sourceEndPoint[i].uuid != uuid) {
                                arr1.push(node.data.sourceEndPoint[i]);
                            }
                        }
                        node.data.sourceEndPoint = arr1;
                        instance.deleteEndpoint(uuid);
                    },
        
                    addSourceEndPoint: function (type) {
                        var uuid = node.data.nodeId + '-out-' + parseInt(Math.random(0, 1) * 10000000);
                        var position = this.nodeType == 'Rect' ? "TopRight" : "Right";
                        L.instance.createPoint(instance, node, uuid, type, position, 'scope');
                        this.sourceEndPoint.push({
                            "uuid": uuid,
                            "type": type,
                            "position": position,
                            "edit": "select"
                        });
                        node.data.sourceEndPoint.push({
                            "uuid": uuid,
                            "type": type,
                            "position": position
                        });
                    },
                    changeEditTargetEndPointModule: function (index, type) {
                        if (this.targetEndPoint[index].edit == 'select') {
                            this.targetEndPoint[index].edit = 'input'
                        } else {
                            this.targetEndPoint[index].edit = 'select'
                        }
                        Vue.set(this.targetEndPoint, index, this.targetEndPoint[index]);
        
                    },
                    inputChangeTargetEndPointPos: function (value, uuid, type) {
                        var _this = this;
                        for (var i = 0; i < this.targetEndPoint.length; i++) {
                            if (this.targetEndPoint[i].uuid == uuid) {
                                this.targetEndPoint[i].position = value;
                            }
                        }
                    },
                    modifyTargetEndPointPos: function (event, uuid, type) { //修改端点位置
                        var _this = this;
        
                        for (var i = 0; i < this.targetEndPoint.length; i++) {
                            if (this.targetEndPoint[i].uuid == uuid) {
                                changePos(this.targetEndPoint[i].position, this.targetEndPoint[i].uuid, this, function () {
                                    node.data.targetEndPoint[i].position = _this.targetEndPoint[i].position;
                                });
        
                            }
                        }
        
                        function changePos(pos, uuid, _this, fun) {
                            if (!pos) {
                                window.top.Vue.prototype.bus.$emit('errorMes','值为空，未修改！');
                                return
                            }
                            var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
                            var match = [false, false, false, false];
                            var defaults = false;
                            data.forEach(function (item) {
                                if (item === pos) {
                                    match = [true, true, true, true];
                                    defaults = true;
                                }
                            });
                            if (!defaults) {
                                pos = pos.split(',');
                                if (pos.length != 4) {
                                    window.top.Vue.prototype.bus.$emit('errorMes','格式错误，未修改！');
                                } else {
                                    pos.forEach(function (item, index) {
                                        pos[index] = parseFloat(item);
                                        if (index == 0 || index == 1) {
                                            if (item > 1 || item < -1) {
                                                window.top.Vue.prototype.bus.$emit('errorMes','格式错误，未修改！');
                                            } else {
                                                match[index] = true;
                                            }
                                        } else {
                                            if (item == 0 || item == 1 || item == -1) {
                                                match[index] = true;
                                            } else {
                                                window.top.Vue.prototype.bus.$emit('errorMes','格式错误，未修改！');

                                            }
                                        }
        
                                    });
                                }
        
                            }
                            for (var i = 0; i < match.length; i++) {
                                if (!match[i]) {
                                    return false
                                }
                            }
        
                            var nodes = null;
                            if (type == "target") {
                                nodes = instance.selectEndpoints({
                                    target: node.data.nodeId
                                });
                            } else if (type == "source") {
                                nodes = instance.selectEndpoints({
                                    source: node.data.nodeId
                                });
                            }
                            var len = nodes.length;
                            for (var j = 0; j < len; j++) {
                                if (nodes.get(j).getUuid() == uuid) {
                                    nodes.get(j).setAnchor(pos);
                                    window.top.Vue.prototype.bus.$emit('successMes','端点位置修改成功！');
                                }
                            }
                            if (fun) {
                                fun()
                            }
                        }
                    },
                    removeTargetEndPoint: function (uuid, type) {
                        var arr = [];
                        for (var i = 0; i < this.targetEndPoint.length; i++) {
                            if (this.targetEndPoint[i].uuid != uuid) {
                                arr.push(this.targetEndPoint[i]);
                            }
                        }
                        this.targetEndPoint = arr;
        
                        var arr1 = [];
                        for (var i = 0; i < node.data.targetEndPoint.length; i++) {
                            if (node.data.targetEndPoint[i].uuid != uuid) {
                                arr1.push(node.data.targetEndPoint[i]);
                            }
                        }
                        node.data.targetEndPoint = arr1;
                        instance.deleteEndpoint(uuid);
                    },
                    addTargetEndPoint: function (type) {
                        var uuid = node.data.nodeId + '-in-' + parseInt(Math.random(0, 1) * 10000000);
                        var position = this.nodeType == 'Rect' ? "TopLeft" : "Left";
                        L.instance.createPoint(instance, node, uuid, type, position, 'scope');
                        this.targetEndPoint.push({
                            "uuid": uuid,
                            "type": type,
                            "position": position,
                            "edit": "select"
                        });
                        node.data.targetEndPoint.push({
                            "uuid": uuid,
                            "type": type,
                            "position": position
                        });
                    }
                }
            })
		});
	});
    new Vue({
        el: '#app',
        data: {
           
        },
        created: function () {
            
        },
       
        methods: {
           
        }
    });
}
