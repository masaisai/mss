L.nodeConfig={
    module:{
        "mode-0":{
            "type": "Note",
            "nodeStyle": {
                "width": 120,
                "height": 40,
                "borderWidth": "1px",
                "borderColor": "#FFE54F",
                "borderRadius": "3px",
                "background": "#FFF6B5",
                "font": {
                    "fontSize": "12px",
                    "color": "#B53F00",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [],
            "targetEndPoint": [],
            "template":''
        },
         "mode-1":{
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "borderRadius": "0px",
                "background": "#ffffff",
                "font": {
                    "fontSize": "14px",
                    "color": "#333333",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template":''
        },
        "mode-2":{
            "type": "Ellipse",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "#ffffff",
                "font": {
                    "color": "#333333",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
        },
        "mode-3":{
        "type": "Prismatic",
        "nodeStyle": {
            "width": 120,
            "height": 70,
            "borderWidth": 2,
            "borderColor": "#333333",
            "background": "#ffffff",
            "font": {
                "color": "#333333",
                "fontSize": "14px",
                "fontWeight": "400"
            }
        },
        "sourceEndPoint": [{
            "type": "source",
            "position": "Right"
        }],
        "targetEndPoint": [{
            "type": "target",
            "position": "Left"
        }]
    },
        "mode-4":{
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "#333333",
                "borderRadius": "0px",
                "font": {
                    "color": "#ffffff",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-5":{"type": "Ellipse",
        "nodeStyle": {
            "width": 120,
            "height": 70,
             "borderWidth": "2px",
             "borderColor": "#333333",
            "background": "#333333",
             "font": {
                "color": "#ffffff",
                "fontSize": "14px",
                "fontWeight": "400"
            }
        },
        "sourceEndPoint": [{
            "type": "source",
            "position": "Right"
        }],
        "targetEndPoint": [{
            "type": "target",
            "position": "Left"
        }]
    },
        "mode-6":{
            "type": "Prismatic",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth":2,
                "borderColor": "#333333",
                "background": "#333333",
                "font": {
                    "color": "#ffffff",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-7":{
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "borderRadius": "0px",
                "background": "#ffffff",
                "font": {
                    "fontSize": "14px",
                    "color": "#333333",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template":"<div class='node-mode-wrap'><div class='node-mode-icon'><i class='el-icon-picture-outline'></i></div><div class='node-mode-content'>{{content}}</div></div>"
        },
        "mode-8":{
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "#333333",
                "borderRadius": "0px",
                "font": {
                    "color": "#ffffff",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template":"<div class='node-mode-wrap dark'><div class='node-mode-icon'><i class='el-icon-picture-outline'></i></div><div class='node-mode-content'>{{content}}</div></div>"

        },
        "mode-9":{
            "type": "Rect",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "#ffffff",
                "borderRadius": "0px",
                "font": {
                    "color": "#333333",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template":"<div class='node-mode-wrap full'><div class='node-mode-icon'><i class='fa fa-pie-chart'></i></div></div>"

        },
        "mode-10":{
            "type": "Prismatic",
            "nodeStyle": {
                "width": 120,
                "height": 70,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "#ffffff",
                "borderRadius": "0px",
                "font": {
                    "color": "#333333",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template":"<div class='node-mode-wrap full'><div class='node-mode-icon'><i class='fa fa-user'></i></div></div>"

        },
        "mode-11":{
            "type": "Rect",
            "nodeStyle": {
                "width": 100,
                "height": 100,
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "#ffffff",
                "borderRadius": "0px",
                "font": {
                    "color": "#333333",
                    "fontSize": "14px",
                    "fontWeight": "400"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }],
            "template":"<div class='node-mode-wrap full'><div class='node-mode-icon'><i class='fa fa-users'></i></div>{{content}}</div>"

        },
            
    },
    edit:{
        Rect:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            },
            {
                value: "TopLeft",
                text: "左上"
            },
            {
                value: "BottomLeft",
                text: "左下"
            },
            {
                value: "TopRight",
                text: "右上"
            },
            {
                value: "BottomRight",
                text: "右下"
            }
        ]
        
        },
        Ellipse:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            }
        ]
        },
        Prismatic:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            }
        ]
        }
    }
}