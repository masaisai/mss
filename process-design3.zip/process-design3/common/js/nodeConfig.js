L.nodeConfig={
    module:{
         "mode-1":{
            "type": "Rect",
            "nodeStyle": {
                "borderWidth": "4px",
                "borderColor": "rgb(4, 41, 177)",
                "background": "rgb(22, 133, 252)",
                "borderRadius": "4px",
                "font":{
                    "fontSize":"12px",
				"color":"#ffffff",
				"fontWeight":"normal"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": []
        },
        "mode-2":{
            "type": "Rect",
            "nodeStyle": {
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "white",
                "borderRadius": "0px",
                "font":{
                    "fontSize":"12px",
				"color":"#000000",
				"fontWeight":"normal"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }]
        },
        "mode-3":{
        "type": "Ellipse",
        "nodeStyle": {
            "borderWidth": "2px",
            "borderColor": "#333333",
            "background": "white",
            "font":{
                "fontSize":"12px",
            "color":"#000000",
            "fontWeight":"normal"
            }
        },
        "sourceEndPoint": [{
            "type": "source",
            "position": "Right"
        }],
        "targetEndPoint": [{
            "type": "target",
            "position": "Left"
        }]},
        "mode-4":{
            "type": "Rect",
            "nodeStyle": {
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "white",
                "borderRadius": "0px",
                "font":{
                    "fontSize":"12px",
				"color":"#000000",
				"fontWeight":"normal"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-5":{"type": "Ellipse",
        "nodeStyle": {
            "borderWidth": "2px",
            "borderColor": "#333333",
            "background": "white",
            "font":{
                "fontSize":"12px",
            "color":"#000000",
            "fontWeight":"normal"
            }
        },
        "sourceEndPoint": [{
            "type": "source",
            "position": "Right"
        }],
        "targetEndPoint": [{
            "type": "target",
            "position": "Left"
        }]},
        "mode-6":{
            "type": "Ellipse",
            "nodeStyle": {
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "white",
                "font":{
                    "fontSize":"12px",
				"color":"#000000",
				"fontWeight":"normal"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-7":{
            "type": "Ellipse",
            "nodeStyle": {
                "borderWidth": "2px",
                "borderColor": "#333333",
                "background": "white",
                "font":{
                    "fontSize":"12px",
				"color":"#000000",
				"fontWeight":"normal"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
        "mode-8":{
            "type": "Prismatic",
            "nodeStyle": {
                "borderWidth": "4px",
                "borderColor": "red",
                "background": "#dddddd",
                "font":{
                    "fontSize":"12px",
				"color":"#000000",
				"fontWeight":"normal"
                }
            },
            "sourceEndPoint": [{
                "type": "source",
                "position": "Right"
            }],
            "targetEndPoint": [{
                "type": "target",
                "position": "Left"
            }]
        },
            
    },
    edit:{
        Rect:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            },
            {
                value: "TopLeft",
                text: "左上"
            },
            {
                value: "BottomLeft",
                text: "左下"
            },
            {
                value: "TopRight",
                text: "右上"
            },
            {
                value: "BottomRight",
                text: "右下"
            }
        ]
        
        },
        Ellipse:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            }
        ]
        },
        Prismatic:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            }
        ]
        }
    }
}