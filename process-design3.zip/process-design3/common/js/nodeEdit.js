
L.instance.nodeEdit = function(instance, node) {
	Vue.component('component-sourcepoint', function(resolve, reject) { 
		$.get("./components/sourcePoint.html").then(function(res) {
			resolve({
				template: res,
				props: ['sourcePoint','nodeTypeTransform'],
				data: function() {
					return {
						nodeType:this.nodeTypeTransform,
						sourceEndPoint: this.sourcePoint
					}
				},
				created: function() {
					var _this = this;
				},
				methods: {
					addEndPoint: function(type) {
						var uuid = node.data.nodeId + '-out-'  + parseInt(Math.random(0, 1) * 10000000);
						var position=this.nodeType=='Rect'?"TopRight":"Right";
						L.instance.createPoint(instance, node, uuid, type, position, 'scope');
						this.sourceEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position": position,
							"edit": "select"
						});
						node.data.sourceEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position":position
						});
					}

				}
			})
		});
	});
		Vue.component('component-sourcepointedit', function(resolve, reject) { 
		$.get("./components/sourcePointEdit.html").then(function(res) {
			resolve({
				template: res,
				props: ['sourcePoint','nodeTypeTransform'],
				data: function() {
					return {
						sourceEndPoint: this.sourcePoint,
						nodeType:this.nodeTypeTransform,
						selects:[]
					}
				},
				created: function() {
					this.setSelects()
				},
				watch:{
					sourceEndPoint:function(val){
                	this.$emit('update:sourcePoint', val);
           		 }
				},
				methods: {
					setSelects:function(){
						this.selects=L.nodeConfig.edit[this.nodeType].selectOption;
					},
					changeEditEndPointModule: function(index) {
						if(this.sourceEndPoint[index].edit == 'select') {
							this.sourceEndPoint[index].edit = 'input'
						} else {
							this.sourceEndPoint[index].edit = 'select'
						}
						Vue.set(this.sourceEndPoint, index, this.sourceEndPoint[index]);

					},
					inputChangeEndPointPos: function(value, uuid) {
						var _this=this;
						/*if(!value) {
							this.$message.error('值为空，未修改！');
							return
						}
						var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
						var match =[ false, false, false, false];
						var defaults=false;
						data.forEach(function(item) {
							if(item == value) {
								match = [true, true, true, true];
								defaults=true;
							}
						});
						if(!defaults) {
							result = value.split(',');
							if(result.length != 4) {
								this.$message.error('格式错误，未修改！');
							} else {
								result.forEach(function(item, index) {
									if(index==0||index==1){
										if(item > 1 || item < -1) {
											_this.$message.error('格式错误，未修改！');
										}else{
											match[index]=true;
										}
									}else{
										if(item==0||item==1||item==-1){
											match[index]=true;
										}else{
											_this.$message.error('格式错误，未修改！');
										}
									}
									
								});
							}
							
						}
						for(var i=0;i<match.length;i++){
							if(!match[i]){
								return false
							}
						}*/
						
						for(var i = 0; i < this.sourceEndPoint.length; i++) {
							if(this.sourceEndPoint[i].uuid == uuid) {
								this.sourceEndPoint[i].position = value;
							}
						}
					},
					modifyEndPointPos: function(event, uuid, type) { //修改端点位置
						var _this=this;
						
						for(var i = 0; i < this.sourceEndPoint.length; i++) {
							if(this.sourceEndPoint[i].uuid == uuid) {
								changePos(this.sourceEndPoint[i].position, this.sourceEndPoint[i].uuid,this,function(){
									node.data.sourceEndPoint[i].position = _this.sourceEndPoint[i].position;
								});
								
							}
						}
						function changePos(pos, uuid,_this,fun) {
							if(!pos) {
								this.$message.error('值为空，未修改！');
								return
							}
							var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
							var defaults=false;
							var match = [false,false,false,false];
							data.forEach(function(item) {
								if(item == pos) {
									match =[true,true,true,true] ;
									defaults=true;
								}
							});
							
							if(!defaults) {
								pos = pos.split(',');
								if(pos.length != 4) {
									this.$message.error('格式错误，未修改！');
								} else {
									pos.forEach(function(item, index) {
										pos[index] = parseFloat(item);
										if(index==0||index==1){
											if(item > 1 || item < -1) {
												_this.$message.error('格式错误，未修改！');
											}else{
												match[index]=true;
											}
										}else{
											if(item==0||item==1||item==-1){
												match[index] = true;
											}else{
												_this.$message.error('格式错误，未修改！');
											}
										}
										
									});
								}
								
							}
							for(var i=0;i<match.length;i++){
								if(!match[i]){
									return false
								}
							}
							var nodes = null;
							if(type == "target") {
								nodes = instance.selectEndpoints({
									target: node.data.nodeId
								});
							} else if(type == "source") {
								nodes = instance.selectEndpoints({
									source: node.data.nodeId
								});
							}
							var len = nodes.length;
							for(var j = 0; j < len; j++) {
								if(nodes.get(j).getUuid() == uuid) {
									nodes.get(j).setAnchor(pos);
									_this.$message.success('端点位置修改成功！');
								}
							}
						if(fun){fun()}
						}
						
					},
					removeEndPoint: function(uuid, type) {
						var arr = [];
						for(var i = 0; i < this.sourceEndPoint.length; i++) {
							if(this.sourceEndPoint[i].uuid != uuid) {
								arr.push(this.sourceEndPoint[i]);
							}
						}
						this.sourceEndPoint = arr;
						
						var arr1 = [];
						for(var i = 0; i < node.data.sourceEndPoint.length; i++) {
							if(node.data.sourceEndPoint[i].uuid != uuid) {
								arr1.push(node.data.sourceEndPoint[i]);
							}
						}
						node.data.sourceEndPoint = arr1;
						instance.deleteEndpoint(uuid);
					},
				}
			})
		});
	});
	Vue.component('component-targetpoint', function(resolve, reject) { //流程图
		$.get("./components/targetPoint.html").then(function(res) {
			resolve({
				template: res,
				props: ['targetPoint','nodeTypeTransform'],
				data: function() {
					return {
						targetEndPoint: this.targetPoint,
						nodeType:this.nodeTypeTransform,
						selects:[]
					
					}
				},
				created: function() {
					var _this = this;
				},
				
				methods: {
					changeEndPointPos: function(value, uuid, type) { //select切换
					},
					addEndPoint: function(type) {
						var uuid = node.data.nodeId + '-in-'  + parseInt(Math.random(0, 1) * 10000000);
						var position=this.nodeType=='Rect'?"TopLeft":"Left";
						L.instance.createPoint(instance, node, uuid, type, position, 'scope');
						this.targetEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position":position,
							"edit": "select"
						});
						node.data.targetEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position":position
						});
					}
				
				}
			})
		});
	});
		Vue.component('component-targetpointedit', function(resolve, reject) { //流程图
		$.get("./components/targetPointEdit.html").then(function(res) {
			resolve({
				template: res,
				props: ['targetPoint','nodeTypeTransform'],
				data: function() {
					return {
						targetEndPoint: this.targetPoint,
						nodeType:this.nodeTypeTransform,
						selects:[]
					}
				},
				created: function() {
					this.setSelects();
				},
				watch:{
					targetEndPoint:function(val){
                	this.$emit('update:targetPoint', val);
           		 }
				},
				methods: {
					setSelects:function(){
						this.selects=L.nodeConfig.edit[this.nodeType].selectOption;
					},
					changeEditEndPointModule: function(index, type) {
						if(this.targetEndPoint[index].edit == 'select') {
							this.targetEndPoint[index].edit = 'input'
						} else {
							this.targetEndPoint[index].edit = 'select'
						}
						Vue.set(this.targetEndPoint, index, this.targetEndPoint[index]);

					},
					inputChangeEndPointPos: function(value, uuid, type) {
						var _this=this;
						/*if(!value) {
							this.$message.error('值为空，未修改！');
							return
						}
						var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
						var match = [false,false,false,false];
						var defaults=false;
						data.forEach(function(item) {
							if(item == value) {
								match = [true,true,true,true];
								defaults=true;
							}
						});
						if(!defaults) {
							var result = value.split(',');
							if(result.length != 4) {
								this.$message.error('格式错误，未修改！');
							} else {
								result.forEach(function(item, index) {
									if(index==0||index==1){
										if(item > 1 || item < -1) {
											_this.$message.error('格式错误，未修改！');
										}else{
											match[index]=true;
										}
									}else{
										if(item==0||item==1||item==-1){
											match[index]= true;
										}else{
											_this.$message.error('格式错误，未修改！');
										}
									}
									
								});
							}
							
						}
						for(var i=0;i<match.length;i++){
							if(!match[i]){
								return false
							}
						}*/

						for(var i = 0; i < this.targetEndPoint.length; i++) {
							if(this.targetEndPoint[i].uuid == uuid) {
								this.targetEndPoint[i].position = value;
							}
						}
					},
					modifyEndPointPos: function(event, uuid, type) { //修改端点位置
						var _this=this;

						for(var i = 0; i < this.targetEndPoint.length; i++) {
							if(this.targetEndPoint[i].uuid == uuid) {
								changePos(this.targetEndPoint[i].position, this.targetEndPoint[i].uuid,this,function(){
									node.data.targetEndPoint[i].position = _this.targetEndPoint[i].position;
								});
								
							}
						}

						function changePos(pos, uuid,_this,fun) {
							if(!pos) {
								this.$message.error('值为空，未修改！');
								return
							}
							var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
							var match =[false,false,false,false];
							var defaults=false;
							data.forEach(function(item) {
								if(item ===pos) {
									match = [true,true,true,true];
									defaults=true;
								}
							});
							if(!defaults) {
								pos = pos.split(',');
								if(pos.length != 4) {
									this.$message.error('格式错误，未修改！');
								} else {
									pos.forEach(function(item, index) {
										pos[index] = parseFloat(item);
										if(index==0||index==1){
											if(item > 1 || item < -1) {
												_this.$message.error('格式错误，未修改！');
											}else{
												match[index]=true;
											}
										}else{
											if(item==0||item==1||item==-1){
												match[index] = true;
											}else{
												_this.$message.error('格式错误，未修改！');
											}
										}
										
									});
								}
								
							}
							for(var i=0;i<match.length;i++){
								if(!match[i]){
									return false
								}
							}

							var nodes = null;
							if(type == "target") {
								nodes = instance.selectEndpoints({
									target: node.data.nodeId
								});
							} else if(type == "source") {
								nodes = instance.selectEndpoints({
									source: node.data.nodeId
								});
							}
							var len = nodes.length;
							for(var j = 0; j < len; j++) {
								if(nodes.get(j).getUuid() == uuid) {
									nodes.get(j).setAnchor(pos);
									_this.$message.success('端点位置修改成功！');
								}
							}
								if(fun){fun()}
						}
					},
					removeEndPoint: function(uuid, type) {
						var arr = [];
						for(var i = 0; i < this.targetEndPoint.length; i++) {
							if(this.targetEndPoint[i].uuid != uuid) {
								arr.push(this.targetEndPoint[i]);
							}
						}
						this.targetEndPoint = arr;
						
						var arr1 = [];
						for(var i = 0; i < node.data.targetEndPoint.length; i++) {
							if(node.data.targetEndPoint[i].uuid != uuid) {
								arr1.push(node.data.targetEndPoint[i]);
							}
						}
						node.data.targetEndPoint = arr1;
						instance.deleteEndpoint(uuid);
					},
				}
			})
		});
	});
		Vue.component('component-nodecontent', function(resolve, reject) { //流程图
		$.get("./components/nodeContent.html").then(function(res) {
			
			resolve({
				template: res,
				props: ['nodeContent'],
				data: function() {
					return {
						content: this.nodeContent
					}
				},
				created: function() {
				
				},
				methods: {
					saveNodeContent: function() {
						
            			//var string=L.compileTemple(this.content,node.data.propertys);
						node.getElementsByClassName('node-example-text')[0].innerHTML = this.content;
						node.data.content = this.content;
					}
				}

			})
		});
	});
	Vue.component('component-nodepropertys', function(resolve) { //流程图
		$.get("./components/nodePropertys.html").then(function(res) {
			
			resolve({
				template: res,
				props: ['nodeGroup'],
				data: function() {
					return {
						group:this.nodeGroup,
						propertys:[]
					}
				},
				mounted: function() {
					var _this=this;
					$.ajax({
						url:"common/data/module/"+node.data.groupId+".json",
						get:'get',
						success:function(res){
							var propertys=res.attribute;
							if(propertys&&propertys.length>0){
								node.propertysMode=propertys;
								var unableSave=false;
								for(var i=0;i<propertys.length;i++){
									for(var key in node.data.propertys){
										if(key==propertys[i].name){
											propertys[i].defaultValue=node.data.propertys[key]
										}
									}
								}
								
								for(var i=0;i<propertys.length;i++){
									if(propertys[i].required==0&&!propertys[i].defaultValue&&propertys[i].defaultValue!=0){
										unableSave=true
									}
								}
								node.unableSave=unableSave;
								if(unableSave){
									$(node).addClass('unableSave');
								}
							}
							_this.propertys =propertys;
						_this.setPropertys(_this.propertys);
					}
				});
					
				},
				methods: {
					setPropertys: function(propertys) {
						var arr = [];
						for(var i = 0; i < propertys.length; i++) {
							var obj = {
								"edit": false,
								"valid":true,
								"autofocus":true
							};
							for(var key in propertys[i]){
								obj[key]=propertys[i][key];
							}
						
							obj["copyValue"]=propertys[i]["defaultValue"];
							if(obj["sourceData"]){
								obj["sourceData"]=JSON.parse(JSON.stringify(obj["sourceData"]));
							}
							arr.push(obj);
						}
						this.propertys = arr;
					},
					
					editPropertys: function(index,event) {
						this.propertys[index].edit = !this.propertys[index].edit;
						setTimeout(function(){
							$(event.target).parents('td').siblings().find('input').focus()
						},10)
					},
					savePropertys: function(index,event) {
						var obj=$(event.target).parents('td').siblings().find('input');
						if(obj.length>0){
							this.inputValueChange(obj,index,'save')
						}
						if(!this.propertys[index].valid){return false}
						this.propertys[index].edit = !this.propertys[index].edit;
						this.propertys[index]["copyValue"]=this.propertys[index]["defaultValue"];
						var jsonObj = {};
						for(var i = 0; i < this.propertys.length; i++) {
							jsonObj[this.propertys[i].name]=this.propertys[i].defaultValue
						}
						node.data.propertys = JSON.parse(JSON.stringify(jsonObj));
						this.authUnableSave()
					},
					inputValueChange:function(event,index,save){
						if(this.propertys[index].required!=0){return}
						var obj='';
						if(save){
							obj=event
						}else{
							obj=$(event.target)
						}
						var value=obj.val()
						
						if(!value){
							if(event){
								obj.parent().addClass('is-error');
								this.propertys[index].valid=false;
								this.$message.error('必填项，不能为空！');
							}
						}else{
							if(event){
								obj.parent().removeClass('is-error')
								this.propertys[index].valid=true
							}
						}
						
					},
					authUnableSave:function(){
						var propertys=JSON.parse(JSON.stringify(node.propertysMode))
						var unableSave=false;
						for(var i=0;i<propertys.length;i++){
							for(var key in node.data.propertys){
								if(key==propertys[i].name){
									propertys[i].defaultValue=node.data.propertys[key]
								}
							}
						}
						for(var i=0;i<propertys.length;i++){
							if(propertys[i].required==0&&!propertys[i].defaultValue&&propertys[i].defaultValue!=0){
								unableSave=true
							}
						}
						node.unableSave=unableSave;
						if(unableSave){
							$(node).addClass('unableSave');
						}else{
							$(node).removeClass('unableSave');
						}
					},
					cancelEdit: function(index) {
						this.propertys[index]["defaultValue"]=this.propertys[index]["copyValue"];
						this.propertys[index].edit = !this.propertys[index].edit;
						

					}
				}

			})
		});
	});
	Vue.component('component-nodestyles', function(resolve) { 
		$.get("./components/nodeStyles.html").then(function(res) {
			
			resolve({
				template: res,
				props: ['nodeTypeTransform','nodeStyleTransform'],
				data: function() {
					return {
						nodeType: this.nodeTypeTransform,
						nodeStyle:this.nodeStyleTransform,
						borderWidth:parseInt(this.nodeStyleTransform.borderWidth),
						borderRadius:parseInt(this.nodeStyleTransform.borderRadius),
						font:{},
						fontSize:12
					}
				},
				created: function() {
					
					this.font=JSON.parse(JSON.stringify(this.nodeStyle.font));
					this.fontSize=parseInt(this.font.fontSize);
					
				},
				methods: {
					backgroundChange: function() {
						if(this.nodeType=="Prismatic"){
								node.getElementsByTagName('polygon')[0].style.fill=this.nodeStyle.background;
						}else{
							node.style.background=this.nodeStyle.background;
						}
						node.data.nodeStyle.background=this.nodeStyle.background;
					},
					borderColorChange: function() {
						if(this.nodeType=="Prismatic"){
							node.getElementsByTagName('polygon')[0].style.stroke=this.nodeStyle.borderColor;
						}else{
						node.style.borderColor=this.nodeStyle.borderColor;
						}
						node.data.nodeStyle.borderColor=this.nodeStyle.borderColor;
						},
					borderWidthChange: function() {
						if(this.nodeType=="Prismatic"){
							node.getElementsByTagName('polygon')[0].style.strokeWidth=this.borderWidth;
							var position=this.borderWidth+','+this.nodeStyle.height/2+' '+this.nodeStyle.width/2+','+this.borderWidth+' '+(this.nodeStyle.width-this.borderWidth)+','+this.nodeStyle.height/2+' '+this.nodeStyle.width/2+','+(this.nodeStyle.height-this.borderWidth);
							node.getElementsByTagName('polygon')[0].style.points=position;
						}else{
							node.style.borderWidth=this.borderWidth+"px";
						}
						node.data.nodeStyle.borderWidth=this.borderWidth+"px";	
					},
					borderRadiusChange: function() {
							node.style.borderRadius=this.borderRadius+"px";
							node.data.nodeStyle.borderRadius=this.borderRadius+"px";
					},
					fontSizeChange:function(){
						this.font.fontSize=this.fontSize;
						node.getElementsByClassName('node-example-text')[0].style.fontSize=this.font.fontSize+"px";
						node.data.nodeStyle.font=this.font;
					},
					fontWeightChange:function(){
						node.getElementsByClassName('node-example-text')[0].style.fontWeight=this.font.fontWeight;
						node.data.nodeStyle.font=this.font;
					},
					fontColorChange:function(){
						node.getElementsByClassName('node-example-text')[0].style.color=this.font.color;
						node.data.nodeStyle.font=this.font;
					}
				
				}

			})
		});
	});
	Vue.component('component-nodeeditmain', function(resolve, reject) { //流程图
		$.get("./components/nodeEdit-main.html?r="+ Math.random()).then(function(res) {
			
			resolve({
				template: res,
				props: [],
				data: function() {
					return {
						title: '',
						nodeType:'',
						content: '',
						propertys: [],
						nodeStyle:{},
						sourceEndPoint: JSON.parse(JSON.stringify(node.data.sourceEndPoint)),
						targetEndPoint: JSON.parse(JSON.stringify(node.data.targetEndPoint)),
						group:{}
					}
				},
				created: function() {
					this.setNodeType();
					this.setNodeStyle();
					this.setContent();
					this.setEndPointType();
					this.setGroup()
				},
				methods: {
					setNodeType: function() {
						this.nodeType = node.data.type;
					},
					
					setNodeStyle: function() {
						this.nodeStyle = node.data.nodeStyle;
					},
					setContent: function() {
						this.content = node.data.content
					},
					setGroup: function() {
						this.group = node.data.group;
					},
					setEndPointType: function() {
						this.sourceEndPoint.forEach(function(item) {
							item.edit = 'select'
						});
						this.targetEndPoint.forEach(function(item) {
							item.edit = 'select'
						});
					},
					
					
					
					slidePanelClose: function() {
						$.slidePanel.hide()
					}
				}

			})
		});
	});
	new Vue({
		el: '#nodeEdit'

	});

}