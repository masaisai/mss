L.nodeConfig={
    edit:{
        Rect:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            },
            {
                value: "TopLeft",
                text: "左上"
            },
            {
                value: "BottomLeft",
                text: "左下"
            },
            {
                value: "TopRight",
                text: "右上"
            },
            {
                value: "BottomRight",
                text: "右下"
            }
        ]
        
        },
        Ellipse:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            }
        ]
        },
        Prismatic:{
            selectOption:[{
                value: "Top",
                text: "上"
            },
            {
                value: "Bottom",
                text: "下"
            },
            {
                value: "Left",
                text: "左"
            },
            {
                value: "Right",
                text: "右"
            }
        ]
        }
    }
}