L.instance.nodeEdit = function(instance, node) {
	Vue.component('component-sourcepoint', function(resolve, reject) { 
		$.get("./components/sourcePoint.html").then(function(res) {
			resolve({
				template: res,
				props: ['sourcePoint'],
				data: function() {
					return {
						sourceEndPoint: this.sourcePoint
					}
				},
				created: function() {
					var _this = this;
				},
				methods: {
					addEndPoint: function(type) {
						var uuid = node.data.nodeId + '-out-'  + parseInt(Math.random(0, 1) * 10000000);
						L.instance.createPoint(instance, node, uuid, type, 'TopRight', 'scope');
						this.sourceEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position": "TopRight",
							"edit": "select"
						});
						node.data.sourceEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position": "TopRight"
						});
					}

				}
			})
		});
	});
		Vue.component('component-sourcepointedit', function(resolve, reject) { 
		$.get("./components/sourcePointEdit.html").then(function(res) {
			resolve({
				template: res,
				props: ['sourcePoint'],
				data: function() {
					return {
						sourceEndPoint: this.sourcePoint,
						selects: [{
								value: "Top",
								text: "上"
							},
							{
								value: "Bottom",
								text: "下"
							},
							{
								value: "Left",
								text: "左"
							},
							{
								value: "Right",
								text: "右"
							},
							{
								value: "TopLeft",
								text: "左上"
							},
							{
								value: "BottomLeft",
								text: "左下"
							},
							{
								value: "TopRight",
								text: "右上"
							},
							{
								value: "BottomRight",
								text: "右下"
							}
						]
					}
				},
				created: function() {
				},
				watch:{
					sourceEndPoint:function(val){
                	this.$emit('update:sourcePoint', val);
           		 }
				},
				methods: {
					
					changeEditEndPointModule: function(index) {
						if(this.sourceEndPoint[index].edit == 'select') {
							this.sourceEndPoint[index].edit = 'input'
						} else {
							this.sourceEndPoint[index].edit = 'select'
						}
						Vue.set(this.sourceEndPoint, index, this.sourceEndPoint[index]);

					},
					inputChangeEndPointPos: function(value, uuid) {
						var _this=this;
						/*if(!value) {
							this.$message.error('值为空，未修改！');
							return
						}
						var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
						var match =[ false, false, false, false];
						var defaults=false;
						data.forEach(function(item) {
							if(item == value) {
								match = [true, true, true, true];
								defaults=true;
							}
						});
						if(!defaults) {
							result = value.split(',');
							if(result.length != 4) {
								this.$message.error('格式错误，未修改！');
							} else {
								result.forEach(function(item, index) {
									if(index==0||index==1){
										if(item > 1 || item < -1) {
											_this.$message.error('格式错误，未修改！');
										}else{
											match[index]=true;
										}
									}else{
										if(item==0||item==1||item==-1){
											match[index]=true;
										}else{
											_this.$message.error('格式错误，未修改！');
										}
									}
									
								});
							}
							
						}
						for(var i=0;i<match.length;i++){
							if(!match[i]){
								return false
							}
						}*/
						
						for(var i = 0; i < this.sourceEndPoint.length; i++) {
							if(this.sourceEndPoint[i].uuid == uuid) {
								this.sourceEndPoint[i].position = value;
							}
						}
					},
					modifyEndPointPos: function(event, uuid, type) { //修改端点位置
						var _this=this;
						
						for(var i = 0; i < this.sourceEndPoint.length; i++) {
							if(this.sourceEndPoint[i].uuid == uuid) {
								changePos(this.sourceEndPoint[i].position, this.sourceEndPoint[i].uuid,this,function(){
									node.data.sourceEndPoint[i].position = _this.sourceEndPoint[i].position;
								});
								
							}
						}
						function changePos(pos, uuid,_this,fun) {
							if(!pos) {
								this.$message.error('值为空，未修改！');
								return
							}
							var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
							var defaults=false;
							var match = [false,false,false,false];
							data.forEach(function(item) {
								if(item == pos) {
									match =[true,true,true,true] ;
									defaults=true;
								}
							});
							
							if(!defaults) {
								pos = pos.split(',');
								if(pos.length != 4) {
									this.$message.error('格式错误，未修改！');
								} else {
									pos.forEach(function(item, index) {
										pos[index] = parseFloat(item);
										if(index==0||index==1){
											if(item > 1 || item < -1) {
												_this.$message.error('格式错误，未修改！');
											}else{
												match[index]=true;
											}
										}else{
											if(item==0||item==1||item==-1){
												match[index] = true;
											}else{
												_this.$message.error('格式错误，未修改！');
											}
										}
										
									});
								}
								
							}
							for(var i=0;i<match.length;i++){
								if(!match[i]){
									return false
								}
							}
							var nodes = null;
							if(type == "target") {
								nodes = instance.selectEndpoints({
									target: node.data.nodeId
								});
							} else if(type == "source") {
								nodes = instance.selectEndpoints({
									source: node.data.nodeId
								});
							}
							var len = nodes.length;
							for(var j = 0; j < len; j++) {
								if(nodes.get(j).getUuid() == uuid) {
									nodes.get(j).setAnchor(pos);
									_this.$message.success('端点位置修改成功！');
								}
							}
						if(fun){fun()}
						}
						
					},
					removeEndPoint: function(uuid, type) {
						var arr = [];
						for(var i = 0; i < this.sourceEndPoint.length; i++) {
							if(this.sourceEndPoint[i].uuid != uuid) {
								arr.push(this.sourceEndPoint[i]);
							}
						}
						this.sourceEndPoint = arr;
						
						var arr1 = [];
						for(var i = 0; i < node.data.sourceEndPoint.length; i++) {
							if(node.data.sourceEndPoint[i].uuid != uuid) {
								arr1.push(node.data.sourceEndPoint[i]);
							}
						}
						node.data.sourceEndPoint = arr1;
						instance.deleteEndpoint(uuid);
					},
				}
			})
		});
	});
	Vue.component('component-targetpoint', function(resolve, reject) { //流程图
		$.get("./components/targetPoint.html").then(function(res) {
			resolve({
				template: res,
				props: ['targetPoint'],
				data: function() {
					return {
						targetEndPoint: this.targetPoint
					
					}
				},
				created: function() {
					var _this = this;
				},
				
				methods: {
					changeEndPointPos: function(value, uuid, type) { //select切换
					},
					addEndPoint: function(type) {
						var uuid = node.data.nodeId + '-in-'  + parseInt(Math.random(0, 1) * 10000000);
						L.instance.createPoint(instance, node, uuid, type, 'TopLeft', 'scope');
						this.targetEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position": "TopLeft",
							"edit": "select"
						});
						node.data.targetEndPoint.push({
							"uuid": uuid,
							"type": type,
							"position": "TopLeft"
						});
					}
				
				}
			})
		});
	});
		Vue.component('component-targetpointedit', function(resolve, reject) { //流程图
		$.get("./components/targetPointEdit.html").then(function(res) {
			resolve({
				template: res,
				props: ['targetPoint'],
				data: function() {
					return {
						targetEndPoint: this.targetPoint,
						selects: [{
								value: "Top",
								text: "上"
							},
							{
								value: "Bottom",
								text: "下"
							},
							{
								value: "Left",
								text: "左"
							},
							{
								value: "Right",
								text: "右"
							},
							{
								value: "TopLeft",
								text: "左上"
							},
							{
								value: "BottomLeft",
								text: "左下"
							},
							{
								value: "TopRight",
								text: "右上"
							},
							{
								value: "BottomRight",
								text: "右下"
							}
						]
					}
				},
				created: function() {
					var _this = this;
				},
				watch:{
					targetEndPoint:function(val){
                	this.$emit('update:targetPoint', val);
           		 }
				},
				methods: {
				
					changeEditEndPointModule: function(index, type) {
						if(this.targetEndPoint[index].edit == 'select') {
							this.targetEndPoint[index].edit = 'input'
						} else {
							this.targetEndPoint[index].edit = 'select'
						}
						Vue.set(this.targetEndPoint, index, this.targetEndPoint[index]);

					},
					inputChangeEndPointPos: function(value, uuid, type) {
						var _this=this;
						/*if(!value) {
							this.$message.error('值为空，未修改！');
							return
						}
						var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
						var match = [false,false,false,false];
						var defaults=false;
						data.forEach(function(item) {
							if(item == value) {
								match = [true,true,true,true];
								defaults=true;
							}
						});
						if(!defaults) {
							var result = value.split(',');
							if(result.length != 4) {
								this.$message.error('格式错误，未修改！');
							} else {
								result.forEach(function(item, index) {
									if(index==0||index==1){
										if(item > 1 || item < -1) {
											_this.$message.error('格式错误，未修改！');
										}else{
											match[index]=true;
										}
									}else{
										if(item==0||item==1||item==-1){
											match[index]= true;
										}else{
											_this.$message.error('格式错误，未修改！');
										}
									}
									
								});
							}
							
						}
						for(var i=0;i<match.length;i++){
							if(!match[i]){
								return false
							}
						}*/

						for(var i = 0; i < this.targetEndPoint.length; i++) {
							if(this.targetEndPoint[i].uuid == uuid) {
								this.targetEndPoint[i].position = value;
							}
						}
					},
					modifyEndPointPos: function(event, uuid, type) { //修改端点位置
						var _this=this;

						for(var i = 0; i < this.targetEndPoint.length; i++) {
							if(this.targetEndPoint[i].uuid == uuid) {
								changePos(this.targetEndPoint[i].position, this.targetEndPoint[i].uuid,this,function(){
									node.data.targetEndPoint[i].position = _this.targetEndPoint[i].position;
								});
								
							}
						}

						function changePos(pos, uuid,_this,fun) {
							if(!pos) {
								this.$message.error('值为空，未修改！');
								return
							}
							var data = ["Top", "Bottom", "Left", "Right", "TopLeft", "BottomLeft", "TopRight", "BottomRight"];
							var match =[false,false,false,false];
							var defaults=false;
							data.forEach(function(item) {
								if(item ===pos) {
									match = [true,true,true,true];
									defaults=true;
								}
							});
							if(!defaults) {
								pos = pos.split(',');
								if(pos.length != 4) {
									this.$message.error('格式错误，未修改！');
								} else {
									pos.forEach(function(item, index) {
										pos[index] = parseFloat(item);
										if(index==0||index==1){
											if(item > 1 || item < -1) {
												_this.$message.error('格式错误，未修改！');
											}else{
												match[index]=true;
											}
										}else{
											if(item==0||item==1||item==-1){
												match[index] = true;
											}else{
												_this.$message.error('格式错误，未修改！');
											}
										}
										
									});
								}
								
							}
							for(var i=0;i<match.length;i++){
								if(!match[i]){
									return false
								}
							}

							var nodes = null;
							if(type == "target") {
								nodes = instance.selectEndpoints({
									target: node.data.nodeId
								});
							} else if(type == "source") {
								nodes = instance.selectEndpoints({
									source: node.data.nodeId
								});
							}
							var len = nodes.length;
							for(var j = 0; j < len; j++) {
								if(nodes.get(j).getUuid() == uuid) {
									nodes.get(j).setAnchor(pos);
									_this.$message.success('端点位置修改成功！');
								}
							}
								if(fun){fun()}
						}
					},
					removeEndPoint: function(uuid, type) {
						var arr = [];
						for(var i = 0; i < this.targetEndPoint.length; i++) {
							if(this.targetEndPoint[i].uuid != uuid) {
								arr.push(this.targetEndPoint[i]);
							}
						}
						this.targetEndPoint = arr;
						
						var arr1 = [];
						for(var i = 0; i < node.data.targetEndPoint.length; i++) {
							if(node.data.targetEndPoint[i].uuid != uuid) {
								arr1.push(node.data.targetEndPoint[i]);
							}
						}
						node.data.targetEndPoint = arr1;
						instance.deleteEndpoint(uuid);
					},
				}
			})
		});
	});
		Vue.component('component-nodecontent', function(resolve, reject) { //流程图
		$.get("./components/nodeContent.html").then(function(res) {
			
			resolve({
				template: res,
				props: ['nodeContent'],
				data: function() {
					return {
						content: this.nodeContent
					}
				},
				created: function() {
					console.log(this.content)
				},
				methods: {
					saveNodeContent: function() {
						var reg=new RegExp('{{(.*?)}}', "g");
            			var string=L.compileTemple(this.content,node.data.propertys);
						node.getElementsByClassName('node-content')[0].innerHTML = string;
						node.data.content = this.content;
					}
				}

			})
		});
	});
	Vue.component('component-nodepropertys', function(resolve) { //流程图
		$.get("./components/nodePropertys.html").then(function(res) {
			
			resolve({
				template: res,
				props: ['nodePropertys'],
				data: function() {
					return {
						propertys: this.nodePropertys,
					}
				},
				created: function() {
					this.setPropertys(node.data.propertys);
				},
				methods: {
					setPropertys: function(propertys) {
						var arr = [];
						for(var i = 0; i < propertys.length; i++) {
							var obj = {
								"edit": false
							};
							obj.key = propertys[i].key;
							obj.value = propertys[i].value;
							arr.push(obj);
						}
						this.propertys = arr;
					},
					addPropertys: function() {
						this.propertys.push({
							"key": "",
							"value": "",
							"edit": true
						})
					},
					editPropertys: function(index) {
						this.propertys[index].edit = !this.propertys[index].edit;
					},
					savePropertys: function(index) {
						this.propertys[index].edit = !this.propertys[index].edit;
						var arr = [];
						for(var i = 0; i < this.propertys.length; i++) {
							var obj = {};
							obj.key = this.propertys[i].key;
							obj.value = this.propertys[i].value;
							arr.push(obj);
						}
						node.data.propertys = JSON.parse(JSON.stringify(arr));
					},
					removePropertys: function(index) {
						var arr = [];
						for(var i = 0; i < this.propertys.length; i++) {
							if(i != index) {
								var obj = {};
								obj.key = this.propertys[i].key;
								obj.value = this.propertys[i].value;
								arr.push(obj)
							}
						}
						node.data.propertys = JSON.parse(JSON.stringify(arr));
						this.setPropertys(arr);

					}
				}

			})
		});
	});
	Vue.component('component-nodeeditmain', function(resolve, reject) { //流程图
		$.get("./components/nodeEdit-main.html?r="+ Math.random()).then(function(res) {
			
			resolve({
				template: res,
				props: [],
				data: function() {
					return {
						title: '',
						content: '',
						propertys: [],
						sourceEndPoint: JSON.parse(JSON.stringify(node.data.sourceEndPoint)),
						targetEndPoint: JSON.parse(JSON.stringify(node.data.targetEndPoint)),
					}
				},
				created: function() {
					this.setContent();
					this.setEndPointType()
				},
				methods: {

					setContent: function() {
						this.content = node.data.content
					},
					setEndPointType: function() {
						this.sourceEndPoint.forEach(function(item) {
							item.edit = 'select'
						});
						this.targetEndPoint.forEach(function(item) {
							item.edit = 'select'
						});
					},
					
					
					
					slidePanelClose: function() {
						$.slidePanel.hide()
					}
				}

			})
		});
	});
	new Vue({
		el: '#nodeEdit'

	});

}