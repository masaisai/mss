
var L={}
//创建节点
L.block={ 
	Model:function(option,instance){
		var _this=this;
		_this.defaults={
			type:'Rect',
			id:"",
			wrapId:"",
			top:0,
			left:0,
			background:'#fff',
			borderWidth:"2px",
			borderColor:"#666",
			borderRadius:"0px",
			hoverBorderColor:"#666",
			width:"120",
			height:"60",
			minHeight:'30px',
			minWidth:'30px',
			content:'',
			view:false,
			propertys:[]
		};
		option=$.extend(true,{},_this.defaults,option);
		if(option.borderColor==''){option.borderColor="#666666"}
		if(option.background==''){option.background="#ffffff"}
		if(option.borderRadius==''){option.borderRadius="0px"}
		var $background=null;
		switch(option.type)
				{
			case 'Rect':
 				_this.model=$('<div id="'+option.id+'" class="node" style="position:absolute;top:'+parseFloat(option.top)+'px;left:'+parseFloat(option.left)+'px;background:'+option.background+';width:'+option.width+'px;height:'+option.height+'px;border:'+parseInt(option.borderWidth)+'px solid '+option.borderColor+';min-height:'+option.minHeight+';min-width:'+option.minWidth+';border-radius:'+option.borderRadius+'" onselectstart="return false;"></div>');
 			 break;
			case 'Ellipse':
  				_this.model=$('<div id="'+option.id+'" class="node" style="position:absolute;top:'+parseFloat(option.top)+'px;left:'+parseFloat(option.left)+'px;background:'+option.background+';width:'+option.width+'px;height:'+option.height+'px;border:'+parseInt(option.borderWidth)+'px solid '+option.borderColor+';min-height:'+option.minHeight+';min-width:'+option.minWidth+';border-radius:50%" onselectstart="return false;"></div>');
  				break;
  			case 'Prismatic':
  			_this.model=$('<div id="'+option.id+'" class="node" style="position:absolute;top:'+parseFloat(option.top)+'px;left:'+parseFloat(option.left)+'px;background:'+option.background+';width:'+option.width+'px;height:'+option.height+'px;min-height:'+option.minHeight+';min-width:'+option.minWidth+';background:transparent;padding:'+parseInt(option.borderWidth)+'px" onselectstart="return false;"></div>');
  			$background=this.createPrismatic(option.id+'Prismatic',option.width,option.height,option.borderWidth,option.borderColor,option.background);
  			var $svg='<?xml version="1.0" standalone="no"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"><svg width="100%" height="100%" class="prismatic" version="1.1" xmlns="http://www.w3.org/2000/svg">'+$background+'</svg>';
  			_this.model.append($svg);
  			break;
			
			}
		
		_this.model.appendTo($("#" + option.wrapId));
		/*_this.model.hover(function(){
			if(option.type!='Prismatic'){
				$(this).css({"border":parseInt(option.borderWidth)+'px solid '+option.hoverBorderColor});
			}else{
				document.getElementById(option.id+'Prismatic').setAttribute("style",'fill:'+option.background+'; stroke:'+option.hoverBorderColor+';stroke-width:'+parseInt(option.borderWidth))
			}
		},function(){
			if(option.type!='Prismatic'){
				$(this).css({"border":parseInt(option.borderWidth)+'px solid '+option.borderColor});
			}else{
				document.getElementById(option.id+'Prismatic').setAttribute("style",'fill:'+option.background+'; stroke:'+option.borderColor+';stroke-width:'+parseInt(option.borderWidth))
			}
		});*/
		_this.$content=$('<div class="node-content"></div>');
		var content=L.compileTemple(option.content,option.propertys);
		_this.$content.append(content);
		_this.model.append(_this.$content);
		if(!option.view){
			_this.model.on('click',function(e){
		e.stopPropagation();
		for(var i=0;i<_this.allEditElement.length;i++){
				_this.allEditElement[i].remove()
			}
		var svgId=$background?$($background).attr('id'):'';
			_this.editBox(this,option.wrapId,instance,svgId);
			
		});
		}
		
		_this.model.mouseup(function(){
			_this.recordNodeStyle(this);
		})
	},
	recordNodeStyle:function(node){  //记录node位置
			var nodeStyle={};
			nodeStyle.width=$(node).width();
			nodeStyle.height=$(node).height();
			nodeStyle.x=$(node).position().left;
			nodeStyle.y=$(node).position().top;
			if(node.data.type=='Prismatic'){
				nodeStyle.borderWidth=Math.round(parseFloat($(node).find('.prismatic polygon').css('stroke-width')));
				nodeStyle.borderColor=$(node).find('.prismatic polygon').css('stroke');
				nodeStyle.background=$(node).find('.prismatic polygon').css('fill');
			}else{
				nodeStyle.borderWidth=Math.round(parseFloat($(node).css('border-width')))+"px";
				nodeStyle.borderColor=$(node).css('border-color');
				nodeStyle.background=$(node).css('background-color');
			}
			if(node.data.type=='Rect'){
				nodeStyle.borderRadius=$(node).css('border-radius');
			}
			node.data.nodeStyle=nodeStyle;
			
	},
	
	createPrismatic:function(id,width,height,borderWidth,borderColor,background){
		var position='2,'+height/2+' '+width/2+',2'+' '+(width-2)+','+height/2+' '+width/2+','+(height-2);
  			var $background='<polygon id='+id+' points="'+position+'" style="fill:'+background+'; stroke:'+borderColor+';stroke-width:'+parseInt(borderWidth)+';"/>';
  			return $background;
	},
	updatePrismatic:function(svgId,width,height){
		var position='2,'+height/2+' '+width/2+',2'+' '+(width-2)+','+height/2+' '+width/2+','+(height-2);
		document.getElementById(svgId).setAttribute('points', position)
	},
	allEditElement:[],
	editBox:function(node,wrapId,instance,svgId){
		var _this=this;
		var height=$(node).outerHeight();
		var width=$(node).outerWidth();
		var left=svgId?4:6;
		var top=svgId?4:6;
		var $editBox=$('<div class="editBox" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		$editBox.css({
			width:width+8+'px',
			height:height+8+'px',
			left:-left+'px',
			top:-top+'px'
		});

		_this.addResizeAble($editBox,node,instance,svgId);
			
		_this.allEditElement.push($editBox);
		$editBox.on('click',function(e){
			e.stopPropagation();
			//$editBox.on('mouseup',function(){
			//	$editBox.off('mousedown');
			//	$editBox.off('mouseup');
			//})
		});
		_this.toolBox(instance,$editBox,node);
		$(document).off('click');
		$(document).on('click',function(e){
			for(var i=0;i<_this.allEditElement.length;i++){
				_this.allEditElement[i].remove()
			}
		})
	},
	addResizeAble:function($editBox,node,instance,svgId){
		var _this=this;
		var $ltresize=$('<div class="resize lt" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $tresize=$('<div class="resize t" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $rtresize=$('<div class="resize rt" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $rresize=$('<div class="resize r" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $rbresize=$('<div class="resize rb" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $bresize=$('<div class="resize b" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $lbresize=$('<div class="resize lb" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		var $lresize=$('<div class="resize l" onselectstart="return false;" style="-moz-user-select: none;"></div>');
		$editBox.append($ltresize);
		$editBox.append($tresize);
		$editBox.append($rtresize);
		$editBox.append($rresize);
		$editBox.append($rbresize);
		$editBox.append($bresize);
		$editBox.append($lbresize);
		$editBox.append($lresize);
		$editBox.appendTo($(node));
		
		
		/*左上*/
		$ltresize.on('mousedown',function(e){
			instance.repaintEverything();
			//instance.droppable($('.node'))
			e.stopPropagation();
			var left=svgId?4:6;
			var top=svgId?4:6;
			var posX=$(node).position().left-left;
			var posY=$(node).position().top-top;
			var pageX0=e.pageX;
			var pageY0=e.pageY;
			var width=$(node).outerWidth();
			var height=$(node).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=pageX-pageX0;
				var oY=pageY-pageY0;
				if(oX>=width-30){oX=width-30}
				if(oY>=height-30){oY=height-30}
				$(node).css({
					width:width-oX+'px',
					height:height-oY+'px',
					left:posX+left+oX+'px',
					top:posY+top+oY+'px'
				});
				if(svgId){
					_this.updatePrismatic(svgId,width-oX,height-oY)
				}
				
				
				$editBox.css({
			width:width-oX+8+'px',
			height:height-oY+8+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});
		/*上*/
		$tresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var left=svgId?4:6;
			var top=svgId?4:6;
			var posY=$(node).position().top-top;
			var pageY0=e.pageY;
			var height=$(node).outerHeight();
			var width=$(node).outerWidth();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageY=e.pageY;
				var oY=pageY-pageY0;
				if(oY>=height-30){oY=height-30}
				$(node).css({
					height:height-oY+'px',
					top:posY+top+oY+'px'
				});
				if(svgId){
					_this.updatePrismatic(svgId,width,height-oY);
				}
				
				$editBox.css({
			height:height-oY+8+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});
	/*右上*/	
	$rtresize.on('mousedown',function(e){
		instance.repaintEverything();
		e.stopPropagation();
			var left=svgId?4:6;
			var top=svgId?4:6;
			var posX=$(node).position().left-left;
			var posY=$(node).position().top-top;
			var pageX0=e.pageX;
			var pageY0=e.pageY;
			var width=$(node).outerWidth();
			var height=$(node).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=pageX-pageX0;
				var oY=pageY-pageY0;
				if(oX<=30-width){oX=30-width}
				if(oY>=height-30){oY=height-30}
				$(node).css({
					width:width+oX+'px',
					height:height-oY+'px',
					top:posY+top+oY+'px'
				});
				if(svgId){
					_this.updatePrismatic(svgId,width+oX,height-oY);
				}
				$editBox.css({
			width:width+oX+8+'px',
			height:height-oY+8+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});	
		/*右*/
			$rresize.on('mousedown',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var left=svgId?4:6;
			var top=svgId?4:6;
			var posX=$(node).position().left-left;
			var pageX0=e.pageX;
			var width=$(node).outerWidth();
			var height=$(node).outerHeight();
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var oX=pageX-pageX0;
				if(oX<30-width){oX=30-width}
				$(node).css({
					width:width+oX+'px',
				});
				
				$editBox.css({
			width:width+oX+8+'px'
		});
		if(svgId){
					_this.updatePrismatic(svgId,width+oX,height);
				}
			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});
		/*右下*/
		$rbresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var left=svgId?4:6;
			var top=svgId?4:6;
			var posX=$(node).offset().left-left;
			var posY=$(node).offset().top-top;
			var width=$(node).outerWidth();
			var height=$(node).outerHeight();
			var pageX0=e.pageX;
			var pageY0=e.pageY;
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=pageX-pageX0;
				var oY=pageY-pageY0;
				if(oX<=30-width){oX=30-width}
				if(oY<=30-height){oY=30-height}
				$(node).css({
					width:width+oX+'px',
					height:height+oY+'px'
				});
				if(svgId){
					_this.updatePrismatic(svgId,width+oX,height+oY);
				}
				$editBox.css({
			width:width+oX+8+'px',
			height:height+oY+8+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});
		/*下*/
		$bresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var left=svgId?4:6;
			var top=svgId?4:6;
			var posY=$(node).position().top-top;
			var height=$(node).outerHeight();
			var width=$(node).outerWidth();
			var pageX0=e.pageX;
			var pageY0=e.pageY;
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageY=e.pageY;
				var oY=pageY-pageY0;
				if(oY<=30-height){oY=30-height}
				$(node).css({
					height:height+oY+'px'
				});
				if(svgId){
					_this.updatePrismatic(svgId,width,height+oY);
				}
				
				$editBox.css({
			height:height+oY+8+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});
		/*左下*/
		$lbresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var left=svgId?4:6;
			var top=svgId?4:6;
			var posX=$(node).position().left-left;
			var posY=$(node).position().top-top;
			var width=$(node).outerWidth();
			var height=$(node).outerHeight();
			var pageX0=e.pageX;
			var pageY0=e.pageY;
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var pageY=e.pageY;
				var oX=pageX-pageX0;
				var oY=pageY-pageY0;
				if(oX>=width-30){oX=width-30}
				if(oY<=30-height){oY=30-height}
				$(node).css({
					width:width-oX+'px',
					height:height+oY+'px',
					left:posX+left+oX+'px'
				});
				if(svgId){
					_this.updatePrismatic(svgId,width-oX,height+oY);
				}
				$editBox.css({
			width:width-oX+8+'px',
			height:height+oY+8+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});
		/*左*/
		$lresize.on('mousedown',function(e){
			instance.repaintEverything();
			e.stopPropagation();
			var left=svgId?4:6;
			var top=svgId?4:6;
			var posX=$(node).position().left-left;
			var width=$(node).outerWidth();
			var height=$(node).outerHeight();
			var pageX0=e.pageX;
			var pageY0=e.pageY;
			$(document).on('mousemove',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				var pageX=e.pageX;
				var oX=pageX-pageX0;
				if(oX>=width-30){oX=width-30}
				$(node).css({
					width:width-oX+'px',
					left:posX+left+oX+'px'
				});
				if(svgId){
					_this.updatePrismatic(svgId,width-oX,height);
				}
				$editBox.css({
			width:width-oX+8+'px'
		});

			});
			$(document).on('mouseup',function(e){
				instance.repaintEverything();
				e.stopPropagation();
				$(document).off('mousemove');
				$(document).off('mouseup');
				_this.recordNodeStyle(node)
			})
		});
	},
	tools:[
		{title:'编辑节点',class:'editBtn',icon:'fa fa-pencil',event:function(e,_this,instance,node){e.stopPropagation();$(instance).trigger('nodeEdit',node)}},
		{title:'删除节点',class:'removeBtn',icon:'fa fa-trash-o',event:function(e,_this,instance,node){e.stopPropagation();_this.removeModel(instance,node);}},
		
//		{title:'调整端点位置',class:'changeEndPointPositionBtn',icon:'fa fa-anchor',event:function(e,_this,instance,node){e.stopPropagation();
//		instance.selectEndpoints({target:node.data.nodeId}).setAnchor([1,1,0,0])
//		}}
	],
	toolBox:function(instance,$editBox,node){
		var $toolBox=$('<div class="toolBox"></div>');
		var _this=this;
		$editBox.append($toolBox);
		var $ul=$('<ul></ul>');
		for(var i=0;i<this.tools.length;i++){
			createLi(this.tools[i])
		}
		function createLi(data){
			var $li=$('<li></li>');
			var $a=$('<a class="'+data.class+'" data-title="'+data.title+'"><i class="'+data.icon+'"></i></a>');
			$li.append($a);
			$ul.append($li);
			var $tools=data;
			$a.click(function(e){
				$(this).title("destory");
				$tools.event&&$tools.event(e,_this,instance,node);
			});
		}
		$toolBox.append($ul);
	},
	
	removeModel:function(instance,node){
			//$editBox.remove();
			$(node).remove();
			//var nodeAttr=$(obj).get(0).nodeAttr;
			//console.log($(obj).get(0).data)
			//for(var i=0;i<nodeAttr.conn.length;i++){
			//	L.deleteConnection(instance,nodeAttr.conn[i]);
			//}
			//instance.deleteEndpoint(nodeAttr.endPoint[0])
			var nodeData=$(node).get(0).data;
			
			instance.select({target:$(node).get(0)}).delete();
			instance.select({source:$(node).get(0)}).delete();
			//instance.selectEndpoints({target:$(obj).get(0)}).delete();
			//instance.selectEndpoints({source:$(obj).get(0)}).delete();
			for(var i=0;i<nodeData.sourceEndPoint.length;i++){
				instance.deleteEndpoint(nodeData.sourceEndPoint[i].uuid);
			}
			for(var i=0;i<nodeData.targetEndPoint.length;i++){
				instance.deleteEndpoint(nodeData.targetEndPoint[i].uuid);
			}
			$(instance).trigger('nodeRemoved',[node,nodeData]);
	}
}


