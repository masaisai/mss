function isIE() {
	 if (!!window.ActiveXObject || "ActiveXObject" in window)
	  {return true;}
	  else
	 { return false;}
	 }
	
	
	L.title=function(){
		$.fn.title=function(type){
				return $(this).each(function(){
					if($(this).hasClass('disabled')||$(this).parents().hasClass('disabled')){return false};
					if($(this).hasClass('hasDataTitleTip')){
						if(type=="destory"){
						this.box.remove();
						$(this).removeClass('hasDataTitleTip');
					}
						return false;
					}else{
						$(this).addClass('hasDataTitleTip');
					
					var _this=this;
					_this.content=$(_this).attr("data-title");
					if((!type)&&_this.content){
					_this.posX=$(this).offset().left+($(this).outerWidth()/2);
					_this.posY=$(this).offset().top;
					_this.arrow=$('<div style="display:block;background:#333;position:absolute;width:8px;height:8px;bottom:-4px;transform:rotate(45deg);-ms-transform:rotate(45deg); z-index:999"></div>');
					_this.box=$('<div class="titleTip" style="display:inline-block;background:#333;opacity:0.9"></div>');
					_this.box.append(_this.arrow);
					_this.box.append(_this.content);
					$('body').append(_this.box);
					_this.box.css({
						"position":"absolute",
						"padding":"5px 12px",
						"line-height":"20px",
						"border":"1px solid #333",
						"border-radius":"4px",
						"z-index":"999",
						"color":"white",
						"box-shadow":"2px 4px 10px rgba(0,0,0,0.2)"
					});
					_this.pwidth=_this.box.outerWidth();
					_this.pheight=_this.box.height();
					_this.pleft=_this.posX-(_this.pwidth/2)+"px";
					_this.ptop=_this.posY-_this.pheight-18+"px";
					_this.arrow.css({"left":_this.pwidth/2-5+"px"});
					_this.box.css({
						"top":_this.ptop,
						"left":_this.pleft
					});
					}
					}
				})
			}
		$(document).on('mouseenter','[data-title]',function(){
			$(this).title();
		});
		$(document).on('mouseleave','[data-title]',function(){
			$(this).title("destory");
			$(".titleTip").remove();
			$(".hasDataTitleTip").removeClass('hasDataTitleTip');
		});
		$(document).on('click',function(){
			$(this).title("destory");
			$(".titleTip").remove();
			$(".hasDataTitleTip").removeClass('hasDataTitleTip');
			
		});
		
		
	}
	L.compileTemple=function(content,propertys){
		var reg=new RegExp('{{(.*?)}}', "g");
		var string=content;
		var strArr=string.match(reg);
		var newStrArr=[];
		if(strArr&&strArr.length>0){
			strArr.forEach(function(item,index){
				var newStr=item.substring(2);
				var len=newStr.length;
				newStr=newStr.substring(0,len-2);
				newStrArr.push(newStr)
			   });
			var proObj={};
			for(var i=0;i<propertys.length;i++){
					proObj[propertys[i].key]=propertys[i].value
			}
				newStrArr.forEach(function(item){
				if(proObj[item]){
					string=string.replace("{{"+item+"}}",proObj[item])
				}
			});
		}
		return string;
	}
	L.homeResize=function(){
				$('[data-plugin="resize"]').each(function(){
			var $resize=$('<div class="rx-resize"></div>');
			var direction=$(this).data('resize');
			if(!direction){
				return false;
			}else if(direction=='right'){
				$resize.addClass('resize-right');
			}else if(direction=='left'){
				$resize.addClass('resize-left');
			}else if(direction=='top'){
				$resize.addClass('resize-top');
			}
			$(this).append($resize)
			var _this=this;
			$resize.mousedown(function(e){
				$resize.addClass('active');
				var width=$(_this).outerWidth();
				var height=$(_this).outerHeight();
				var pageX=e.pageX;
				var pageY=e.pageY;
				$(document).bind('mousemove',function(e){
					var page1X=e.pageX;
					var page1Y=e.pageY;
					if(direction=='right'){
						var width1=page1X-pageX+width;
					if(width1>=500){
						width1=500
					}else if(width1<=100){
						width1=100
					}
					$(_this).css({
						"width":width1+'px'
					});
						$('.rx-container').css({
						'padding-left':width1+'px'
					})
					
					
					}else if(direction=='left'){
						var width1=pageX-page1X+width;
					if(width1>=500){
						width1=500
					}else if(width1<=100){
						width1=100
					}
					$(_this).css({
						"width":width1+'px'
					});
						$('.rx-container2').css({
						'padding-right':width1+'px'
						});
					}else if(direction=='top'){
						var height1=pageY-page1Y+height;
						if(height1>=500){
						height1=500
					}else if(height1<=100){
						height1=100
					}
						
						$(_this).css({
						"height":height1+'px'
					});
						$('.rx-container1').css({
						'padding-bottom':height1+'px'
					})
					}
					
				});
				
				$(document).bind('mouseup',function(e){
					$(document).unbind('mousemove');
					$(document).unbind('mouseup');
					$resize.removeClass('active');
				})
			})
		})
	}
	   	L.dragNodeExample=function(e,instance,type){
   			var $this=this;
  		var $node=$(e.currentTarget);
  		var $body=$('body');
  		var $nodeExample=$node.clone();
  		//$nodeExample.addClass('rx-node-example');
  		var nodeLeft=$node.offset().left;
  		var nodeTop=$node.offset().top;
  		var nodeWidth=$node.outerWidth();
  		var nodeHeight=$node.outerHeight();
  		var pageX=e.pageX;
  		var pageY=e.pageY;
  		$nodeExample.css({
  			position:'absolute',
  			left:nodeLeft+'px',
  			top:nodeTop+'px',
  			width:nodeWidth+'px',
  			height:nodeHeight+'px'
  		});
  		$(document).bind('mousemove',function(e){
  			var pageX1=e.pageX;
  			var pageY1=e.pageY;
  			$nodeExample.css({
  			left:nodeLeft+(pageX1-pageX)+'px',
  			top:nodeTop+(pageY1-pageY)+'px'
  		});
  		});
  		$(document).bind('mouseup',function(e){
  			var nodeExampleLeft=$nodeExample.offset().left;
  			var nodeExampleTop=$nodeExample.offset().top;
  			var cl=$('.rx-main').offset().left;
  			var ct=$('.rx-main').offset().top;
  			var cr=cl+$('.rx-main').outerWidth();
  			var cb=ct+$('.rx-main').outerHeight();
  			if(nodeExampleLeft>=cl&&nodeExampleTop>=ct&&nodeExampleLeft<=cr-100&&nodeExampleTop<=cb-50){
  				
  				var data={
  					width:nodeWidth,
  					height:nodeHeight,
  					left:nodeExampleLeft-$('#container-id').offset().left,
  					top:nodeExampleTop-$('#container-id').offset().top,
  					type:type
  				}
  				
  				$(instance).trigger('addDargNode',data)
  			}
  			$nodeExample.remove()
  			$(document).unbind('mousemove');
  			$(document).unbind('mouseup');
  		
  		})
   		$body.append($nodeExample);
  	}
	

 $.slidePanel.setDefaults({
  mouseDrag: false,
  touchDrag: false,
  pointerDrag: false,
  dragTolerance: 150,
})  	
$(function(){
	L.title();
	L.homeResize();
});
L.domtoimage=function(id,fun){
var node = document.getElementById(id);
domtoimage.toPng(node)
  .then(function (dataUrl) {
	  var img = new Image();
	  img.src = dataUrl;
	  if(fun){
		  fun({
			  src:dataUrl,
			  img:img
		  })
	  }
  })
  .catch(function (error) {
      console.error('oops, something went wrong!', error);
  });
    //domtoimage.toBlob(document.getElementById('container-id'))
   // .then(function (blob) {
    //    window.saveAs(blob, 'my-node.png');
   // });
}
function instanceUnbindEvent(instance) {
	instance.unbind("connection");
	instance.unbind("click");
	instance.unbind("dblclick");
	instance.unbind("beforeDrop");
	instance.unbind("connectionDetached");
	$(instance).unbind('addDargNode');
	$(instance).unbind('nodeRemoved');
	$(instance).unbind('nodeEdit');
}
function instanceBindEvent(instance) {
	instance.bind("connection", function(conn, originalEvent) {
		if(!conn.connection.getParameter("init")) {
			var lineData = {
				"type": "Line",
				"sourceId": conn.sourceId,
				"targetId": conn.targetId,
				"sourceEndPointUuid": conn.sourceEndpoint.getUuid(),
				"targetEndPointUuid": conn.targetEndpoint.getUuid(),
				"label": conn.connection.getOverlay('label').labelText
			}
			
			conn.connection.data=lineData;
			//store.state.processData.push(lineData);
		}
	});
	instance.bind("click", function(conn, originalEvent){});
	instance.bind("dblclick", function(conn, originalEvent) {
		var label=conn.getOverlay('label').label;
		//var name=prompt("label",label);
		//conn.getOverlay('label').setLabel(name);
		//conn.data.label=name;
		$(document).trigger('conEdit',[label,conn])
	});
	instance.bind("beforeDrop", function(conn) {
		if(instance.select({
				source: conn.sourceId,
				target: conn.targetId
			}).length >= 1) {
			return false;
		}
		return true;
	});
	instance.bind("connectionDetached", function(conn, originalEvent) {
		//console.log(conn)
	});
	$(instance).bind('addDargNode', function(e, result) {
		var nodeId=createNodeId();
		function createNodeId(){
			var id="node-"+parseInt(Math.random()*100000000);
			var len=L.instance.nodes.length;
			for(var i=0;i<len;i++){
				if(id==L.instance.nodes[i]){
					id=createNodeId();
				}
			}
			return id;
		}
		var params = {
			"type": "Rect",
			"nodeId":nodeId,
			"nodeStyle": {
				"x": result.left,
				"y": result.top,
				"width":result.width,
				"height": result.height,
				"borderWidth": "2px",
				'borderColor': ''
			},
			'scope':'scope',
			"sourceEndPoint": [],
			"targetEndPoint": [],
			"content":'<div class="node-example-content"><span class="node-example-text">'+nodeId+'</span></div>',
			"propertys":[]
		}
		if(result.type==1){
			params.sourceEndPoint=[{
				"uuid": nodeId+"-out-"+parseInt(Math.random(0,1)*10000000),
				"type": "source",
				"position":'Right'
			}]
		}else if(result.type==2){
			params.targetEndPoint=[{
				"uuid": nodeId+"-in-"+parseInt(Math.random(0,1)*10000000),
				"type": "target",
				"position":'Left'
			}]
		}
		else if(result.type==3){
			params.sourceEndPoint=[{
				"uuid": nodeId+"-out-"+parseInt(Math.random(0,1)*10000000),
				"type": "source",
				"position":'Right'
			}]
			params.targetEndPoint=[{
				"uuid": nodeId+"-in-"+parseInt(Math.random(0,1)*10000000),
				"type": "target",
				"position":'Left'
			}]
		}else if(result.type==4){
			params.type="Ellipse";
			params.sourceEndPoint=[{
				"uuid": nodeId+"-out-"+parseInt(Math.random(0,1)*10000000),
				"type": "source",
				"position":'Right'
			}]
		}else if(result.type==5){
			params.type="Ellipse";
			params.targetEndPoint=[{
				"uuid": nodeId+"-in-"+parseInt(Math.random(0,1)*10000000),
				"type": "target",
				"position":'Left'
			}]
		}else if(result.type==6){
			params.type="Ellipse";
			params.sourceEndPoint=[{
				"uuid": nodeId+"-out-"+parseInt(Math.random(0,1)*10000000),
				"type": "source",
				"position":'Right'
			}]
			params.targetEndPoint=[{
				"uuid": nodeId+"-in-"+parseInt(Math.random(0,1)*10000000),
				"type": "target",
				"position":'Left'
			}]
		}else if(result.type==7){
			params.type="Prismatic";
			params.sourceEndPoint=[{
				"uuid": nodeId+"-out-"+parseInt(Math.random(0,1)*10000000),
				"type": "source",
				"position":'Right'
			}]
			
		}else if(result.type==8){
			params.type="Prismatic";
			params.targetEndPoint=[{
				"uuid": nodeId+"-in-"+parseInt(Math.random(0,1)*10000000),
				"type": "target",
				"position":'Left'
			}]
		}else if(result.type==9){
			params.type="Prismatic";
			params.sourceEndPoint=[{
				"uuid": nodeId+"-out-"+parseInt(Math.random(0,1)*10000000),
				"type": "source",
				"position":'Right'
			}]
			params.targetEndPoint=[{
				"uuid": nodeId+"-in-"+parseInt(Math.random(0,1)*10000000),
				"type": "target",
				"position":'Left'
			}]
		}
		L.instance.createNode(instance, params)
		instance.draggable($('#'+nodeId), {
			containment: true
		});
	});
	
	$(instance).bind('nodeRemoved', function(e, node, data) {});
	
	$(instance).bind('nodeEdit', function(e, node, data) {
		//要转换为图片的dom对象
   L.instance.currentNode=node;
//  var node = document.getElementById('container-id');
//
//domtoimage.toPng(node)
//  .then(function (dataUrl) {
//      var img = new Image();
//      img.src = dataUrl;
//      document.body.appendChild(img);
//  })
//  .catch(function (error) {
//      console.error('oops, something went wrong!', error);
//  });
    //domtoimage.toBlob(document.getElementById('container-id'))
   // .then(function (blob) {
    //    window.saveAs(blob, 'my-node.png');
   // });
		//console.log(e)
		//console.log(node)
		
		//L.instance.removeView(instance);
		//store.state.instance=null;
		//console.log(store.state.instance)
		//store.state.instance=L.instance.init({Container:"container-id"});
		//L.instance.createAjaxView(store.state.instance,'common/data/data.json');
		var connectionList = instance.getConnections();
		
		for(var i=0;i<connectionList.length;i++){
			//for(var j=0;j<connectionList[i].endpoints.length;j++){
			//	console.log(connectionList[i].endpoints[j].getUuid())
			//}
			//console.log(connectionList[i].sourceId)
			//console.log(connectionList[i].targetId)
			//console.log(connectionList[i].getOverlay('label').label)
		}
		$(document).off('slidePanel::afterLoad');
		$(document).on('slidePanel::afterLoad', function (e) {
			
 			 L.instance.nodeEdit(instance,node)
		});
		$.slidePanel.show({
 		 url: './components/nodeEdit.html',
  		settings: {
    	method: 'GET'
  		}});
		//setTimeout(function(){
		//	$.slidePanel.hide()
		//},2000)
	});
	
}			