L.instance = {};
//流程初始化参数
L.instance.init = function(option) {
	L.instance.nodes=[];
	var defaults = {
		Connector: ["Flowchart",{ stub: [40, 60], gap: 10, cornerRadius:0, alwaysRespectStubs: true }], //Flowchart、Bezier、Straight、StateMachine
		DragOptions: {
			cursor: "pointer",
			zIndex: 2000
		},
		PaintStyle: {
			strokeWidth: 1,
			stroke: "#37474F",
			outlineStroke: "transparent",
			outlineWidth:6
		},
		EndpointStyle: {},
		EndpointHoverStyle: {
			
		},
		HoverPaintStyle: {
			stroke: "#ff4c52",
			strokeWidth: 1,
			outlineStroke: "transparent"
		},
		ConnectionOverlays: [
			["Arrow", {
				location:1,
				length: 10,
				foldback: 0.6,
				fill: '#000',
				width: 8,
				visible: true
			}],
			["Custom", {
				create: function(component) {
					var $remove = $("<div style='width:20px;height:20px;line-height:18px;text-align:center;cursor:pointer;border-radius:50%;background:#000;color:#fff;padding:0'><i class='fa fa-close'><i></div>");
					return $remove;
				},
				cssClass: 'hidden',
				location: 0.8,
				id: "customOverlay",
				hoverClass: 'show',
				events: {
					"click": function(custom, evt) {
						L.instance.deleteConnection(custom._jsPlumb.instance, custom._jsPlumb.component)
					}
				}
			}],

			["Label", {
				label: 'label',
				id: 'label',
				location: 0.5,
				cssClass: 'aLabel',
				hoverClass: 'show',
				events: {
					"click": function(label, evt) {
						//label.setLabel('54444');
							//console.log(label)
							//console.log(evt)
					}
				}
			}]
		],
		Container: "container-id"
	};

	option = $.extend(true, {}, defaults, option);
	return jsPlumb.getInstance(option);
}
//预览模式初始化参数
L.instance.viewInit = function(option) {
	L.instance.nodes=[];
	var defaults = {
		Connector: ["Flowchart",{ stub: [40, 60], gap: 10, cornerRadius:0, alwaysRespectStubs: true }], //Flowchart、Bezier、Straight、StateMachine
		DragOptions: {
			cursor: "pointer",
			zIndex: 2000
		},
		PaintStyle: {
			strokeWidth: 1,
			stroke: "#37474F",
			outlineStroke: "transparent",
			outlineWidth: 10
		},
		EndpointStyle: {},
		EndpointHoverStyle: {
			fill: "",
			radius:0
		},
		HoverPaintStyle: {
			stroke: "#000",
			strokeWidth: 1,
			outlineStroke: "transparent"
		},
		ConnectionOverlays: [
			["Arrow", {
				location:1,
				length: 10,
				foldback: 0.6,
				fill: '#000',
				width: 8,
				visible: true
			}],
			

			["Label", {
				label: 'label',
				id: 'label',
				location: 0.5,
				cssClass: 'aLabel',
				hoverClass: 'show',
				events: {
					"click": function(label, evt) {
					
					}
				}
			}]
		],
		Container: "container-id"
	};

	option = $.extend(true, {}, defaults, option);
	return jsPlumb.getInstance(option);
}
//增加单个节点
L.instance.createBlock = function(instance, type, nodeId, position, width, height, borderWidth, borderColor, background,content,view,propertys) {

	L.block.Model({
		type: type,
		id: nodeId,
		wrapId: Object.getPrototypeOf(instance).Defaults.Container,
		top: position.y,
		left: position.x,
		width: width,
		height: height,
		borderWidth: borderWidth,
		borderColor: borderColor,
		background: background,
		content:content,
		propertys:propertys,
		view:view
	}, instance)
	return jsPlumb.getSelector('#' + nodeId)[0];
}
//增加单个端点
L.instance.createPoint = function(instance, node, uuid, type, position,scope,view) {
	 //"Top","Bottom","Left","Right","Center","TopRight","BottomRight","TopLeft","BottomLeft"
	var anchor = "Left";//另一种格式[0,0.5,0,0]
	var paintStyle = {
		radius:10,
		fill: '#ff4c52'
	};
	
	var isSource = false,
		isTarget = true;
	if(type == 'source') {
		paintStyle.fill = '#6DA611';
		isSource = true;
		isTarget = false;
		anchor = "Right";
		
	}
	if(view){
		paintStyle = {
		radius:0
	};
	}
	if(position) {
		if(position.split(',').length==4){
			position=position.split(',');
			position.forEach(function(item,index){
					position[index]=parseFloat(item);
				
			});
			anchor=position;
		}else{
			anchor = position;
		}
		
	}
	
	var e = instance.addEndpoint(node, {
		uuid: uuid,
		paintStyle: paintStyle,
		anchor: anchor,
		maxConnections: -1,
		isSource: isSource,
		isTarget: isTarget,
		scope:scope,
		detachable: true
	});
	return e
}

//增加端点连线
L.instance.connectPoints = function(instance, sourceUuid, targetUuid, label, init) {
	var conn = instance.connect({
		uuids: [sourceUuid, targetUuid],
		parameters: {
			"label": label,
			'init': init
		}
	});
	if(conn){
		conn.getOverlay('label').setLabel(label);
		conn.id = sourceUuid + '-' + targetUuid;
		//conn.getOverlay('label').setLocation(0.3)
	}
	return conn;

}
//删除端点连线
L.instance.deleteConnection = function(instance, conn) {
	instance.deleteConnection(conn);
}
//创建节点和所带端点并携带数据
L.instance.createNode = function(instance, option,view) {
	var defaults = {
		"type": "Rect",
		"nodeId": "",
		"nodeStyle": {
			"x": 320,
			"y": 140,
			"width": 156,
			"height": 60,
			"borderWidth": "2px",
			"borderColor": "rgb(102, 102, 102)",
			"background": "white"
		},
		"sourceEndPoint": [],
		"targetEndPoint": []
	}
	option = $.extend(true, {}, defaults, option);
	L.instance.nodes.push(option.nodeId);
	var node = L.instance.createBlock(instance, option.type, option.nodeId, {
		x: option.nodeStyle.x + 'px',
		y: option.nodeStyle.y + 'px'
	}, parseInt(option.nodeStyle.width), parseInt(option.nodeStyle.height), parseInt(option.nodeStyle.borderWidth), option.nodeStyle.borderColor, option.nodeStyle.background,option.content,view,option.propertys);
	if(node){
		node.data = option;
		for(var i = 0; i < option.sourceEndPoint.length; i++) {
			L.instance.createPoint(instance, node, option.sourceEndPoint[i].uuid, option.sourceEndPoint[i].type, option.sourceEndPoint[i].position,option.scope,view)
		}
		for(var i = 0; i < option.targetEndPoint.length; i++) {
			L.instance.createPoint(instance, node, option.targetEndPoint[i].uuid, option.targetEndPoint[i].type, option.targetEndPoint[i].position,option.scope,view)
		}
	}
	return node;
}
//增加端点连线并携带数据
L.instance.createLine = function(instance, option) {
	var defaults = {
		"type": "Line",
		"sourceId": "",
		"targetId": "",
		"sourceEndPointUuid": "",
		"targetEndPointUuid": "",
		"label": "label"
	}
	option = $.extend(true, {}, defaults, option);
	var conn = L.instance.connectPoints(instance, option.sourceEndPointUuid, option.targetEndPointUuid, option.label, true);
	if(conn){
		conn.data = option;
	}
	return conn;
}
//创建视图模式流程图
L.instance.createView = function(instance, data) {
	for(var i = 0; i < data.length; i++) {
		if(data[i].type != 'Line') {
			L.instance.createNode(instance, data[i],'view')
		} else {
			L.instance.createLine(instance, data[i])
		}
		//instance.draggable($('.node'), {
			//containment: true
		//});
	}
	
}
//ajax获取数据
L.instance.ajaxData = function(url,fun) {
	var res=$.get(url).then(function(result) {
		if(fun){fun(result)}
	});
	
}
//删除视图模式流程图
L.instance.removeView = function(instance) {
	instance.deleteEveryConnection();
	instance.deleteEveryEndpoint();
	$(instance.getContainer()).find('.node').remove();
}
//创建编辑模式流程图
L.instance.createEditView = function(instance, data) {
	for(var i = 0; i < data.length; i++) {
		if(data[i].type != 'Line') {
			L.instance.createNode(instance, data[i])
		} else {
			L.instance.createLine(instance, data[i])
		}
		instance.draggable($('.node'), {
			containment: true
		});
	}
	
}
//删除编辑模式流程图
L.instance.removeEditView = function(instance) {
	instance.deleteEveryConnection();
	instance.deleteEveryEndpoint();
	$(instance.getContainer()).find('.node').remove();
}

//获取流程数据
L.instance.getInstanceData = function(instance){
	var data=[];
	var nodes=$(instance.getContainer()).find('.node');
	var len=nodes.length;
	for(var i=0;i<len;i++){
		data.push(nodes[i].data)
	}
	instance.select().each(function(connection) {
			data.push(connection.data)
		
});
return JSON.parse(JSON.stringify(data))
}
